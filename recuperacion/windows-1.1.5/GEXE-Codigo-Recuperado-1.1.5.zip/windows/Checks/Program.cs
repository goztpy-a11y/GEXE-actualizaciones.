using System;
using System.IO;
using System.Text.Json;
using GOZT.Excel;

int checks = 0;
void Check(bool condition, string name) { if (!condition) throw new Exception(name); checks++; }
void Reject(Action action, string name) { try { action(); } catch (InvalidDataException) { checks++; return; } throw new Exception(name); }
Check(PlanPricing.PriceUsd("personal") == 28.15m, "Monthly amount");
Check(PlanPricing.PriceUsd("one_time") == 201.09m, "One-time amount");
var engine = new FormulaEngine((r, c) => r == 0 && c == 0 ? 10 : 20);
Check(engine.Evaluate("=2+3*4") == "14", "Arithmetic precedence");
Check(engine.Evaluate("=SUM(A1:A2)") == "30", "Cell ranges");
Check(engine.Evaluate("=SUMA(1;2;3)") == "6", "Spanish formulas");
Check(engine.Evaluate("=1/0") == "#DIV/0!", "Formula error");
const string repo = "goztpy-a11y/GEXE-actualizaciones.";
string Announcement(string url, string product="GEXE") => JsonSerializer.Serialize(new { product, enabled=true, version="1.1.5", downloadUrl=url, notes="Precios actualizados" });
string good = Announcement("https://github.com/" + repo + "/releases/download/v1.1.5/GEXE-Update.zip");
Check(AppUpdateService.Parse(good, new Version("1.1.4"), repo) != null, "Update from installed version");
Check(AppUpdateService.Parse(good, new Version("1.1.5"), repo) == null, "No repeated update");
Reject(() => AppUpdateService.Parse(Announcement("https://example.com/GEXE-Update.zip"), new Version("1.1.4"), repo), "Reject other host");
Reject(() => AppUpdateService.Parse(Announcement("https://github.com/other/repo/releases/download/v1.1.5/GEXE-Update.zip"), new Version("1.1.4"), repo), "Reject other repository");
Reject(() => AppUpdateService.Parse(Announcement("https://github.com/" + repo + "/releases/download/v1.1.5/GEXE-Update.zip", "OTHER"), new Version("1.1.4"), repo), "Reject other product");
Console.WriteLine($"PASS: {checks} checks.");
