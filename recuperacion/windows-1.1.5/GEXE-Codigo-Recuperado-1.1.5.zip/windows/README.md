# GEXE Windows: código recuperado y candidata 1.1.5

Recuperado del instalador público 1.1.4 con ILSpy 11.2. Es código reconstruido; no es una copia exacta de los archivos originales ni prueba que sea la última versión local del autor.

Precios mostrados: USD 28,15 mensual y USD 201,09 pago único. Se actualizaron el cálculo de planes, tarjetas, botones y pantalla de vencimiento. Los importes son fijos en USD.

Comprobaciones: compilación cruzada de aplicación e instalador Windows x64 y once pruebas de precios, fórmulas y validación de anuncios de actualización. Falta verificar la interfaz en Windows. Los avisos CS4014 recuperados corresponden a tareas de interfaz existentes y quedan documentados en la compilación.

**No se publicó esta candidata en el canal estable.** No se actualizaron los productos externos de Lemon Squeezy. Se conservan las configuraciones públicas de prueba; no usar esta candidata para cobrar con los nuevos importes sin ajustar primero el proveedor. La candidata no activa cobros reales.

## Compilar

Con .NET SDK 10 y PowerShell: `./build.ps1`. El instalador conserva el destino de instalación y no escribe en los directorios de libros o credenciales del usuario. Requiere .NET Desktop Runtime 10 x64.

## Android

La recuperación Windows no contiene el proyecto Android, APK ni su clave de firma. El borrador `android-updates` solo tenía un anuncio JSON al revisar el repositorio. No se cambió ni se publicó ese canal: se necesita recuperar su proyecto y firma para actualizar instalaciones existentes.

## Distribución

No cambiar el anuncio estable a 1.1.5 hasta verificar la interfaz y los importes externos. El actualizador existente solo anuncia versiones mayores y descarga el ZIP; la instalación requiere cerrar GEXE y ejecutar GEXE-Setup.exe. La publicación de este código no cambia las instalaciones existentes.
