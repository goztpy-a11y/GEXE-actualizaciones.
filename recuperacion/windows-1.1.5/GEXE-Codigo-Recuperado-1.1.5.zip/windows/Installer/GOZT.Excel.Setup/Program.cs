using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace GOZT.Excel.Setup;

internal static class Program
{
	[STAThread]
	private static int Main(string[] args)
	{
		try
		{
			string text = ((args.Length == 2 && args[0] == "--extract") ? Path.GetFullPath(args[1]) : Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "GEXE"));
			ExtractPayload(text);
			if (args.Length == 2 && args[0] == "--extract")
			{
				return 0;
			}
			string text2 = Path.Combine(text, "GEXE.exe");
			CreateDesktopShortcut(text2, "GEXE.lnk");
			MessageBox.Show("GEXE se instaló. Se abrirá ahora.", "GEXE", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			Process.Start(new ProcessStartInfo(text2)
			{
				WorkingDirectory = text
			});
			return 0;
		}
		catch (Exception ex)
		{
			MessageBox.Show("No se pudo instalar GEXE. Si está abierto, cerralo y volvé a ejecutar este instalador. " + ex.Message, "GEXE", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			return 1;
		}
	}

	private static void ExtractPayload(string target)
	{
		Directory.CreateDirectory(target);
		Assembly executingAssembly = Assembly.GetExecutingAssembly();
		foreach (string item in from x in executingAssembly.GetManifestResourceNames()
			where x.StartsWith("payload/", StringComparison.Ordinal)
			select x)
		{
			string path = item.Substring("payload/".Length);
			string fullPath = Path.GetFullPath(Path.Combine(target, path));
			if (!fullPath.StartsWith(Path.GetFullPath(target).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
			{
				throw new InvalidDataException("Ruta inválida del instalador.");
			}
			Directory.CreateDirectory(Path.GetDirectoryName(fullPath));
			using Stream stream = executingAssembly.GetManifestResourceStream(item) ?? throw new InvalidDataException("Falta un archivo del instalador.");
			using FileStream destination = File.Create(fullPath);
			stream.CopyTo(destination);
		}
	}

	private static void CreateDesktopShortcut(string appPath, string shortcutName)
	{
		dynamic val = Activator.CreateInstance(Type.GetTypeFromProgID("WScript.Shell") ?? throw new InvalidOperationException("Windows no pudo preparar el acceso directo."));
		string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
		dynamic val2 = val.CreateShortcut(Path.Combine(folderPath, shortcutName));
		val2.TargetPath = appPath;
		val2.IconLocation = appPath + ",0";
		val2.WorkingDirectory = Path.GetDirectoryName(appPath);
		val2.Description = "GEXE";
		val2.Save();
		Marshal.FinalReleaseComObject(val2);
		Marshal.FinalReleaseComObject(val);
	}
}
