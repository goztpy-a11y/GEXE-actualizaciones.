$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$appOut = Join-Path $root 'artifacts/app'
$setupOut = Join-Path $root 'artifacts/setup'
dotnet run --project "$root/Checks/Checks.csproj" -c Release
if ($LASTEXITCODE) { throw 'Las comprobaciones fallaron.' }
dotnet publish "$root/App/GEXE.csproj" -c Release -r win-x64 --self-contained false -o $appOut
if ($LASTEXITCODE) { throw 'No se pudo compilar GEXE.' }
Copy-Item "$root/Config/*.json" $appOut -Force
$payload = Join-Path $root 'Installer/payload'
New-Item -ItemType Directory -Path $payload -Force | Out-Null
Get-ChildItem $appOut -File | Where-Object Extension -ne '.pdb' | Copy-Item -Destination $payload -Force
dotnet publish "$root/Installer/GEXE-Setup.csproj" -c Release -r win-x64 --self-contained false -o $setupOut
if ($LASTEXITCODE) { throw 'No se pudo compilar el instalador.' }
Get-ChildItem $setupOut -Filter '*.pdb' | Remove-Item
Compress-Archive -Path "$setupOut/*" -DestinationPath "$root/artifacts/GEXE-Update-1.1.5.zip" -Force
