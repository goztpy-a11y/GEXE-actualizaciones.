using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace GOZT.Excel;

internal sealed class DriveSnapshots(HttpClient http, Func<CancellationToken, Task<string>> authorize)
{
	private const string Fields = "id,name,modifiedTime,appProperties";

	private async Task<HttpRequestMessage> Request(HttpMethod method, string url, CancellationToken ct)
	{
		HttpRequestMessage request = new HttpRequestMessage(method, url);
		HttpRequestHeaders headers = request.Headers;
		headers.Authorization = new AuthenticationHeaderValue("Bearer", await authorize(ct));
		return request;
	}

	private static DriveSnapshot Parse(JsonElement file)
	{
		JsonElement property = file.GetProperty("appProperties");
		JsonElement value;
		JsonElement value2;
		return new DriveSnapshot(file.GetProperty("id").GetString(), property.GetProperty("gexeBookId").GetString(), property.TryGetProperty("gexeParent", out value) ? (value.GetString() ?? "") : "", file.GetProperty("name").GetString() ?? "Libro", file.TryGetProperty("modifiedTime", out value2) ? (value2.GetString() ?? "") : "");
	}

	public async Task<List<DriveSnapshot>> ListAsync(CancellationToken ct)
	{
		List<DriveSnapshot> files = new List<DriveSnapshot>();
		string text = null;
		do
		{
			string text2 = Uri.EscapeDataString("appProperties has { key='gexeSyncOwner' and value='GEXE-Cloud-1' } and trashed=false");
			string text3 = "https://www.googleapis.com/drive/v3/files?q=" + text2 + "&spaces=drive&pageSize=1000&fields=" + Uri.EscapeDataString("nextPageToken,files(id,name,modifiedTime,appProperties)");
			if (text != null)
			{
				text3 = text3 + "&pageToken=" + Uri.EscapeDataString(text);
			}
			using HttpRequestMessage request = await Request(HttpMethod.Get, text3, ct);
			using HttpResponseMessage response = await http.SendAsync(request, ct);
			response.EnsureSuccessStatusCode();
			using JsonDocument jsonDocument = JsonDocument.Parse(await response.Content.ReadAsStringAsync(ct));
			files.AddRange(jsonDocument.RootElement.GetProperty("files").EnumerateArray().Select(Parse));
			text = (jsonDocument.RootElement.TryGetProperty("nextPageToken", out var value) ? value.GetString() : null);
		}
		while (!string.IsNullOrEmpty(text));
		return files;
	}

	internal static List<DriveSnapshot> Heads(IEnumerable<DriveSnapshot> snapshots)
	{
		List<DriveSnapshot> source = snapshots.ToList();
		HashSet<string> parents = (from s in source
			select s.Parent into p
			where p.Length > 0
			select p).ToHashSet(StringComparer.Ordinal);
		return source.Where((DriveSnapshot s) => !parents.Contains(s.Id)).ToList();
	}

	public async Task<DriveSnapshot> AppendAsync(string bookId, string parent, string title, byte[] content, CancellationToken ct)
	{
		if (!Guid.TryParse(bookId, out var _))
		{
			throw new InvalidDataException("Identificador de libro inválido.");
		}
		var metadata = new
		{
			name = title + ".gexe",
			mimeType = "application/json",
			appProperties = new Dictionary<string, string>
			{
				{ "gexeSyncOwner", "GEXE-Cloud-1" },
				{ "gexeBookId", bookId },
				{ "gexeParent", parent }
			}
		};
		using HttpRequestMessage request = await Request(HttpMethod.Post, "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=" + Uri.EscapeDataString("id,name,modifiedTime,appProperties"), ct);
		MultipartContent multipartContent = new MultipartContent("related");
		multipartContent.Add(new StringContent(JsonSerializer.Serialize(metadata), Encoding.UTF8, "application/json"));
		ByteArrayContent byteArrayContent = new ByteArrayContent(content);
		byteArrayContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
		multipartContent.Add(byteArrayContent);
		request.Content = multipartContent;
		using HttpResponseMessage response = await http.SendAsync(request, ct);
		response.EnsureSuccessStatusCode();
		using JsonDocument jsonDocument = JsonDocument.Parse(await response.Content.ReadAsStringAsync(ct));
		return Parse(jsonDocument.RootElement);
	}

	public async Task<byte[]> DownloadAsync(DriveSnapshot snapshot, CancellationToken ct)
	{
		using HttpRequestMessage request = await Request(HttpMethod.Get, "https://www.googleapis.com/drive/v3/files/" + Uri.EscapeDataString(snapshot.Id) + "?alt=media", ct);
		using HttpResponseMessage response = await http.SendAsync(request, ct);
		response.EnsureSuccessStatusCode();
		return await response.Content.ReadAsByteArrayAsync(ct);
	}
}
