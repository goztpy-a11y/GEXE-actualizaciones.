using System;

namespace GOZT.Excel;

internal sealed class LicenseException : Exception
{
	public LicenseException(string message)
		: base(message)
	{
	}
}
