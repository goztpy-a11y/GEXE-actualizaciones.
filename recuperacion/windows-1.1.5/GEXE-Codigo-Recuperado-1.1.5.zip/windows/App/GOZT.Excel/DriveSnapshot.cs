namespace GOZT.Excel;

internal sealed record DriveSnapshot(string Id, string BookId, string Parent, string Name, string Modified);
