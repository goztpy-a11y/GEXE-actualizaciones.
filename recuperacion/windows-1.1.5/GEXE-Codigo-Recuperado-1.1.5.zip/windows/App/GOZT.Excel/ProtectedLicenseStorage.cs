using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace GOZT.Excel;

internal sealed class ProtectedLicenseStorage(string path) : ILicenseStorage
{
	private static readonly byte[] Entropy = Encoding.UTF8.GetBytes("GEXE-License-v1");

	public StoredLicense? Load()
	{
		if (!File.Exists(path))
		{
			return null;
		}
		return JsonSerializer.Deserialize<StoredLicense>(ProtectedData.Unprotect(File.ReadAllBytes(path), Entropy, DataProtectionScope.CurrentUser)) ?? throw new InvalidDataException("No se pudo leer la licencia guardada.");
	}

	public void Save(StoredLicense value)
	{
		byte[] bytes = ProtectedData.Protect(JsonSerializer.SerializeToUtf8Bytes(value), Entropy, DataProtectionScope.CurrentUser);
		Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path)));
		string sourceFileName = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
		try
		{
			File.WriteAllBytes(sourceFileName, bytes);
			File.Move(sourceFileName, path, overwrite: true);
		}
		finally
		{
			if (File.Exists(sourceFileName))
			{
				File.Delete(sourceFileName);
			}
		}
	}

	public void Clear()
	{
		if (File.Exists(path))
		{
			File.Delete(path);
		}
	}
}
