namespace GOZT.Excel;

internal interface ILicenseStorage
{
	StoredLicense? Load();

	void Save(StoredLicense value);

	void Clear();
}
