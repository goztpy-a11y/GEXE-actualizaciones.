using System;
namespace GOZT.Excel;
internal static class PlanPricing
{
	internal static decimal PriceUsd(string plan)
	{
		if (!(plan == "personal"))
		{
			if (plan == "one_time")
			{
				return 201.09m;
			}
			throw new ArgumentException("Plan desconocido.");
		}
		return 28.15m;
	}

}
