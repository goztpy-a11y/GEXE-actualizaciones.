using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace GOZT.Excel;

internal sealed class GoogleDriveSync
{
	private const string Scope = "https://www.googleapis.com/auth/drive.file";

	private const string FileName = "GOZT Excel Workbook.gozt";

	private const string OwnerKey = "goztOwner";

	private const string OwnerValue = "GOZT-Excel";

	private static readonly HttpClient Http = new HttpClient();

	private readonly string clientId;

	private string refreshToken;

	private string clientSecret = "";

	private readonly string configPath;

	private DataProtectionScope protectionScope;

	private GoogleDriveSync(string clientId, string refreshToken, string configPath, DataProtectionScope scope = DataProtectionScope.CurrentUser)
	{
		this.clientId = clientId;
		this.refreshToken = refreshToken;
		this.configPath = configPath;
		protectionScope = scope;
	}

	public static GoogleDriveSync? Load(string path)
	{
		try
		{
			if (!File.Exists(path))
			{
				return null;
			}
			using JsonDocument jsonDocument = JsonDocument.Parse(File.ReadAllText(path));
			JsonElement rootElement = jsonDocument.RootElement;
			string text = rootElement.GetProperty("clientId").GetString() ?? "";
			string text2 = rootElement.GetProperty("protectedRefreshToken").GetString() ?? "";
			if (text.Length == 0 || text2.Length == 0)
			{
				return null;
			}
			DataProtectionScope scope = ((rootElement.TryGetProperty("protectionScope", out var value) && Enum.TryParse<DataProtectionScope>(value.GetString(), out var result)) ? result : DataProtectionScope.CurrentUser);
			string text3 = Encoding.UTF8.GetString(ProtectedData.Unprotect(Convert.FromBase64String(text2), null, scope));
			GoogleDriveSync googleDriveSync = new GoogleDriveSync(text, text3, path, scope);
			if (rootElement.TryGetProperty("protectedClientSecret", out var value2) && !string.IsNullOrEmpty(value2.GetString()))
			{
				googleDriveSync.clientSecret = Encoding.UTF8.GetString(ProtectedData.Unprotect(Convert.FromBase64String(value2.GetString()), null, scope));
			}
			return googleDriveSync;
		}
		catch
		{
			return null;
		}
	}

	public static async Task<GoogleDriveSync> ConnectAsync(string id, string path, CancellationToken cancellationToken, string? secret = null)
	{
		if (string.IsNullOrWhiteSpace(id) || !id.Contains(".apps.googleusercontent.com", StringComparison.Ordinal))
		{
			throw new InvalidOperationException("El ID de cliente de Google no parece válido.");
		}
		using TcpListener listener = new TcpListener(IPAddress.Loopback, 0);
		listener.Start();
		int port = ((IPEndPoint)listener.LocalEndpoint).Port;
		string redirect = CreateRedirectUri(port);
		string verifier = Base64Url(RandomNumberGenerator.GetBytes(32));
		string value = Base64Url(SHA256.HashData(Encoding.ASCII.GetBytes(verifier)));
		string state = Base64Url(RandomNumberGenerator.GetBytes(24));
		string fileName = "https://accounts.google.com/o/oauth2/v2/auth?" + Query(new Dictionary<string, string>
		{
			["client_id"] = id,
			["redirect_uri"] = redirect,
			["response_type"] = "code",
			["scope"] = "https://www.googleapis.com/auth/drive.file",
			["code_challenge"] = value,
			["code_challenge_method"] = "S256",
			["access_type"] = "offline",
			["prompt"] = "consent",
			["state"] = state
		});
		try
		{
			Process.Start(new ProcessStartInfo(fileName)
			{
				UseShellExecute = true
			});
		}
		catch (Exception innerException)
		{
			throw new InvalidOperationException("No se pudo abrir el navegador para conectar Google.", innerException);
		}
		Dictionary<string, string> query;
		while (true)
		{
			using (TcpClient client = await listener.AcceptTcpClientAsync(cancellationToken))
			{
				using NetworkStream stream = client.GetStream();
				using StreamReader reader = new StreamReader(stream, Encoding.ASCII, detectEncodingFromByteOrderMarks: true, -1, leaveOpen: true);
				string request = (await reader.ReadLineAsync(cancellationToken)) ?? "";
				while (!string.IsNullOrEmpty(await reader.ReadLineAsync(cancellationToken)))
				{
				}
				string text = request.Split(' ').ElementAtOrDefault(1) ?? "/";
				if (!Uri.TryCreate(redirect + text, UriKind.Absolute, out Uri result) || result.AbsolutePath != "/")
				{
					await Reply(stream, "400 Bad Request", "<h2>GEXE</h2><p>Solicitud local no válida. Volvé a la aplicación.</p>", cancellationToken);
					continue;
				}
				Dictionary<string, string> dictionary = ParseQuery(result.Query);
				if (!dictionary.TryGetValue("state", out var value2) || value2 != state || (!dictionary.ContainsKey("code") && !dictionary.ContainsKey("error")))
				{
					await Reply(stream, "400 Bad Request", "<h2>GEXE</h2><p>No se pudo validar la respuesta de Google. Volvé a la aplicación.</p>", cancellationToken);
					continue;
				}
				query = dictionary;
				string page = (query.ContainsKey("error") ? "<h2>GEXE</h2><p>No se completó la autorización. Volvé a la aplicación.</p>" : "<h2>GEXE</h2><p>Autorización recibida. Volvé a GEXE para terminar la conexión.</p>");
				await Reply(stream, "200 OK", page, cancellationToken);
			}
			break;
		}
		if (query.TryGetValue("error", out string value3))
		{
			throw new InvalidOperationException("Google canceló la autorización: " + value3);
		}
		if (!query.TryGetValue("code", out string value4))
		{
			throw new InvalidOperationException("Google no devolvió un código de autorización.");
		}
		using HttpResponseMessage tokenResponse = await Http.PostAsync("https://oauth2.googleapis.com/token", new FormUrlEncodedContent(TokenFields(id, secret, new Dictionary<string, string>
		{
			["code"] = value4,
			["code_verifier"] = verifier,
			["redirect_uri"] = redirect,
			["grant_type"] = "authorization_code"
		})), cancellationToken);
		string text2 = await tokenResponse.Content.ReadAsStringAsync(cancellationToken);
		if (!tokenResponse.IsSuccessStatusCode)
		{
			throw new InvalidOperationException("Google no pudo completar el acceso: " + SafeMessage(text2));
		}
		using JsonDocument jsonDocument = JsonDocument.Parse(text2);
		string text3 = (jsonDocument.RootElement.TryGetProperty("refresh_token", out var value5) ? (value5.GetString() ?? "") : "");
		if (text3.Length == 0)
		{
			throw new InvalidOperationException("Google no entregó un token de renovación. Desconectá GOZT Excel de tu cuenta y volvé a conectar.");
		}
		GoogleDriveSync googleDriveSync = new GoogleDriveSync(id, text3, path);
		googleDriveSync.clientSecret = secret ?? "";
		googleDriveSync.Save();
		return googleDriveSync;
	}

	internal DriveSnapshots Snapshots()
	{
		return new DriveSnapshots(Http, AccessToken);
	}

	public void Disconnect()
	{
		if (File.Exists(configPath))
		{
			File.Delete(configPath);
		}
		refreshToken = "";
		clientSecret = "";
	}

	internal static string CreateRedirectUri(int port)
	{
		if ((port < 1 || port > 65535) ? true : false)
		{
			throw new ArgumentOutOfRangeException("port");
		}
		return $"http://127.0.0.1:{port}";
	}

	public async Task UploadWorkbookAsync(string localPath, CancellationToken cancellationToken)
	{
		if (!File.Exists(localPath))
		{
			throw new FileNotFoundException("Todavía no hay un libro local guardado.");
		}
		string access = await AccessToken(cancellationToken);
		using HttpRequestMessage request = AuthRequest(HttpMethod.Get, "https://www.googleapis.com/drive/v3/files?" + Query(new Dictionary<string, string>
		{
			["q"] = "appProperties has { key='goztOwner' and value='GOZT-Excel' } and trashed=false",
			["spaces"] = "drive",
			["fields"] = "files(id,name,modifiedTime,appProperties)",
			["pageSize"] = "100"
		}), access);
		using HttpResponseMessage listResponse = await Http.SendAsync(request, cancellationToken);
		string text = await listResponse.Content.ReadAsStringAsync(cancellationToken);
		if (!listResponse.IsSuccessStatusCode)
		{
			throw new InvalidOperationException("No se pudo consultar el archivo propio de GOZT Excel: " + SafeMessage(text));
		}
		using JsonDocument list = JsonDocument.Parse(text);
		List<JsonElement> list2 = (list.RootElement.TryGetProperty("files", out var value) ? value.EnumerateArray().ToList() : new List<JsonElement>());
		string id;
		if (list2.Count > 0)
		{
			id = list2.OrderByDescending((JsonElement f) => (!f.TryGetProperty("modifiedTime", out var value3)) ? "" : value3.GetString()).First().GetProperty("id")
				.GetString();
		}
		else
		{
			var value2 = new
			{
				name = "GOZT Excel Workbook.gozt",
				mimeType = "application/octet-stream",
				appProperties = new Dictionary<string, string> { ["goztOwner"] = "GOZT-Excel" }
			};
			using HttpRequestMessage create = AuthRequest(HttpMethod.Post, "https://www.googleapis.com/drive/v3/files?fields=id", access);
			create.Content = new StringContent(JsonSerializer.Serialize(value2), Encoding.UTF8, "application/json");
			using HttpResponseMessage created = await Http.SendAsync(create, cancellationToken);
			string text2 = await created.Content.ReadAsStringAsync(cancellationToken);
			if (!created.IsSuccessStatusCode)
			{
				throw new InvalidOperationException("No se pudo crear el archivo de GOZT Excel en Drive: " + SafeMessage(text2));
			}
			using JsonDocument jsonDocument = JsonDocument.Parse(text2);
			id = jsonDocument.RootElement.GetProperty("id").GetString();
		}
		byte[] content = await File.ReadAllBytesAsync(localPath, cancellationToken);
		using HttpRequestMessage upload = AuthRequest(HttpMethod.Patch, "https://www.googleapis.com/upload/drive/v3/files/" + Uri.EscapeDataString(id) + "?uploadType=media", access);
		upload.Content = new ByteArrayContent(content);
		upload.Content.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
		using HttpResponseMessage uploaded = await Http.SendAsync(upload, cancellationToken);
		string body = await uploaded.Content.ReadAsStringAsync(cancellationToken);
		if (!uploaded.IsSuccessStatusCode)
		{
			throw new InvalidOperationException("No se pudo subir el libro a Drive: " + SafeMessage(body));
		}
	}

	public async Task<byte[]> DownloadWorkbookAsync(CancellationToken cancellationToken)
	{
		string access = await AccessToken(cancellationToken);
		using HttpRequestMessage request = AuthRequest(HttpMethod.Get, "https://www.googleapis.com/drive/v3/files?" + Query(new Dictionary<string, string>
		{
			["q"] = "appProperties has { key='goztOwner' and value='GOZT-Excel' } and trashed=false",
			["spaces"] = "drive",
			["fields"] = "files(id,name,modifiedTime)",
			["pageSize"] = "100"
		}), access);
		using HttpResponseMessage listResponse = await Http.SendAsync(request, cancellationToken);
		string text = await listResponse.Content.ReadAsStringAsync(cancellationToken);
		if (!listResponse.IsSuccessStatusCode)
		{
			throw new InvalidOperationException("No se pudo buscar el archivo de GOZT Excel: " + SafeMessage(text));
		}
		using JsonDocument doc = JsonDocument.Parse(text);
		List<JsonElement> obj = (doc.RootElement.TryGetProperty("files", out var value) ? value.EnumerateArray().ToList() : new List<JsonElement>());
		if (obj.Count == 0)
		{
			throw new FileNotFoundException("Todavía no hay un libro sincronizado. Primero subilo desde la otra computadora.");
		}
		string stringToEscape = obj.OrderByDescending((JsonElement f) => (!f.TryGetProperty("modifiedTime", out var value2)) ? "" : value2.GetString()).First().GetProperty("id")
			.GetString();
		using HttpRequestMessage download = AuthRequest(HttpMethod.Get, "https://www.googleapis.com/drive/v3/files/" + Uri.EscapeDataString(stringToEscape) + "?alt=media", access);
		using HttpResponseMessage response = await Http.SendAsync(download, cancellationToken);
		if (!response.IsSuccessStatusCode)
		{
			throw new InvalidOperationException("No se pudo descargar el libro de Drive: " + SafeMessage(await response.Content.ReadAsStringAsync(cancellationToken)));
		}
		return await response.Content.ReadAsByteArrayAsync(cancellationToken);
	}

	private async Task<string> AccessToken(CancellationToken ct)
	{
		using HttpResponseMessage response = await Http.PostAsync("https://oauth2.googleapis.com/token", new FormUrlEncodedContent(TokenFields(clientId, clientSecret, new Dictionary<string, string>
		{
			["refresh_token"] = refreshToken,
			["grant_type"] = "refresh_token"
		})), ct);
		string text = await response.Content.ReadAsStringAsync(ct);
		if (!response.IsSuccessStatusCode)
		{
			throw new InvalidOperationException("La sesión de Google expiró. Volvé a conectar la cuenta: " + SafeMessage(text));
		}
		using JsonDocument jsonDocument = JsonDocument.Parse(text);
		return jsonDocument.RootElement.GetProperty("access_token").GetString();
	}

	internal static Dictionary<string, string> TokenFields(string id, string? secret, Dictionary<string, string> fields)
	{
		Dictionary<string, string> dictionary = new Dictionary<string, string>(fields) { ["client_id"] = id };
		if (!string.IsNullOrWhiteSpace(secret))
		{
			dictionary["client_secret"] = secret;
		}
		return dictionary;
	}

	private void Save()
	{
		Directory.CreateDirectory(Path.GetDirectoryName(configPath));
		byte[] bytes = Encoding.UTF8.GetBytes(refreshToken);
		protectionScope = DataProtectionScope.CurrentUser;
		byte[] inArray;
		try
		{
			inArray = ProtectedData.Protect(bytes, null, protectionScope);
		}
		catch (CryptographicException)
		{
			protectionScope = DataProtectionScope.LocalMachine;
			inArray = ProtectedData.Protect(bytes, null, protectionScope);
		}
		string protectedRefreshToken = Convert.ToBase64String(inArray);
		string protectedClientSecret = ((clientSecret.Length == 0) ? "" : Convert.ToBase64String(ProtectedData.Protect(Encoding.UTF8.GetBytes(clientSecret), null, protectionScope)));
		string text = configPath + ".tmp";
		File.WriteAllText(text, JsonSerializer.Serialize(new
		{
			clientId = clientId,
			protectedRefreshToken = protectedRefreshToken,
			protectedClientSecret = protectedClientSecret,
			protectionScope = protectionScope.ToString()
		}));
		File.Move(text, configPath, overwrite: true);
	}

	private static async Task Reply(NetworkStream stream, string status, string page, CancellationToken cancellationToken)
	{
		byte[] body = Encoding.UTF8.GetBytes(page);
		byte[] bytes = Encoding.ASCII.GetBytes($"HTTP/1.1 {status}\r\nContent-Type: text/html; charset=utf-8\r\nConnection: close\r\nContent-Length: {body.Length}\r\n\r\n");
		await stream.WriteAsync(bytes, cancellationToken);
		await stream.WriteAsync(body, cancellationToken);
	}

	private static HttpRequestMessage AuthRequest(HttpMethod method, string url, string access)
	{
		HttpRequestMessage httpRequestMessage = new HttpRequestMessage(method, url);
		httpRequestMessage.Headers.Authorization = new AuthenticationHeaderValue("Bearer", access);
		return httpRequestMessage;
	}

	private static string Query(Dictionary<string, string> data)
	{
		return string.Join("&", data.Select((KeyValuePair<string, string> x) => Uri.EscapeDataString(x.Key) + "=" + Uri.EscapeDataString(x.Value)));
	}

	private static Dictionary<string, string> ParseQuery(string query)
	{
		return (from x in query.TrimStart('?').Split('&', StringSplitOptions.RemoveEmptyEntries)
			select x.Split('=', 2) into x
			where x.Length == 2
			select x).ToDictionary((string[] x) => Uri.UnescapeDataString(x[0]), (string[] x) => Uri.UnescapeDataString(x[1].Replace('+', ' ')));
	}

	private static string Base64Url(byte[] bytes)
	{
		return Convert.ToBase64String(bytes).TrimEnd('=').Replace('+', '-')
			.Replace('/', '_');
	}

	private static string SafeMessage(string body)
	{
		try
		{
			using JsonDocument jsonDocument = JsonDocument.Parse(body);
			string result;
			if (jsonDocument.RootElement.TryGetProperty("error_description", out var value))
			{
				result = value.GetString() ?? "Error de Google";
			}
			else
			{
				result = (jsonDocument.RootElement.TryGetProperty("error", out value) ? (value.GetString() ?? "Error de Google") : "Error de Google");
			}
			return result;
		}
		catch
		{
			return "Error de Google";
		}
	}
}
