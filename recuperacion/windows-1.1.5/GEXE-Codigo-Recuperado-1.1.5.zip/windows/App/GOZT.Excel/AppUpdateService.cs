using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace GOZT.Excel;

internal sealed class AppUpdateService(HttpClient http, string repository)
{
	internal static bool ValidRepository(string value)
	{
		return Regex.IsMatch(value, "^[A-Za-z0-9][A-Za-z0-9_.-]*/[A-Za-z0-9][A-Za-z0-9_.-]*$");
	}

	private static Version Normalize(Version value)
	{
		return new Version(value.Major, value.Minor, Math.Max(0, value.Build), Math.Max(0, value.Revision));
	}

	internal static AppUpdate? Parse(string json, Version current, string repository)
	{
		if (!ValidRepository(repository))
		{
			throw new InvalidDataException("El canal de actualizaciones no es válido.");
		}
		using JsonDocument jsonDocument = JsonDocument.Parse(json);
		JsonElement rootElement = jsonDocument.RootElement;
		if (rootElement.GetProperty("product").GetString() != "GEXE")
		{
			throw new InvalidDataException("El anuncio no corresponde a GEXE.");
		}
		if (!rootElement.GetProperty("enabled").GetBoolean())
		{
			return null;
		}
		string text = rootElement.GetProperty("version").GetString() ?? "";
		if (!Version.TryParse(text, out Version result))
		{
			throw new InvalidDataException("La versión publicada no es válida.");
		}
		if (Normalize(result) <= Normalize(current))
		{
			return null;
		}
		if (!Uri.TryCreate(rootElement.GetProperty("downloadUrl").GetString() ?? "", UriKind.Absolute, out Uri result2) || result2.Scheme != "https" || result2.Host != "github.com" || !result2.IsDefaultPort || result2.UserInfo.Length > 0 || result2.Query.Length > 0 || result2.Fragment.Length > 0 || !result2.AbsolutePath.StartsWith("/" + repository + "/releases/download/", StringComparison.OrdinalIgnoreCase) || !result2.AbsolutePath.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
		{
			throw new InvalidDataException("La descarga no pertenece al canal autorizado de GEXE.");
		}
		string text2 = (rootElement.TryGetProperty("notes", out var value) ? (value.GetString() ?? "") : "");
		if (text2.Length > 4000)
		{
			text2 = text2.Substring(0, 4000);
		}
		return new AppUpdate(text, result2.AbsoluteUri, text2);
	}

	internal async Task<AppUpdate?> CheckAsync(Version current, CancellationToken ct)
	{
		if (!ValidRepository(repository))
		{
			throw new InvalidDataException("El canal de actualizaciones no es válido.");
		}
		using HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, "https://github.com/" + repository + "/releases/latest/download/gexe-update.json");
		request.Headers.UserAgent.ParseAdd("GEXE-Updates/1.0");
		request.Headers.CacheControl = new CacheControlHeaderValue
		{
			NoCache = true
		};
		using HttpResponseMessage response = await http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct);
		if (response.StatusCode == HttpStatusCode.NotFound)
		{
			return null;
		}
		response.EnsureSuccessStatusCode();
		if (response.Content.Headers.ContentLength > 65536)
		{
			throw new InvalidDataException("El anuncio de actualización es demasiado grande.");
		}
		using Stream stream = await response.Content.ReadAsStreamAsync(ct);
		using MemoryStream memory = new MemoryStream();
		byte[] buffer = new byte[4096];
		int num;
		while ((num = await stream.ReadAsync(buffer, ct)) > 0)
		{
			if (memory.Length + num > 65536)
			{
				throw new InvalidDataException("El anuncio de actualización es demasiado grande.");
			}
			memory.Write(buffer, 0, num);
		}
		return Parse(Encoding.UTF8.GetString(memory.ToArray()), current, repository);
	}
}
