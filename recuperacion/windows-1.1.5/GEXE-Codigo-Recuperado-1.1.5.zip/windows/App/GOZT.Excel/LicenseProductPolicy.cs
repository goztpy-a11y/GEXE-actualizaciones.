using System;
using System.Linq;

namespace GOZT.Excel;

internal sealed class LicenseProductPolicy
{
	public long ProductId { get; set; }

	public long? StoreId { get; set; }

	public long[] VariantIds { get; set; } = Array.Empty<long>();

	public long[] MonthlyVariantIds { get; set; } = Array.Empty<long>();

	public int LicensedMajor { get; set; } = 1;

	public int ActivationLimit { get; set; } = 3;

	public bool IsTestProduct { get; set; } = true;

	public bool IsConfigured
	{
		get
		{
			if ((ProductId > 0 || VariantIds.Length + MonthlyVariantIds.Length > 0) && VariantIds.Concat(MonthlyVariantIds).All((long id) => id > 0) && !VariantIds.Intersect(MonthlyVariantIds).Any() && LicensedMajor > 0)
			{
				return ActivationLimit == 3;
			}
			return false;
		}
	}
}
