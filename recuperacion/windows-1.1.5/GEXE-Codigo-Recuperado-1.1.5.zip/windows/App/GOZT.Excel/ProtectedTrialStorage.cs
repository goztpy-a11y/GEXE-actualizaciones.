using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Win32;

namespace GOZT.Excel;

internal sealed class ProtectedTrialStorage(string path, string registryPath = "Software\\GEXE\\TrialV1") : ITrialStorage
{
	private static readonly byte[] Entropy = Encoding.UTF8.GetBytes("GEXE-Trial-v1");

	public TrialRecord? Load()
	{
		using RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(registryPath);
		List<TrialRecord> list = new List<TrialRecord>();
		if (File.Exists(path))
		{
			list.Add(Decode(File.ReadAllBytes(path)));
		}
		if (registryKey?.GetValue("Record") is byte[] bytes)
		{
			list.Add(Decode(bytes));
		}
		if (list.Count == 0)
		{
			return null;
		}
		TrialRecord trialRecord = list.MinBy((TrialRecord r) => r.StartedUtc);
		return new TrialRecord
		{
			StartedUtc = trialRecord.StartedUtc,
			LastSeenUtc = list.Max((TrialRecord r) => r.LastSeenUtc),
			Blocked = list.Any((TrialRecord r) => r.Blocked),
			DeviceHash = trialRecord.DeviceHash
		};
	}

	private static TrialRecord Decode(byte[] bytes)
	{
		return JsonSerializer.Deserialize<TrialRecord>(ProtectedData.Unprotect(bytes, Entropy, DataProtectionScope.CurrentUser)) ?? throw new InvalidDataException("Prueba inválida.");
	}

	public void Save(TrialRecord record)
	{
		byte[] array = ProtectedData.Protect(JsonSerializer.SerializeToUtf8Bytes(record), Entropy, DataProtectionScope.CurrentUser);
		using RegistryKey registryKey = Registry.CurrentUser.CreateSubKey(registryPath);
		registryKey.SetValue("Record", array, RegistryValueKind.Binary);
		Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path)));
		string sourceFileName = path + ".tmp";
		File.WriteAllBytes(sourceFileName, array);
		File.Move(sourceFileName, path, overwrite: true);
	}
}
