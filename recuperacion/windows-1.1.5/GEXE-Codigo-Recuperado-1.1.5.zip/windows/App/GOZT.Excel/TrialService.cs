using System;
using System.Diagnostics;
using System.Linq;

namespace GOZT.Excel;

internal sealed class TrialService(ITrialStorage storage, string deviceHash, Func<DateTimeOffset>? clock = null, Func<TimeSpan>? elapsed = null)
{
	private readonly Func<DateTimeOffset> utc = clock ?? ((Func<DateTimeOffset>)(() => DateTimeOffset.UtcNow));

	private readonly Func<TimeSpan> monotonic = elapsed ?? CreateMonotonicClock();

	private TrialRecord? record;

	private DateTimeOffset sessionStart;

	private TimeSpan sessionElapsed;

	private bool failed;

	private DateTimeOffset Now => new DateTimeOffset[3]
	{
		utc(),
		sessionStart + (monotonic() - sessionElapsed),
		record?.LastSeenUtc ?? DateTimeOffset.MinValue
	}.Max();

	private static Func<TimeSpan> CreateMonotonicClock()
	{
		Stopwatch watch = Stopwatch.StartNew();
		return () => watch.Elapsed;
	}

	internal TrialView Start()
	{
		try
		{
			DateTimeOffset dateTimeOffset = utc();
			record = storage.Load() ?? new TrialRecord
			{
				StartedUtc = dateTimeOffset,
				LastSeenUtc = dateTimeOffset,
				DeviceHash = deviceHash
			};
			sessionStart = ((dateTimeOffset > record.LastSeenUtc) ? dateTimeOffset : record.LastSeenUtc);
			sessionElapsed = monotonic();
			if (record.DeviceHash != deviceHash || record.StartedUtc > record.LastSeenUtc || dateTimeOffset < record.LastSeenUtc.AddMinutes(-2.0))
			{
				record.Blocked = true;
			}
			return Check();
		}
		catch
		{
			failed = true;
			return Peek();
		}
	}

	internal TrialView Peek()
	{
		if (failed || record == null)
		{
			return new TrialView(Allowed: false, DateTimeOffset.MinValue, "No se pudo comprobar la prueba. Activá tu licencia o consultá a soporte. Tus libros se conservan.");
		}
		DateTimeOffset dateTimeOffset = record.StartedUtc.AddDays(5.0);
		bool flag = !record.Blocked && Now < dateTimeOffset;
		return new TrialView(flag, dateTimeOffset, flag ? ("Prueba gratis de 5 días · hasta el " + dateTimeOffset.ToLocalTime().ToString("dd/MM/yyyy HH:mm")) : "La prueba de cinco días terminó o no pudo validarse. Comprá y activá una licencia para continuar.");
	}

	internal TrialView Check()
	{
		if (record == null || failed)
		{
			return Peek();
		}
		try
		{
			if (utc() < record.LastSeenUtc.AddMinutes(-2.0))
			{
				record.Blocked = true;
			}
			record.LastSeenUtc = Now;
			if (record.LastSeenUtc >= record.StartedUtc.AddDays(5.0))
			{
				record.Blocked = true;
			}
			storage.Save(record);
		}
		catch
		{
			failed = true;
		}
		return Peek();
	}
}
