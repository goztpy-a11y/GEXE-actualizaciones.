using System;

namespace GOZT.Excel;

internal sealed record LicenseView(bool IsActive, string Message, int SeatsUsed = 0, bool Offline = false, string Plan = "one_time", DateTimeOffset? ValidUntil = null);
