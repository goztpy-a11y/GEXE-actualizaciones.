using System;

namespace GOZT.Excel;

internal sealed record TrialView(bool Allowed, DateTimeOffset EndsUtc, string Message);
