using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Xml.Linq;
using Microsoft.Win32;

namespace GOZT.Excel;

public partial class MainWindow : Window, IComponentConnector
{
	private sealed class CloudBinding
	{
		public bool Enabled { get; set; }

		public string Head { get; set; } = "";

		public string Hash { get; set; } = "";

		public bool Conflict { get; set; }
	}

	private sealed class Book
	{
		public string SyncId { get; set; } = Guid.NewGuid().ToString("N");

		public string Title { get; set; } = "Libro1";

		public List<Sheet> Sheets { get; set; } = new List<Sheet>();

		public int Active { get; set; }
	}

	private sealed class Sheet
	{
		public string Name { get; set; } = "Hoja1";

		public List<List<string>> Rows { get; set; } = new List<List<string>>();

		public Dictionary<string, string> NumberFormats { get; set; } = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

		public Dictionary<string, CellStyleInfo> CellStyles { get; set; } = new Dictionary<string, CellStyleInfo>(StringComparer.OrdinalIgnoreCase);

		public Dictionary<string, CellLink> CellLinks { get; set; } = new Dictionary<string, CellLink>(StringComparer.OrdinalIgnoreCase);

		public Dictionary<string, string> CellNotes { get; set; } = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

		public Dictionary<string, string> CachedFormulaValues { get; set; } = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

		public Dictionary<string, string> CachedFormulaTypes { get; set; } = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

		public string PageColor { get; set; } = "#FFFFFF";
	}

	private sealed class CellLink
	{
		public string SourceSheet { get; set; } = "";

		public int SourceRow { get; set; }

		public int SourceCol { get; set; }
	}

	private sealed record PendingCellWrite(Sheet Sheet, int Row, int Col, string Value, string? Navigation);

	private sealed class CellStyleInfo
	{
		public string FontFamily { get; set; } = "Aptos Narrow";

		public double FontSize { get; set; } = 11.0;

		public bool Bold { get; set; }

		public bool Italic { get; set; }

		public bool Underline { get; set; }

		public string HorizontalAlignment { get; set; } = "Left";

		public string? FontColor { get; set; }

		public string? FillColor { get; set; }

		public string? BorderColor { get; set; }
	}

	private sealed record ExportCellStyle(string NumberFormat, string? FontFamily, double? FontSize, bool? Bold, bool? Italic, bool? Underline, string? FontColor, string? FillColor, string? HorizontalAlignment, string? BorderColor);

	private sealed record ExportFont(string? Family, double? Size, bool? Bold, bool? Italic, bool? Underline, string? Color);

	private sealed class CopyMarchingAdorner : Adorner
	{
		private readonly Func<Rect?> rectangle;

		private readonly DispatcherTimer timer;

		private double phase;

		public CopyMarchingAdorner(UIElement element, Func<Rect?> getRectangle)
			: base(element)
		{
			rectangle = getRectangle;
			IsHitTestVisible = false;
			timer = new DispatcherTimer(DispatcherPriority.Render)
			{
				Interval = TimeSpan.FromMilliseconds(90L)
			};
			timer.Tick += (object? _, EventArgs _) =>
			{
				phase = (phase + 1.0) % 4.0;
				InvalidateVisual();
			};
			timer.Start();
		}

		public void Stop()
		{
			timer.Stop();
		}

		protected override void OnRender(DrawingContext drawingContext)
		{
			base.OnRender(drawingContext);
			Rect? rect = rectangle();
			if (rect.HasValue)
			{
				Rect valueOrDefault = rect.GetValueOrDefault();
				if (!valueOrDefault.IsEmpty && !(valueOrDefault.Width < 2.0) && !(valueOrDefault.Height < 2.0))
				{
					valueOrDefault = new Rect(valueOrDefault.Left + 1.0, valueOrDefault.Top + 1.0, Math.Max(1.0, valueOrDefault.Width - 2.0), Math.Max(1.0, valueOrDefault.Height - 2.0));
					Pen pen = new Pen(Brushes.Black, 2.0);
					pen.DashStyle = new DashStyle(new double[2] { 2.0, 2.0 }, phase);
					Pen pen2 = pen;
					pen = new Pen(Brushes.White, 2.0);
					pen.DashStyle = new DashStyle(new double[2] { 2.0, 2.0 }, phase + 2.0);
					Pen pen3 = pen;
					drawingContext.DrawRectangle(null, pen2, valueOrDefault);
					drawingContext.DrawRectangle(null, pen3, valueOrDefault);
				}
			}
		}
	}

	private static readonly HttpClient UpdateHttp = new HttpClient();

	private AppUpdate? availableUpdate;

	private bool checkingUpdates;

	private string updateStatus = "Buscá nuevas versiones de GEXE sin usar un USB.";

	private readonly List<Action> updateObservers = new List<Action>();

	private DispatcherTimer? updateTimer;

	private readonly CancellationTokenSource updateShutdown = new CancellationTokenSource();

	private GoogleDriveSync? cloudDrive;

	private DispatcherTimer? cloudTimer;

	private Dictionary<string, CloudBinding> cloudBindings = new Dictionary<string, CloudBinding>();

	private bool cloudBusy;

	private bool applyingCloud;

	private bool cloudClosing;

	private TaskCompletionSource? cloudIdle;

	private DateTime cloudLastEdit = DateTime.MinValue;

	private DateTime nextCloudAttempt = DateTime.MinValue;

	private int cloudFailures;

	private static readonly HttpClient LicenseHttp = new HttpClient(new HttpClientHandler
	{
		AllowAutoRedirect = false
	})
	{
		Timeout = TimeSpan.FromSeconds(15L)
	};

	private LicenseService? licenseService;

	private LicenseView licenseView = new LicenseView(IsActive: false, "Gratis · sin licencia activa en esta computadora");

	private readonly List<Action> licenseObservers = new List<Action>();

	private readonly CancellationTokenSource licenseShutdown = new CancellationTokenSource();

	private DispatcherTimer? licenseTimer;

	private readonly DateTimeOffset licenseClockStart = DateTimeOffset.UtcNow;

	private readonly Stopwatch licenseClock = Stopwatch.StartNew();

	private readonly Book book = new Book();

	private DataTable table = new DataTable();

	private int activeSheet;

	private bool formulaEdit;

	private bool autoSave = true;

	private bool cutPending;

	private bool refreshingRibbon;

	private bool applyingSelection;

	private bool restoringHistory;

	private bool gridlinesVisible = true;

	private bool gridCellEditing;

	private string? pendingNavigation;

	private string? currentWorkbookPath;

	private string? lastMouseReference;

	private string? lastHistorySnapshot;

	private int? formulaTargetRow;

	private int? formulaTargetCol;

	private int? formulaReferenceTextStart;

	private (int row, int col)? shiftAnchor;

	private (int row, int col)? formulaMouseReferenceAnchor;

	private (int top, int left, int bottom, int right)? formulaReferenceRange;

	private double zoom = 1.0;

	private int nextPendingCellWriteId;

	private readonly Dictionary<int, PendingCellWrite> pendingCellWrites = new Dictionary<int, PendingCellWrite>();

	private List<(int row, int col)> lastSelection = new List<(int, int)>();

	private readonly List<string> undoHistory = new List<string>();

	private readonly List<string> redoHistory = new List<string>();

	private int copiedTop;

	private int copiedLeft;

	private string? copiedSheet;

	private List<List<string>>? copiedCells;

	private AdornerLayer? copyAdornerLayer;

	private CopyMarchingAdorner? copyAdorner;

	private CopyMarchingAdorner? formulaReferenceAdorner;

	private ComboBox? ribbonFontControl;

	private ComboBox? ribbonFontSizeControl;

	private ComboBox? ribbonNumberControl;

	private Border? ribbonFontColorBar;

	private Border? ribbonFillColorBar;

	private TextBlock? ribbonFontColorGlyph;

	private TextBox? autocompleteEditor;

	private Popup? autocompletePopup;

	private ListBox? autocompleteList;

	private int autocompleteRow = -1;

	private int autocompleteCol = -1;

	private const string FreeSyncNotice = "Plan Gratis: la sincronización puede dejar de estar disponible en este plan. Tus libros locales se conservan; guardá copias de respaldo.";

	private TrialService? trialService;

	private bool trialInitialized;

	private bool trialClosing;

	private bool committingTrialEdit;

	private DispatcherTimer? trialTimer;

	private Window? trialLock;

	private TrialView trialView = new TrialView(Allowed: true, DateTimeOffset.MaxValue, "Prueba gratis de 5 días");

	private static readonly string[] IndexedXlsxColors = new string[56]
	{
		"#000000", "#FFFFFF", "#FF0000", "#00FF00", "#0000FF", "#FFFF00", "#FF00FF", "#00FFFF", "#800000", "#008000",
		"#000080", "#808000", "#800080", "#008080", "#C0C0C0", "#808080", "#9999FF", "#993366", "#FFFFCC", "#CCFFFF",
		"#660066", "#FF8080", "#0066CC", "#CCCCFF", "#000080", "#FF00FF", "#FFFF00", "#00FFFF", "#800080", "#800000",
		"#008080", "#0000FF", "#00CCFF", "#CCFFFF", "#CCFFCC", "#FFFF99", "#99CCFF", "#FF99CC", "#CC99FF", "#FFCC99",
		"#3366FF", "#33CCCC", "#99CC00", "#FFCC00", "#FF9900", "#FF6600", "#666699", "#969696", "#003366", "#339966",
		"#003300", "#333300", "#993300", "#993366", "#333399", "#333333"
	};

	private static Version InstalledVersion => typeof(MainWindow).Assembly.GetName().Version ?? new Version(1, 0, 0);

	private string CloudStatePath => System.IO.Path.Combine(DataDirectory, "cloud-sync.json");

	private DateTimeOffset LicenseNow
	{
		get
		{
			if (!(DateTimeOffset.UtcNow > licenseClockStart + licenseClock.Elapsed))
			{
				return licenseClockStart + licenseClock.Elapsed;
			}
			return DateTimeOffset.UtcNow;
		}
	}

	private bool HasPaidLicense
	{
		get
		{
			if (licenseView.IsActive)
			{
				if (licenseView.ValidUntil.HasValue)
				{
					DateTimeOffset licenseNow = LicenseNow;
					DateTimeOffset? validUntil = licenseView.ValidUntil;
					return licenseNow < validUntil;
				}
				return true;
			}
			return false;
		}
	}

	private string DataDirectory
	{
		get
		{
			string environmentVariable = Environment.GetEnvironmentVariable("GOZT_EXCEL_DATA_DIR");
			if (environmentVariable == null || environmentVariable.Length <= 0)
			{
				return System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "GOZT", "GOZT Excel Prototype");
			}
			return System.IO.Path.GetFullPath(environmentVariable);
		}
	}

	private string AutoPath => System.IO.Path.Combine(DataDirectory, "recovery.json");

	private string DriveSettingsPath => System.IO.Path.Combine(DataDirectory, "google-drive.json");

	private string RecentWorkbooksPath => System.IO.Path.Combine(DataDirectory, "recent-workbooks.json");

	private string BooksDirectory => System.IO.Path.Combine(DataDirectory, "Books");

	private bool CanUseApp
	{
		get
		{
			if (!committingTrialEdit && trialInitialized && !HasPaidLicense)
			{
				return trialService?.Peek().Allowed ?? false;
			}
			return true;
		}
	}

	private string TrialStatus => trialView.Message;

	private void StartUpdateChecks()
	{
		if (updateTimer == null && !(Environment.GetEnvironmentVariable("GEXE_SKIP_UPDATE_CHECK") == "1"))
		{
			updateTimer = new DispatcherTimer
			{
				Interval = TimeSpan.FromHours(4)
			};
			updateTimer.Tick += async (object? _, EventArgs _) =>
			{
				await CheckUpdatesAsync();
			};
			Closed += (object? _, EventArgs _) =>
			{
				updateTimer.Stop();
				updateShutdown.Cancel();
			};
			updateTimer.Start();
			CheckUpdatesAsync();
		}
	}

	private async Task CheckUpdatesAsync()
	{
		if (checkingUpdates)
		{
			return;
		}
		checkingUpdates = true;
		updateStatus = "Buscando actualizaciones…";
		RefreshUpdateControls();
		try
		{
			string path = System.IO.Path.Combine(AppContext.BaseDirectory, "update-settings.json");
			if (!File.Exists(path))
			{
				updateStatus = "El canal de actualizaciones todavía no está configurado.";
				return;
			}
			using JsonDocument settings = JsonDocument.Parse(File.ReadAllText(path));
			string repository = settings.RootElement.GetProperty("repository").GetString() ?? "";
			using CancellationTokenSource timeout = CancellationTokenSource.CreateLinkedTokenSource(updateShutdown.Token);
			timeout.CancelAfter(TimeSpan.FromSeconds(8L));
			availableUpdate = await new AppUpdateService(UpdateHttp, repository).CheckAsync(InstalledVersion, timeout.Token);
			updateStatus = (((object)availableUpdate == null) ? ("GEXE " + InstalledVersion.ToString(3) + " · no hay una versión más nueva publicada.") : ("GEXE " + availableUpdate.Version + " está disponible. Descargala para actualizar."));
		}
		catch (Exception)
		{
			updateStatus = "No se pudo consultar la actualización. Podés seguir trabajando y volver a intentarlo.";
		}
		finally
		{
			checkingUpdates = false;
			RefreshUpdateControls();
		}
	}

	private void RefreshUpdateControls()
	{
		UpdateAppButton.Visibility = (((object)availableUpdate == null) ? Visibility.Collapsed : Visibility.Visible);
		UpdateAppButton.ToolTip = updateStatus;
		UpdateHeaderLayout();
		Action[] array = updateObservers.ToArray();
		for (int i = 0; i < array.Length; i++)
		{
			array[i]();
		}
	}

	private void DownloadAvailableUpdate()
	{
		if ((object)availableUpdate == null)
		{
			return;
		}
		try
		{
			Process.Start(new ProcessStartInfo(availableUpdate.DownloadUrl)
			{
				UseShellExecute = true
			});
		}
		catch
		{
			MessageBox.Show("No se pudo abrir la descarga. Volvé a intentarlo desde Ayuda → Actualizaciones.", "GEXE");
		}
	}

	private Border BuildUpdateCard(Window owner)
	{
		StackPanel stackPanel = new StackPanel();
		stackPanel.Children.Add(new TextBlock
		{
			Text = "Actualizaciones de GEXE",
			FontWeight = FontWeights.SemiBold,
			FontSize = 16.0,
			Foreground = new SolidColorBrush(Color.FromRgb(33, 115, 70))
		});
		TextBlock status = new TextBlock
		{
			Name = "AppUpdateStatus",
			TextWrapping = TextWrapping.Wrap,
			Margin = new Thickness(0.0, 7.0, 0.0, 8.0)
		};
		stackPanel.Children.Add(status);
		WrapPanel wrapPanel = new WrapPanel();
		Button check = new Button
		{
			Name = "CheckAppUpdatesButton",
			Content = "Buscar actualizaciones",
			Padding = new Thickness(12.0, 6.0, 12.0, 6.0),
			Margin = new Thickness(0.0, 0.0, 8.0, 0.0)
		};
		Button download = new Button
		{
			Name = "DownloadAppUpdateButton",
			Content = "Descargar actualización",
			Padding = new Thickness(12.0, 6.0, 12.0, 6.0)
		};
		check.Click += async (object _, RoutedEventArgs _) =>
		{
			await CheckUpdatesAsync();
		};
		download.Click += (object _, RoutedEventArgs _) =>
		{
			DownloadAvailableUpdate();
		};
		wrapPanel.Children.Add(check);
		wrapPanel.Children.Add(download);
		stackPanel.Children.Add(wrapPanel);
		TextBlock detail = new TextBlock
		{
			TextWrapping = TextWrapping.Wrap,
			Margin = new Thickness(0.0, 8.0, 0.0, 0.0),
			Foreground = Brushes.DimGray
		};
		stackPanel.Children.Add(detail);
		Refresh();
		updateObservers.Add(Refresh);
		owner.Closed += (object? _, EventArgs _) =>
		{
			updateObservers.Remove(Refresh);
		};
		return new Border
		{
			Child = stackPanel,
			Background = Brushes.White,
			Padding = new Thickness(18.0),
			Margin = new Thickness(0.0, 0.0, 0.0, 18.0),
			BorderBrush = new SolidColorBrush(Color.FromRgb(210, 220, 214)),
			BorderThickness = new Thickness(1.0),
			CornerRadius = new CornerRadius(4.0)
		};
		void Refresh()
		{
			status.Text = updateStatus;
			check.IsEnabled = !checkingUpdates;
			download.Visibility = (((object)availableUpdate == null) ? Visibility.Collapsed : Visibility.Visible);
			detail.Text = (((object)availableUpdate == null) ? "Te avisamos aquí cuando se publique una nueva versión." : (availableUpdate.Notes + "\nExtraé el ZIP, cerrá GEXE y ejecutá el instalador. Tus libros locales se conservan."));
		}
	}

	private void UpdateApp_Click(object sender, RoutedEventArgs e)
	{
		ShowAppUpdates();
	}

	private void ShowAppUpdates()
	{
		Window window = new Window
		{
			Title = "GEXE · Actualizaciones",
			Owner = this,
			Width = 560.0,
			Height = 330.0,
			MinWidth = 450.0,
			MinHeight = 260.0,
			WindowStartupLocation = WindowStartupLocation.CenterOwner,
			Background = Brushes.White
		};
		window.Content = new ScrollViewer
		{
			Content = BuildUpdateCard(window),
			VerticalScrollBarVisibility = ScrollBarVisibility.Auto
		};
		window.Loaded += async (object _, RoutedEventArgs _) =>
		{
			await CheckUpdatesAsync();
		};
		window.ShowDialog();
	}

	private string CloudCachePath(string id)
	{
		return System.IO.Path.Combine(BooksDirectory, "Google-" + id + ".gexe");
	}

	private CloudBinding GetCloudBinding()
	{
		if (!Guid.TryParse(book.SyncId, out var _))
		{
			book.SyncId = Guid.NewGuid().ToString("N");
		}
		if (!cloudBindings.TryGetValue(book.SyncId, out CloudBinding value))
		{
			value = (cloudBindings[book.SyncId] = new CloudBinding());
		}
		return value;
	}

	private void SaveCloudBindings()
	{
		Directory.CreateDirectory(DataDirectory);
		File.WriteAllText(CloudStatePath + ".tmp", JsonSerializer.Serialize(cloudBindings));
		File.Move(CloudStatePath + ".tmp", CloudStatePath, overwrite: true);
	}

	private void CloudBookChanged()
	{
		if (!applyingCloud)
		{
			cloudLastEdit = DateTime.UtcNow;
		}
	}

	private static string CloudHash(byte[] bytes)
	{
		return Convert.ToHexString(SHA256.HashData(bytes));
	}

	private string? LoadBundledGoogleClientId()
	{
		string path = System.IO.Path.Combine(AppContext.BaseDirectory, "google-client.json");
		if (!File.Exists(path))
		{
			return null;
		}
		using JsonDocument jsonDocument = JsonDocument.Parse(File.ReadAllText(path));
		return jsonDocument.RootElement.GetProperty("clientId").GetString();
	}

	private string? LoadBundledGoogleClientSecret()
	{
		string path = System.IO.Path.Combine(AppContext.BaseDirectory, "google-client.json");
		if (!File.Exists(path))
		{
			return null;
		}
		using JsonDocument jsonDocument = JsonDocument.Parse(File.ReadAllText(path));
		JsonElement value;
		return jsonDocument.RootElement.TryGetProperty("clientSecret", out value) ? value.GetString() : null;
	}

	private void StartCloudSync()
	{
		if (cloudTimer != null)
		{
			cloudTimer.Start();
			return;
		}
		try
		{
			if (File.Exists(CloudStatePath))
			{
				cloudBindings = JsonSerializer.Deserialize<Dictionary<string, CloudBinding>>(File.ReadAllText(CloudStatePath)) ?? new Dictionary<string, CloudBinding>();
			}
		}
		catch
		{
			SetCloudStatus("Revisá la configuración de sincronización");
		}
		if (cloudDrive == null)
		{
			cloudDrive = GoogleDriveSync.Load(DriveSettingsPath);
		}
		cloudTimer = new DispatcherTimer
		{
			Interval = TimeSpan.FromSeconds(10L)
		};
		cloudTimer.Tick += async (object? _, EventArgs _) =>
		{
			if (DateTime.UtcNow >= nextCloudAttempt)
			{
				await SyncCloudAsync();
			}
		};
		Closing += CloudWindowClosing;
		Closed += (object? _, EventArgs _) =>
		{
			cloudTimer.Stop();
		};
		cloudTimer.Start();
	}

	private void SetCloudStatus(string text)
	{
		SaveStatus.Text = text;
		GoogleButton.ToolTip = text;
		AccountBadge.ToolTip = text;
	}

	internal static string CloudDecision(string localHash, string baseHash, string baseHead, IReadOnlyList<DriveSnapshot> heads)
	{
		if (heads.Count > 1)
		{
			return "conflict";
		}
		if (heads.Count == 0)
		{
			return "upload";
		}
		if (baseHead.Length == 0)
		{
			return "compare";
		}
		bool flag = localHash != baseHash;
		if (!(heads[0].Id == baseHead))
		{
			if (!flag)
			{
				return "download";
			}
			return "conflict";
		}
		if (!flag)
		{
			return "idle";
		}
		return "upload";
	}

	private async Task SyncCloudAsync(CancellationToken cancellationToken = default(CancellationToken), bool force = false)
	{
		if (!CanUseApp || cloudBusy || cloudDrive == null || !autoSave || !IsVisible || OwnedWindows.Count > 0 || gridCellEditing || FormulaBox.IsKeyboardFocusWithin)
		{
			return;
		}
		CloudBinding binding = GetCloudBinding();
		if (!binding.Enabled || binding.Conflict || (!force && DateTime.UtcNow - cloudLastEdit < TimeSpan.FromSeconds(2L)))
		{
			return;
		}
		cloudBusy = true;
		cloudIdle = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
		string id = this.book.SyncId;
		try
		{
			using CancellationTokenSource timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
			timeout.CancelAfter(TimeSpan.FromSeconds(30L));
			DriveSnapshots store = cloudDrive.Snapshots();
			List<DriveSnapshot> heads = DriveSnapshots.Heads((await store.ListAsync(timeout.Token)).Where((DriveSnapshot s) => s.BookId == id));
			if (!CanUseApp || this.book.SyncId != id || !binding.Enabled)
			{
				return;
			}
			byte[] bytes = JsonSerializer.SerializeToUtf8Bytes(this.book);
			string hash = CloudHash(bytes);
			string text = CloudDecision(hash, binding.Hash, binding.Head, heads);
			if (text == "compare")
			{
				Book book = JsonSerializer.Deserialize<Book>(await store.DownloadAsync(heads[0], timeout.Token));
				if (book == null || CloudHash(JsonSerializer.SerializeToUtf8Bytes(book)) != hash)
				{
					text = "conflict";
				}
				else
				{
					binding.Head = heads[0].Id;
					binding.Hash = hash;
					text = "idle";
				}
			}
			if (!CanUseApp || this.book.SyncId != id || !binding.Enabled)
			{
				return;
			}
			switch (text)
			{
			case "conflict":
				binding.Conflict = true;
				SaveCloudBindings();
				SetCloudStatus("Hay cambios en dos equipos · conservamos ambas copias");
				StatusText.Text = "Google: abrí Compartir para conservar tu copia como otro libro o elegir una versión de Google.";
				return;
			case "upload":
				SetCloudStatus("Guardando en Google…");
				binding.Head = (await store.AppendAsync(id, heads.FirstOrDefault()?.Id ?? "", this.book.Title, bytes, timeout.Token)).Id;
				binding.Hash = hash;
				Directory.CreateDirectory(BooksDirectory);
				File.WriteAllBytes(CloudCachePath(id), bytes);
				break;
			case "download":
			{
				byte[] bytes2 = await store.DownloadAsync(heads[0], timeout.Token);
				if (!CanUseApp || this.book.SyncId != id || !binding.Enabled || !autoSave || !IsVisible || OwnedWindows.Count > 0 || gridCellEditing || FormulaBox.IsKeyboardFocusWithin || CloudHash(JsonSerializer.SerializeToUtf8Bytes(this.book)) != hash)
				{
					return;
				}
				ApplyCloudBook(bytes2, id);
				binding.Head = heads[0].Id;
				binding.Hash = CloudHash(JsonSerializer.SerializeToUtf8Bytes(this.book));
				break;
			}
			}
			SaveCloudBindings();
			cloudFailures = 0;
			nextCloudAttempt = DateTime.MinValue;
			if (this.book.SyncId == id)
			{
				SetCloudStatus((CloudHash(JsonSerializer.SerializeToUtf8Bytes(this.book)) == binding.Hash) ? ("Google · sincronizado " + DateTime.Now.ToString("HH:mm:ss")) : "Google · cambios pendientes");
			}
		}
		catch (Exception ex)
		{
			cloudFailures = Math.Min(cloudFailures + 1, 5);
			nextCloudAttempt = DateTime.UtcNow.AddSeconds(Math.Min(120.0, 10.0 * Math.Pow(2.0, cloudFailures - 1)));
			SetCloudStatus("Google pendiente · tus cambios siguen guardados aquí");
			GoogleButton.ToolTip = "Se reintentará automáticamente. " + ((ex is OperationCanceledException) ? "La conexión tardó demasiado." : ex.Message);
		}
		finally
		{
			cloudBusy = false;
			cloudIdle?.TrySetResult();
		}
	}

	private async void CloudWindowClosing(object? sender, CancelEventArgs e)
	{
		if (cloudClosing)
		{
			return;
		}
		CommitPendingEditForHistory();
		CommitTable();
		Persist();
		if (cloudDrive == null || !GetCloudBinding().Enabled || GetCloudBinding().Conflict)
		{
			return;
		}
		e.Cancel = true;
		cloudClosing = true;
		cloudTimer?.Stop();
		try
		{
			using CancellationTokenSource timeout = new CancellationTokenSource(TimeSpan.FromSeconds(8L));
			if (cloudBusy && cloudIdle != null)
			{
				await cloudIdle.Task.WaitAsync(timeout.Token);
			}
			await SyncCloudAsync(timeout.Token, force: true);
		}
		catch (OperationCanceledException)
		{
			SetCloudStatus("Guardado local · Google se reintentará al abrir");
		}
		finally
		{
			Close();
		}
	}

	private async Task ImportLegacyDriveAsync()
	{
		if (cloudDrive == null || cloudBusy)
		{
			return;
		}
		cloudBusy = true;
		try
		{
			using CancellationTokenSource timeout = new CancellationTokenSource(TimeSpan.FromSeconds(30L));
			string before = JsonSerializer.Serialize(this.book);
			byte[] array = await cloudDrive.DownloadWorkbookAsync(timeout.Token);
			if (gridCellEditing || FormulaBox.IsKeyboardFocusWithin || before != JsonSerializer.Serialize(this.book))
			{
				throw new InvalidOperationException("El libro local cambió. Volvé a importar el libro anterior.");
			}
			Book book = JsonSerializer.Deserialize<Book>(array);
			if (book == null || book.Sheets.Count == 0)
			{
				throw new InvalidDataException("El libro anterior no contiene hojas.");
			}
			book.SyncId = Guid.NewGuid().ToString("N");
			CommitTable();
			Persist();
			ApplyCloudBook(JsonSerializer.SerializeToUtf8Bytes(book), book.SyncId);
			SetCloudStatus("Libro anterior importado · activá la sincronización automática");
		}
		finally
		{
			cloudBusy = false;
		}
	}

	private void ApplyCloudBook(byte[] bytes, string expectedId)
	{
		Book book = JsonSerializer.Deserialize<Book>(bytes);
		if (book == null || book.Sheets.Count == 0 || book.SyncId != expectedId || !Guid.TryParse(book.SyncId, out var _))
		{
			throw new InvalidDataException("El libro de Google no es válido.");
		}
		Directory.CreateDirectory(DataDirectory);
		if (File.Exists(AutoPath))
		{
			File.Copy(AutoPath, AutoPath + ".before-cloud-" + Guid.NewGuid().ToString("N") + ".bak");
		}
		applyingCloud = true;
		try
		{
			this.book.SyncId = book.SyncId;
			this.book.Title = book.Title;
			this.book.Sheets = book.Sheets;
			activeSheet = Math.Clamp(book.Active, 0, this.book.Sheets.Count - 1);
			this.book.Active = activeSheet;
			lastSelection = new List<(int, int)>();
			WorkbookTitle.Text = this.book.Title;
			currentWorkbookPath = CloudCachePath(this.book.SyncId);
			RenderSheet();
			RenderTabs();
			ResetHistory();
			Directory.CreateDirectory(BooksDirectory);
			byte[] bytes2 = JsonSerializer.SerializeToUtf8Bytes(this.book);
			File.WriteAllBytes(AutoPath, bytes2);
			File.WriteAllBytes(currentWorkbookPath, bytes2);
			RememberRecentWorkbook(currentWorkbookPath);
		}
		finally
		{
			applyingCloud = false;
		}
	}

	private async Task PickCloudBookAsync()
	{
		if (cloudBusy)
		{
			throw new InvalidOperationException("Esperá a que termine la sincronización actual.");
		}
		if (cloudDrive == null)
		{
			return;
		}
		cloudBusy = true;
		try
		{
			using CancellationTokenSource timeout = new CancellationTokenSource(TimeSpan.FromSeconds(30L));
			DriveSnapshots store = cloudDrive.Snapshots();
			List<DriveSnapshot> source = await store.ListAsync(timeout.Token);
			timeout.CancelAfter(Timeout.InfiniteTimeSpan);
			List<DriveSnapshot> heads = (from s in (from s in source
					group s by s.BookId).SelectMany((IGrouping<string, DriveSnapshot> g) => DriveSnapshots.Heads(g))
				orderby s.Modified descending
				select s).ToList();
			if (heads.Count == 0)
			{
				MessageBox.Show("Todavía no hay libros con sincronización automática. Activala primero en la computadora que tiene el libro.", "Google · GEXE");
				return;
			}
			Window dialog = new Window
			{
				Title = "Mis libros de Google",
				Owner = this,
				Width = 650.0,
				Height = 440.0,
				WindowStartupLocation = WindowStartupLocation.CenterOwner
			};
			DockPanel dockPanel = new DockPanel
			{
				Margin = new Thickness(16.0)
			};
			TextBlock element = new TextBlock
			{
				Text = "Elegí un libro o una versión. El libro local actual se conserva en una copia de recuperación.",
				TextWrapping = TextWrapping.Wrap,
				Margin = new Thickness(0.0, 0.0, 0.0, 12.0)
			};
			DockPanel.SetDock(element, Dock.Top);
			dockPanel.Children.Add(element);
			Button button = new Button
			{
				Content = "Abrir y sincronizar automáticamente",
				Padding = new Thickness(12.0, 7.0, 12.0, 7.0),
				Margin = new Thickness(0.0, 12.0, 0.0, 0.0)
			};
			DockPanel.SetDock(button, Dock.Bottom);
			dockPanel.Children.Add(button);
			ListBox list = new ListBox();
			foreach (DriveSnapshot item in heads)
			{
				list.Items.Add(new ListBoxItem
				{
					Content = item.Name + "   ·   " + item.Modified,
					Tag = item,
					Padding = new Thickness(8.0)
				});
			}
			dockPanel.Children.Add(list);
			DriveSnapshot chosen = null;
			button.Click += (object _, RoutedEventArgs _) =>
			{
				if (list.SelectedItem is ListBoxItem listBoxItem)
				{
					chosen = (DriveSnapshot)listBoxItem.Tag;
					dialog.Close();
				}
			};
			dialog.Content = dockPanel;
			dialog.ShowDialog();
			if ((object)chosen == null)
			{
				return;
			}
			CommitTable();
			Persist();
			string before = JsonSerializer.Serialize(book);
			timeout.CancelAfter(TimeSpan.FromSeconds(30L));
			byte[] bytes = await store.DownloadAsync(chosen, timeout.Token);
			if (gridCellEditing || FormulaBox.IsKeyboardFocusWithin || before != JsonSerializer.Serialize(book))
			{
				throw new InvalidOperationException("El libro local cambió mientras se descargaba. Volvé a elegir el libro de Google.");
			}
			ApplyCloudBook(bytes, chosen.BookId);
			CloudBinding cloudBinding = GetCloudBinding();
			cloudBinding.Enabled = true;
			cloudBinding.Head = chosen.Id;
			cloudBinding.Hash = CloudHash(JsonSerializer.SerializeToUtf8Bytes(book));
			cloudBinding.Conflict = Enumerable.Count(heads, (DriveSnapshot h) => h.BookId == chosen.BookId) > 1;
			SaveCloudBindings();
			SetCloudStatus(cloudBinding.Conflict ? "Versión abierta · hay otras copias, sincronización pausada" : "Google · libro abierto y sincronización activa");
		}
		finally
		{
			cloudBusy = false;
		}
	}

	[DllImport("dwmapi.dll")]
	private static extern int DwmSetWindowAttribute(nint window, int attribute, ref int value, int size);

	private void ApplyGreenWindowCaption()
	{
		int value = 4616993;
		int value2 = 16777215;
		nint handle = new WindowInteropHelper(this).Handle;
		DwmSetWindowAttribute(handle, 35, ref value, 4);
		DwmSetWindowAttribute(handle, 36, ref value2, 4);
	}

	private void UpdateHeaderLayout()
	{
		double num = ((FrameworkElement)Content).ActualWidth - (double)((UpdateAppButton.Visibility == Visibility.Visible) ? 120 : 0);
		StatusText.Visibility = ((!(num >= 900.0)) ? Visibility.Collapsed : Visibility.Visible);
		SearchBox.Visibility = ((!(num >= 1280.0)) ? Visibility.Collapsed : Visibility.Visible);
		CommentsButton.Visibility = ((!(num >= 1450.0)) ? Visibility.Collapsed : Visibility.Visible);
		PlanButton.Visibility = ((!(num >= 1120.0)) ? Visibility.Collapsed : Visibility.Visible);
		SaveStatus.Visibility = ((!(num >= 1000.0)) ? Visibility.Collapsed : Visibility.Visible);
		AutoSaveLabel.Visibility = ((!(num >= 850.0)) ? Visibility.Collapsed : Visibility.Visible);
		WorkbookTitle.MaxWidth = ((num >= 1000.0) ? 180 : 110);
	}

	private void ZoomOut_Click(object sender, RoutedEventArgs e)
	{
		ChangeZoom(-0.1);
	}

	private void ZoomIn_Click(object sender, RoutedEventArgs e)
	{
		ChangeZoom(0.1);
	}

	private void ZoomReset_Click(object sender, RoutedEventArgs e)
	{
		ResetZoom();
	}

	internal static Uri PersonalCheckoutUri()
	{
		return new Uri("https://gozt-software.lemonsqueezy.com/checkout/buy/656714d7-29e3-418f-8f16-2f3c0f82e136", UriKind.Absolute);
	}

	internal static decimal PlanPriceUsd(string plan) => PlanPricing.PriceUsd(plan);

	internal static Uri? PlanCheckoutUri(string plan, string settingsPath)
	{
		PlanPriceUsd(plan);
		if (!File.Exists(settingsPath))
		{
			if (!(plan == "personal"))
			{
				return null;
			}
			return PersonalCheckoutUri();
		}
		using JsonDocument jsonDocument = JsonDocument.Parse(File.ReadAllText(settingsPath));
		if (!jsonDocument.RootElement.TryGetProperty(plan, out var value) || value.ValueKind == JsonValueKind.Null)
		{
			return null;
		}
		string text = value.GetString() ?? "";
		if (text.Length == 0)
		{
			return null;
		}
		if (!Uri.TryCreate(text, UriKind.Absolute, out Uri result) || result.Scheme != "https" || result.Host != "gozt-software.lemonsqueezy.com" || !result.IsDefaultPort || result.UserInfo.Length > 0 || !result.AbsolutePath.StartsWith("/checkout/buy/", StringComparison.Ordinal) || result.Query.Length > 0 || result.Fragment.Length > 0 || !Guid.TryParse(result.AbsolutePath.Substring("/checkout/buy/".Length), out var _))
		{
			throw new InvalidDataException("El enlace de pago del plan no es válido.");
		}
		if (plan == "one_time" && jsonDocument.RootElement.TryGetProperty("personal", out var value2) && string.Equals(value2.GetString(), text, StringComparison.OrdinalIgnoreCase))
		{
			throw new InvalidDataException("Cada opción necesita su propio enlace de pago.");
		}
		return result;
	}

	private void OpenPersonalCheckout()
	{
		OpenPlanCheckout("personal");
	}

	private void OpenPlanCheckout(string plan)
	{
		try
		{
			Uri uri = PlanCheckoutUri(plan, System.IO.Path.Combine(AppContext.BaseDirectory, "lemon-checkout.json"));
			if ((object)uri == null)
			{
				MessageBox.Show("El pago único todavía no está disponible. Volvé a intentarlo más tarde.", "GEXE · Pago pendiente", MessageBoxButton.OK, MessageBoxImage.Asterisk);
				return;
			}
			Process.Start(new ProcessStartInfo(uri.AbsoluteUri)
			{
				UseShellExecute = true
			});
		}
		catch (Exception)
		{
			MessageBox.Show("No se pudo abrir el pago. Revisá el enlace configurado y volvé a intentar desde Planes y suscripción.", "GEXE · Pago", MessageBoxButton.OK, MessageBoxImage.Asterisk);
		}
	}

	private LicenseService GetLicenseService()
	{
		if (licenseService != null)
		{
			return licenseService;
		}
		using Stream utf8Json = typeof(MainWindow).Assembly.GetManifestResourceStream("GEXE.license-product.json") ?? throw new InvalidDataException("Falta la configuración del producto GEXE.");
		LicenseProductPolicy policy = JsonSerializer.Deserialize<LicenseProductPolicy>(utf8Json, new JsonSerializerOptions
		{
			PropertyNameCaseInsensitive = true
		}) ?? new LicenseProductPolicy();
		return licenseService = new LicenseService(LicenseHttp, new ProtectedLicenseStorage(System.IO.Path.Combine(DataDirectory, "license-v1.dat")), policy, LicenseDevice.Fingerprint(DataDirectory), typeof(MainWindow).Assembly.GetName().Version?.Major ?? 1);
	}

	private void SetLicenseView(LicenseView view)
	{
		licenseView = view;
		Action[] array = licenseObservers.ToArray();
		for (int i = 0; i < array.Length; i++)
		{
			array[i]();
		}
		if (trialInitialized)
		{
			Dispatcher.BeginInvoke(new Action(CheckTrialAccess));
		}
	}

	private void ObserveLicense(FrameworkElement element, Action refresh)
	{
		bool attached = false;
		element.Loaded += (object _, RoutedEventArgs _) =>
		{
			if (!attached)
			{
				licenseObservers.Add(refresh);
				attached = true;
			}
			refresh();
		};
		element.Unloaded += (object _, RoutedEventArgs _) =>
		{
			if (attached)
			{
				licenseObservers.Remove(refresh);
				attached = false;
			}
		};
		refresh();
	}

	private void StartLicenseChecks()
	{
		if (licenseTimer == null)
		{
			try
			{
				SetLicenseView(GetLicenseService().ReadLocal());
			}
			catch
			{
				SetLicenseView(new LicenseView(IsActive: false, "No se pudo leer la licencia guardada. Tus libros siguen disponibles."));
			}
			licenseTimer = new DispatcherTimer
			{
				Interval = TimeSpan.FromHours(6)
			};
			licenseTimer.Tick += async (object? _, EventArgs _) =>
			{
				await RefreshLicenseViewAsync();
			};
			Closed += (object? _, EventArgs _) =>
			{
				licenseTimer.Stop();
				licenseShutdown.Cancel();
			};
			if (Environment.GetEnvironmentVariable("GEXE_SKIP_LICENSE_CHECKS") != "1")
			{
				licenseTimer.Start();
				RefreshLicenseViewAsync();
			}
		}
	}

	private async Task RefreshLicenseViewAsync()
	{
		try
		{
			LicenseService licenseService = GetLicenseService();
			if (licenseService.HasSavedLicense && licenseService.IsConfigured)
			{
				using CancellationTokenSource timeout = CancellationTokenSource.CreateLinkedTokenSource(licenseShutdown.Token);
				timeout.CancelAfter(TimeSpan.FromSeconds(15L));
				SetLicenseView(await licenseService.RefreshAsync(timeout.Token));
			}
		}
		catch
		{
			SetLicenseView(licenseView with
			{
				Message = "No se pudo comprobar la conexión de la licencia. Volvé a intentar desde Mi plan."
			});
		}
	}

	private Border BuildLicenseSummary(Window owner)
	{
		StackPanel stackPanel = new StackPanel();
		TextBlock status = new TextBlock
		{
			Name = "StartLicenseStatus",
			FontWeight = FontWeights.SemiBold,
			TextWrapping = TextWrapping.Wrap,
			FontSize = 15.0
		};
		stackPanel.Children.Add(status);
		Button button = new Button
		{
			Name = "StartActivateLicenseButton",
			Content = "Activar licencia",
			HorizontalAlignment = HorizontalAlignment.Left,
			Padding = new Thickness(12.0, 6.0, 12.0, 6.0),
			Margin = new Thickness(0.0, 10.0, 0.0, 0.0)
		};
		button.Click += (object _, RoutedEventArgs _) =>
		{
			ShowLicenseWindow(owner);
		};
		stackPanel.Children.Add(button);
		Border border = new Border
		{
			Child = stackPanel,
			Background = Brushes.White,
			Padding = new Thickness(18.0),
			Margin = new Thickness(0.0, 0.0, 0.0, 18.0),
			BorderBrush = new SolidColorBrush(Color.FromRgb(210, 220, 214)),
			BorderThickness = new Thickness(1.0),
			CornerRadius = new CornerRadius(4.0)
		};
		ObserveLicense(border, () =>
		{
			TextBlock textBlock = status;
			string text = ((!HasPaidLicense) ? TrialStatus : ((licenseView.Plan == "personal") ? "Tu plan: Mensual · licencia activa" : "Tu plan: Pago único · licencia activa"));
			textBlock.Text = text;
			button.Content = (HasPaidLicense ? "Ver mi licencia" : "Activar licencia");
		});
		return border;
	}

	private Border BuildLicensePanel()
	{
		StackPanel stackPanel = new StackPanel();
		stackPanel.Children.Add(new TextBlock
		{
			Text = "Mi licencia de GEXE",
			FontSize = 22.0,
			FontWeight = FontWeights.SemiBold
		});
		stackPanel.Children.Add(new TextBlock
		{
			Text = "Después de comprar el plan mensual o pago único, pegá la clave que recibiste con tu compra. Se comprobará por Internet y se activará esta computadora.",
			TextWrapping = TextWrapping.Wrap,
			Foreground = Brushes.DimGray,
			Margin = new Thickness(0.0, 12.0, 0.0, 12.0)
		});
		TextBlock state = new TextBlock
		{
			Name = "LicenseStateText",
			FontWeight = FontWeights.SemiBold,
			TextWrapping = TextWrapping.Wrap,
			Margin = new Thickness(0.0, 0.0, 0.0, 8.0)
		};
		stackPanel.Children.Add(state);
		TextBlock usage = new TextBlock
		{
			Name = "LicenseUsageText",
			Foreground = Brushes.DimGray,
			TextWrapping = TextWrapping.Wrap,
			Margin = new Thickness(0.0, 0.0, 0.0, 12.0)
		};
		stackPanel.Children.Add(usage);
		stackPanel.Children.Add(new TextBlock
		{
			Text = "Clave de licencia",
			Margin = new Thickness(0.0, 0.0, 0.0, 5.0)
		});
		PasswordBox key = new PasswordBox
		{
			Name = "LicenseKeyBox",
			MaxLength = 256,
			Padding = new Thickness(8.0),
			Height = 34.0
		};
		AutomationProperties.SetName(key, "Clave de licencia");
		stackPanel.Children.Add(key);
		WrapPanel wrapPanel = new WrapPanel
		{
			Margin = new Thickness(0.0, 12.0, 0.0, 12.0)
		};
		Button activate = new Button
		{
			Name = "ActivateLicenseButton",
			Content = "Activar en este equipo",
			Padding = new Thickness(12.0, 8.0, 12.0, 8.0),
			Margin = new Thickness(0.0, 0.0, 8.0, 8.0)
		};
		Button check = new Button
		{
			Name = "ValidateLicenseButton",
			Content = "Comprobar licencia",
			Padding = new Thickness(12.0, 8.0, 12.0, 8.0),
			Margin = new Thickness(0.0, 0.0, 8.0, 8.0)
		};
		Button remove = new Button
		{
			Name = "DeactivateLicenseButton",
			Content = "Quitar de este equipo",
			Padding = new Thickness(12.0, 8.0, 12.0, 8.0),
			Margin = new Thickness(0.0, 0.0, 0.0, 8.0)
		};
		wrapPanel.Children.Add(activate);
		wrapPanel.Children.Add(check);
		wrapPanel.Children.Add(remove);
		stackPanel.Children.Add(wrapPanel);
		TextBlock message = new TextBlock
		{
			Name = "LicenseActionMessage",
			TextWrapping = TextWrapping.Wrap,
			Foreground = Brushes.DimGray
		};
		stackPanel.Children.Add(message);
		stackPanel.Children.Add(new TextBlock
		{
			Text = "La licencia de pago único no vence y corresponde a GEXE 1.x. Puede activarse en hasta tres computadoras. Quitarla de este equipo libera una activación y conserva tus libros. El mensual requiere una suscripción vigente y una comprobación por Internet al menos cada 24 horas. Las futuras versiones principales y los servicios en línea se rigen por sus condiciones.",
			TextWrapping = TextWrapping.Wrap,
			Foreground = Brushes.DimGray,
			Margin = new Thickness(0.0, 14.0, 0.0, 0.0)
		});
		Border freeNotice = BuildFreeSyncNotice();
		stackPanel.Children.Add(freeNotice);
		Border border = new Border
		{
			Child = stackPanel,
			Padding = new Thickness(20.0),
			Background = Brushes.White
		};
		bool busy = false;
		activate.Click += async (object _, RoutedEventArgs _) =>
		{
			await Run((LicenseService service, CancellationToken ct) => service.ActivateAsync(key.Password, ct));
		};
		check.Click += async (object _, RoutedEventArgs _) =>
		{
			await Run((LicenseService service, CancellationToken ct) => service.RefreshAsync(ct));
		};
		remove.Click += async (object _, RoutedEventArgs _) =>
		{
			if (MessageBox.Show("¿Quitar la licencia de esta computadora y liberar su activación? Tus libros locales se conservan.", "GEXE · Licencia", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
			{
				await Run((LicenseService service, CancellationToken ct) => service.DeactivateAsync(ct));
			}
		};
		ObserveLicense(border, Refresh);
		return border;
		void Refresh()
		{
			bool flag = false;
			bool flag2 = false;
			try
			{
				LicenseService licenseService = GetLicenseService();
				flag = licenseService.HasSavedLicense;
				flag2 = licenseService.IsConfigured;
			}
			catch
			{
			}
			state.Text = licenseView.Message;
			usage.Text = (HasPaidLicense ? $"Activaciones utilizadas: {licenseView.SeatsUsed} de 3" : "");
			key.IsEnabled = !busy && !flag;
			activate.IsEnabled = (!busy && !flag) & flag2;
			check.IsEnabled = !busy & flag & flag2;
			remove.IsEnabled = !busy & flag;
			if (!flag2 && !busy)
			{
				message.Text = "Los cobros están en preparación. La página de pago está en modo de prueba y sus claves no activan esta versión pública. Tu prueba gratis dura cinco días.";
			}
			freeNotice.Visibility = (HasPaidLicense ? Visibility.Collapsed : Visibility.Visible);
		}
		async Task Run(Func<LicenseService, CancellationToken, Task<LicenseView>> action)
		{
			if (busy)
			{
				return;
			}
			busy = true;
			Refresh();
			message.Text = "Comprobando licencia…";
			try
			{
				using CancellationTokenSource timeout = CancellationTokenSource.CreateLinkedTokenSource(licenseShutdown.Token);
				timeout.CancelAfter(TimeSpan.FromSeconds(15L));
				LicenseView licenseView = await action(GetLicenseService(), timeout.Token);
				SetLicenseView(licenseView);
				message.Text = licenseView.Message;
				if (licenseView.IsActive)
				{
					key.Clear();
				}
			}
			catch (LicenseException ex)
			{
				message.Text = ex.Message;
			}
			catch (Exception ex2) when ((ex2 is CryptographicException || ex2 is IOException) ? true : false)
			{
				message.Text = "Windows no pudo guardar la licencia de forma protegida. Revisá el acceso a la carpeta de GEXE.";
			}
			catch
			{
				message.Text = "No se pudo completar la consulta. Revisá la conexión y volvé a intentar; no ingreses otra clave mientras la consulta esté pendiente.";
			}
			finally
			{
				busy = false;
				Refresh();
			}
		}
	}

	private void ShowLicenseWindow(Window owner)
	{
		Window window = new Window();
		window.Title = "GEXE · Activar licencia";
		window.Owner = owner;
		window.Width = 640.0;
		window.Height = 620.0;
		window.MinWidth = 480.0;
		window.MinHeight = 420.0;
		window.WindowStartupLocation = WindowStartupLocation.CenterOwner;
		window.Background = Brushes.White;
		window.Content = new ScrollViewer
		{
			Content = BuildLicensePanel(),
			VerticalScrollBarVisibility = ScrollBarVisibility.Auto
		};
		window.ShowDialog();
	}

	private bool IsManagedWorkbook(string path)
	{
		try
		{
			return System.IO.Path.GetFullPath(path).StartsWith(System.IO.Path.GetFullPath(BooksDirectory) + System.IO.Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase);
		}
		catch
		{
			return false;
		}
	}

	private void RememberRecentWorkbook(string path)
	{
		try
		{
			Directory.CreateDirectory(DataDirectory);
			List<string> list = (File.Exists(RecentWorkbooksPath) ? (JsonSerializer.Deserialize<List<string>>(File.ReadAllText(RecentWorkbooksPath)) ?? new List<string>()) : new List<string>());
			list.RemoveAll((string x) => string.Equals(x, path, StringComparison.OrdinalIgnoreCase));
			list.Insert(0, path);
			File.WriteAllText(RecentWorkbooksPath, JsonSerializer.Serialize(list.Take(12).ToList()));
		}
		catch
		{
		}
	}

	private void UpdateRecentWorkbookPath(string oldPath, string? newPath)
	{
		try
		{
			List<string> list = (File.Exists(RecentWorkbooksPath) ? (JsonSerializer.Deserialize<List<string>>(File.ReadAllText(RecentWorkbooksPath)) ?? new List<string>()) : new List<string>());
			list.RemoveAll((string x) => string.Equals(x, oldPath, StringComparison.OrdinalIgnoreCase) || (newPath != null && string.Equals(x, newPath, StringComparison.OrdinalIgnoreCase)));
			if (newPath != null)
			{
				list.Insert(0, newPath);
			}
			File.WriteAllText(RecentWorkbooksPath, JsonSerializer.Serialize(list.Take(12).ToList()));
		}
		catch
		{
		}
	}

	private void AttachWorkbookContextMenu(FrameworkElement target, Func<string> getPath, Window dialog, Action removeFromList)
	{
		ContextMenu menu = new ContextMenu();
		MenuItem menuItem = new MenuItem
		{
			Header = "Abrir"
		};
		menuItem.Click += (object _, RoutedEventArgs _) =>
		{
			string path = getPath();
			dialog.Close();
			OpenWorkbookFile(path);
		};
		menu.Items.Add(menuItem);
		bool managed = IsManagedWorkbook(getPath());
		MenuItem menuItem2 = new MenuItem
		{
			Header = (managed ? "Eliminar" : "Eliminar de recientes")
		};
		menuItem2.Click += (object _, RoutedEventArgs _) =>
		{
			string text = getPath();
			if (managed && MessageBox.Show("¿Eliminar «" + System.IO.Path.GetFileNameWithoutExtension(text) + "» de la biblioteca GOZT? Esta acción no se puede deshacer.", "Eliminar libro", MessageBoxButton.YesNo, MessageBoxImage.Exclamation) != MessageBoxResult.Yes)
			{
				return;
			}
			try
			{
				if (managed)
				{
					File.Delete(text);
				}
				UpdateRecentWorkbookPath(text, null);
				if (string.Equals(currentWorkbookPath, text, StringComparison.OrdinalIgnoreCase))
				{
					currentWorkbookPath = null;
					WorkbookTitle.Text = "Libro sin guardar";
				}
				removeFromList();
			}
			catch (Exception ex)
			{
				MessageBox.Show("No se pudo eliminar el libro: " + ex.Message, "GEXE", MessageBoxButton.OK, MessageBoxImage.Error);
			}
		};
		menu.Items.Add(menuItem2);
		MenuItem menuItem3 = new MenuItem
		{
			Header = "Compartir"
		};
		menuItem3.Click += (object _, RoutedEventArgs _) =>
		{
			string path = getPath();
			dialog.Close();
			OpenWorkbookFile(path);
			Drive_Click(this, new RoutedEventArgs());
		};
		menu.Items.Add(new Separator());
		menu.Items.Add(menuItem3);
		target.ContextMenu = menu;
		target.PreviewMouseRightButtonDown += (object _, MouseButtonEventArgs e) =>
		{
			menu.PlacementTarget = target;
			menu.Placement = PlacementMode.MousePoint;
			menu.IsOpen = true;
			e.Handled = true;
		};
	}

	private void AddRecentWorkbooks(StackPanel content, Window dialog)
	{
		List<string> source = new List<string>();
		try
		{
			if (File.Exists(RecentWorkbooksPath))
			{
				source = JsonSerializer.Deserialize<List<string>>(File.ReadAllText(RecentWorkbooksPath)) ?? new List<string>();
			}
		}
		catch
		{
		}
		List<string> list = source.Where(File.Exists).Take(8).ToList();
		bool flag = File.Exists(AutoPath);
		if (list.Count == 0 && !flag)
		{
			return;
		}
		content.Children.Add(new TextBlock
		{
			Text = "Libros recientes",
			FontSize = 17.0,
			FontWeight = FontWeights.SemiBold,
			Margin = new Thickness(0.0, 12.0, 0.0, 7.0),
			Foreground = new SolidColorBrush(Color.FromRgb(37, 50, 71))
		});
		if (flag)
		{
			Add("Libro actual · " + book.Sheets[Math.Clamp(book.Active, 0, book.Sheets.Count - 1)].Name, "Continuar con la recuperación automática local", () =>
			{
			});
		}
		foreach (string path in list)
		{
			Add(System.IO.Path.GetFileName(path) + "   ·   " + System.IO.Path.GetDirectoryName(path), path, () =>
			{
				OpenWorkbookFile(path);
			}, path);
		}
		void Add(string label, string tip, Action action, string? workbookPath = null)
		{
			Button button = new Button
			{
				Content = label,
				HorizontalContentAlignment = HorizontalAlignment.Left,
				Padding = new Thickness(10.0, 7.0, 10.0, 7.0),
				Margin = new Thickness(0.0, 2.0, 0.0, 2.0),
				Background = Brushes.White,
				BorderBrush = new SolidColorBrush(Color.FromRgb(226, 230, 235)),
				ToolTip = ((workbookPath == null) ? tip : (tip + " · clic derecho para opciones"))
			};
			button.Click += (object _, RoutedEventArgs _) =>
			{
				dialog.Close();
				action();
			};
			content.Children.Add(button);
			if (workbookPath != null)
			{
				AttachWorkbookContextMenu(button, () => workbookPath, dialog, () =>
				{
					content.Children.Remove(button);
				});
			}
		}
	}

	private void AddManagedBooks(StackPanel content, Window dialog)
	{
		Directory.CreateDirectory(BooksDirectory);
		List<string> list = Directory.GetFiles(BooksDirectory, "*.xlsx").Concat(Directory.GetFiles(BooksDirectory, "*.gexe")).OrderByDescending(File.GetLastWriteTime)
			.ToList();
		content.Children.Add(new TextBlock
		{
			Text = "Continuar libro guardado",
			FontSize = 17.0,
			FontWeight = FontWeights.SemiBold,
			Margin = new Thickness(0.0, 18.0, 0.0, 7.0),
			Foreground = new SolidColorBrush(Color.FromRgb(37, 50, 71))
		});
		if (list.Count == 0)
		{
			content.Children.Add(new TextBlock
			{
				Text = "Los libros que guardes desde GOZT aparecerán aquí.",
				Foreground = new SolidColorBrush(Color.FromRgb(120, 120, 120)),
				Margin = new Thickness(0.0, 0.0, 0.0, 8.0)
			});
			return;
		}
		foreach (string item in list)
		{
			string path = item;
			DockPanel row = new DockPanel
			{
				Margin = new Thickness(0.0, 2.0, 0.0, 2.0),
				LastChildFill = false,
				ToolTip = "Clic derecho sobre cualquier parte de la fila para abrir, eliminar o compartir"
			};
			Button open = new Button
			{
				Content = System.IO.Path.GetFileNameWithoutExtension(path),
				HorizontalContentAlignment = HorizontalAlignment.Left,
				Padding = new Thickness(10.0, 8.0, 10.0, 8.0),
				Background = Brushes.White,
				BorderBrush = new SolidColorBrush(Color.FromRgb(226, 230, 235)),
				MinWidth = 260.0,
				ToolTip = "Clic para abrir · clic derecho para opciones"
			};
			open.Click += (object _, RoutedEventArgs _) =>
			{
				dialog.Close();
				OpenWorkbookFile(path);
			};
			DockPanel.SetDock(open, Dock.Left);
			row.Children.Add(open);
			Button button = new Button
			{
				Content = "Renombrar",
				Padding = new Thickness(8.0, 6.0, 8.0, 6.0),
				Margin = new Thickness(5.0, 0.0, 0.0, 0.0),
				ToolTip = "Cambiar el nombre de este libro"
			};
			button.Click += (object _, RoutedEventArgs _) =>
			{
				string text = path;
				string text2 = PromptText("Renombrar libro", "Escribí el nuevo nombre:", System.IO.Path.GetFileNameWithoutExtension(path));
				if (!string.IsNullOrWhiteSpace(text2))
				{
					string text3 = System.IO.Path.Combine(BooksDirectory, SafeFileName(text2) + System.IO.Path.GetExtension(text));
					if (string.Equals(text, text3, StringComparison.OrdinalIgnoreCase))
					{
						MessageBox.Show("El libro ya tiene ese nombre.", "Renombrar libro", MessageBoxButton.OK, MessageBoxImage.Asterisk);
					}
					else
					{
						if (!File.Exists(text3))
						{
							try
							{
								File.Move(text, text3);
								path = text3;
								open.Content = System.IO.Path.GetFileNameWithoutExtension(text3);
								UpdateRecentWorkbookPath(text, text3);
								if (string.Equals(currentWorkbookPath, text, StringComparison.OrdinalIgnoreCase))
								{
									currentWorkbookPath = text3;
									WorkbookTitle.Text = System.IO.Path.GetFileNameWithoutExtension(text3);
								}
								StatusText.Text = "Libro renombrado: " + System.IO.Path.GetFileNameWithoutExtension(text3);
								return;
							}
							catch (Exception ex)
							{
								MessageBox.Show("No se pudo renombrar el libro: " + ex.Message, "GEXE", MessageBoxButton.OK, MessageBoxImage.Error);
								return;
							}
						}
						MessageBox.Show("Ya existe un libro con ese nombre.", "Renombrar libro", MessageBoxButton.OK, MessageBoxImage.Asterisk);
					}
				}
			};
			DockPanel.SetDock(button, Dock.Left);
			row.Children.Add(button);
			Button button2 = new Button
			{
				Content = "Eliminar",
				Padding = new Thickness(8.0, 6.0, 8.0, 6.0),
				Margin = new Thickness(5.0, 0.0, 0.0, 0.0),
				ToolTip = "Eliminar este libro de la biblioteca GOZT"
			};
			button2.Click += (object _, RoutedEventArgs _) =>
			{
				if (MessageBox.Show("¿Eliminar «" + System.IO.Path.GetFileNameWithoutExtension(path) + "» de la biblioteca GOZT? Esta acción no se puede deshacer.", "Eliminar libro", MessageBoxButton.YesNo, MessageBoxImage.Exclamation) != MessageBoxResult.Yes)
				{
					return;
				}
				try
				{
					File.Delete(path);
					UpdateRecentWorkbookPath(path, null);
					if (string.Equals(currentWorkbookPath, path, StringComparison.OrdinalIgnoreCase))
					{
						currentWorkbookPath = null;
						WorkbookTitle.Text = "Libro sin guardar";
					}
					content.Children.Remove(row);
				}
				catch (Exception ex)
				{
					MessageBox.Show("No se pudo eliminar el libro: " + ex.Message, "GEXE", MessageBoxButton.OK, MessageBoxImage.Error);
				}
			};
			DockPanel.SetDock(button2, Dock.Left);
			row.Children.Add(button2);
			AttachWorkbookContextMenu(row, () => path, dialog, () =>
			{
				content.Children.Remove(row);
			});
			content.Children.Add(row);
		}
	}

	private static string SafeFileName(string name)
	{
		char[] invalidFileNameChars = System.IO.Path.GetInvalidFileNameChars();
		foreach (char oldChar in invalidFileNameChars)
		{
			name = name.Replace(oldChar, '_');
		}
		name = name.Trim().TrimEnd('.');
		if (!string.IsNullOrWhiteSpace(name))
		{
			return name;
		}
		return "Libro-GOZT";
	}

	private void UpdateAccountBadge()
	{
		bool flag = GoogleDriveSync.Load(DriveSettingsPath) != null;
		GoogleButton.Content = (flag ? "Google · Sincronizar" : "Conectar Google");
		AccountBadge.Text = (flag ? "G✓" : "G");
		AccountBadge.ToolTip = (flag ? "Google Drive conectado en esta computadora" : "Google Drive no conectado");
	}

	private void MinimizeWindow_Click(object s, RoutedEventArgs e)
	{
		WindowState = WindowState.Minimized;
	}

	private void ToggleMaximize_Click(object s, RoutedEventArgs e)
	{
		ToggleWindowSize();
	}

	private void CloseWindow_Click(object s, RoutedEventArgs e)
	{
		Close();
	}

	private void MainWindow_SizeChanged(object? s, SizeChangedEventArgs e)
	{
		UpdateHeaderLayout();
	}

	private void AutoSave_Click(object s, RoutedEventArgs e)
	{
		autoSave = AutoSaveToggle.IsChecked == true;
		SaveStatus.Text = (autoSave ? "Autoguardado activado" : "Autoguardado pausado");
		if (autoSave)
		{
			Persist();
		}
	}

	private void SearchBox_GotFocus(object s, RoutedEventArgs e)
	{
		if (SearchBox.Text == "Buscar en la hoja")
		{
			SearchBox.Text = "";
			SearchBox.Foreground = new SolidColorBrush(Color.FromRgb(55, 55, 55));
		}
	}

	private void SearchBox_LostFocus(object s, RoutedEventArgs e)
	{
		if (string.IsNullOrWhiteSpace(SearchBox.Text))
		{
			SearchBox.Text = "Buscar en la hoja";
			SearchBox.Foreground = new SolidColorBrush(Color.FromRgb(119, 119, 119));
		}
	}

	private void SearchBox_KeyDown(object s, KeyEventArgs e)
	{
		if (e.Key == Key.Enter && !string.IsNullOrWhiteSpace(SearchBox.Text) && SearchBox.Text != "Buscar en la hoja")
		{
			FindNext(SearchBox.Text);
			e.Handled = true;
		}
	}

	public MainWindow()
	{
		InitializeComponent();
		((FrameworkElement)Content).SizeChanged += (object _, SizeChangedEventArgs _) =>
		{
			UpdateHeaderLayout();
		};
		SourceInitialized += (object? _, EventArgs _) =>
		{
			ApplyGreenWindowCaption();
		};
		SizeChanged += MainWindow_SizeChanged;
		Grid.LoadingRow += Grid_LoadingRow;
		Grid.AddHandler(ScrollViewer.ScrollChangedEvent, (ScrollChangedEventHandler)((object _, ScrollChangedEventArgs _) =>
		{
			copyAdorner?.InvalidateVisual();
			formulaReferenceAdorner?.InvalidateVisual();
		}));
		Grid.SizeChanged += (object _, SizeChangedEventArgs _) =>
		{
			copyAdorner?.InvalidateVisual();
			formulaReferenceAdorner?.InvalidateVisual();
		};
		this.book.Sheets.Add(new Sheet
		{
			Name = "Hoja1"
		});
		if (File.Exists(AutoPath))
		{
			try
			{
				Book book = JsonSerializer.Deserialize<Book>(File.ReadAllText(AutoPath));
				if (book != null && book.Sheets.Count > 0)
				{
					this.book.SyncId = book.SyncId;
					this.book.Title = book.Title;
					this.book.Sheets = book.Sheets;
					this.book.Active = Math.Clamp(book.Active, 0, book.Sheets.Count - 1);
				}
			}
			catch
			{
			}
		}
		activeSheet = this.book.Active;
		WorkbookTitle.Text = (string.IsNullOrWhiteSpace(this.book.Title) ? "Libro1" : this.book.Title);
		RenderSheet();
		RenderTabs();
		CommitTable();
		ResetHistory();
		SetRibbon("home");
		UpdateAccountBadge();
		Loaded += (object _, RoutedEventArgs _) =>
		{
			StartLicenseChecks();
			StartTrialChecks();
			StartCloudSync();
			StartUpdateChecks();
			Dispatcher.BeginInvoke((Action)(() =>
			{
				if (CanUseApp)
				{
					ShowStartScreen();
				}
			}));
		};
	}

	private void BuildTable()
	{
		table = new DataTable();
		for (int i = 0; i < 26; i++)
		{
			table.Columns.Add(ColName(i));
		}
		for (int j = 0; j < 500; j++)
		{
			table.Rows.Add(table.NewRow());
		}
		Sheet sheet = book.Sheets[activeSheet];
		for (int k = 0; k < Math.Min(500, sheet.Rows.Count); k++)
		{
			for (int l = 0; l < Math.Min(26, sheet.Rows[k].Count); l++)
			{
				table.Rows[k][l] = Display(sheet.Rows[k][l], k, l);
			}
		}
	}

	private string Display(string v, int row, int col)
	{
		return DisplayCellValue(activeSheet, row, col, new HashSet<string>());
	}

	private string DisplayCellValue(int sheetIndex, int row, int col, HashSet<string> stack)
	{
		string text = CalculateCellValue(sheetIndex, row, col, stack);
		if (sheetIndex < 0 || sheetIndex >= book.Sheets.Count || !double.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out var result))
		{
			return text;
		}
		return book.Sheets[sheetIndex].NumberFormats.GetValueOrDefault(CellAddress(row, col), "General") switch
		{
			"Thousands" => result.ToString("N0", CultureInfo.CurrentCulture), 
			"Number" => result.ToString("N2", CultureInfo.CurrentCulture), 
			"Currency" => result.ToString("C2", CultureInfo.CurrentCulture), 
			"Percent" => (result / 100.0).ToString("P0", CultureInfo.CurrentCulture), 
			"Date" => FormatExcelDate(result, text), 
			_ => text, 
		};
	}

	private string CalculateCellValue(int sheetIndex, int row, int col, HashSet<string> stack)
	{
		if (sheetIndex < 0 || sheetIndex >= book.Sheets.Count || row < 0 || col < 0)
		{
			return "#REF!";
		}
		string text = CellAddress(row, col);
		string item = $"{sheetIndex}!{text}";
		if (!stack.Add(item))
		{
			return "#CIRC!";
		}
		try
		{
			Sheet sheet = book.Sheets[sheetIndex];
			if (sheet.CellLinks.TryGetValue(text, out CellLink link))
			{
				int num = book.Sheets.FindIndex((Sheet s) => string.Equals(s.Name, link.SourceSheet, StringComparison.OrdinalIgnoreCase));
				return (num < 0) ? "#REF!" : CalculateCellValue(num, link.SourceRow, link.SourceCol, stack);
			}
			string text2 = sheet.Rows.ElementAtOrDefault(row)?.ElementAtOrDefault(col) ?? "";
			if (!text2.StartsWith('='))
			{
				return text2;
			}
			string text3 = EvaluateFormula(text2, sheetIndex, row, col, stack);
			if (text3.StartsWith('#') && text3 != "#CIRC!" && sheet.CachedFormulaValues.TryGetValue(text, out string value))
			{
				return value;
			}
			return text3;
		}
		finally
		{
			stack.Remove(item);
		}
	}

	private void RenderSheet()
	{
		List<(int row, int col)> restore = lastSelection.ToList();
		BuildTable();
		Grid.Columns.Clear();
		Grid.ItemsSource = table.DefaultView;
		Grid.Background = TryBrush(book.Sheets[activeSheet].PageColor) ?? Brushes.White;
		foreach (DataColumn column in table.Columns)
		{
			Grid.Columns.Add(new DataGridTextColumn
			{
				Header = column.ColumnName,
				Binding = new Binding("[" + column.ColumnName + "]")
				{
					UpdateSourceTrigger = UpdateSourceTrigger.LostFocus
				},
				Width = 115.0,
				SortMemberPath = column.ColumnName
			});
		}
		UpdateStatus();
		if (restore.Count > 0)
		{
			Dispatcher.BeginInvoke((Action)(() =>
			{
				RestoreSelection(restore);
			}));
		}
		Dispatcher.BeginInvoke(new Action(UpdateCopyOutline), DispatcherPriority.Loaded);
	}

	private void RestoreSelection(List<(int row, int col)> cells, (int row, int col)? active = null)
	{
		applyingSelection = true;
		try
		{
			Grid.SelectedCells.Clear();
			foreach (var cell in cells)
			{
				int row = cell.row;
				int item = cell.col;
				DataRowView dataRowView = table.DefaultView.Cast<DataRowView>().FirstOrDefault((DataRowView v) => table.Rows.IndexOf(v.Row) == row);
				if (dataRowView != null && item >= 0 && item < Grid.Columns.Count)
				{
					DataGridCellInfo dataGridCellInfo = new DataGridCellInfo(dataRowView, Grid.Columns[item]);
					if (Grid.SelectedCells.Count == 0)
					{
						Grid.CurrentCell = dataGridCellInfo;
					}
					Grid.SelectedCells.Add(dataGridCellInfo);
				}
			}
			lastSelection = cells.ToList();
			if (cells.Count > 0)
			{
				(int, int)? tuple = active;
				(int, int) tuple2;
				if (!tuple.HasValue)
				{
					tuple2 = cells[cells.Count - 1];
				}
				else
				{
					tuple2 = tuple.GetValueOrDefault();
				}
				(int row, int col) target = tuple2;
				DataRowView dataRowView2 = table.DefaultView.Cast<DataRowView>().FirstOrDefault((DataRowView v) => table.Rows.IndexOf(v.Row) == target.row);
				if (dataRowView2 != null && target.col >= 0 && target.col < Grid.Columns.Count)
				{
					DataGridCellInfo currentCell = new DataGridCellInfo(dataRowView2, Grid.Columns[target.col]);
					Grid.CurrentCell = currentCell;
					Grid.ScrollIntoView(dataRowView2, Grid.Columns[target.col]);
				}
			}
		}
		finally
		{
			applyingSelection = false;
		}
		UpdateActiveCellFromGrid();
		RefreshSelectionRows(cells);
	}

	private void Grid_LoadingRow(object? sender, DataGridRowEventArgs e)
	{
		e.Row.Header = e.Row.GetIndex() + 1;
		int row = ((e.Row.Item is DataRowView dataRowView) ? table.Rows.IndexOf(dataRowView.Row) : (-1));
		if (row >= 0)
		{
			Dispatcher.BeginInvoke((Action)(() =>
			{
				ApplyRowStyles(e.Row, row);
			}));
		}
	}

	private void ApplyRowStyles(DataGridRow row, int rowIndex)
	{
		if (!(row.Item is DataRowView))
		{
			return;
		}
		DataGridCellsPresenter dataGridCellsPresenter = FindVisualChild<DataGridCellsPresenter>(row);
		if (dataGridCellsPresenter == null)
		{
			return;
		}
		Brush borderBrush = (gridlinesVisible ? new SolidColorBrush(Color.FromRgb(217, 217, 217)) : Brushes.Transparent);
		Thickness borderThickness = (gridlinesVisible ? new Thickness(0.0, 0.0, 1.0, 1.0) : new Thickness(0.0));
		for (int i = 0; i < Grid.Columns.Count; i++)
		{
			if (!(dataGridCellsPresenter.ItemContainerGenerator.ContainerFromIndex(i) is DataGridCell dataGridCell))
			{
				continue;
			}
			dataGridCell.ClearValue(Control.BackgroundProperty);
			dataGridCell.ClearValue(Control.ForegroundProperty);
			dataGridCell.ClearValue(Control.FontFamilyProperty);
			dataGridCell.ClearValue(Control.FontSizeProperty);
			dataGridCell.ClearValue(Control.FontWeightProperty);
			dataGridCell.ClearValue(Control.FontStyleProperty);
			dataGridCell.ClearValue(Control.HorizontalContentAlignmentProperty);
			dataGridCell.ClearValue(Control.BorderBrushProperty);
			dataGridCell.ClearValue(Control.BorderThicknessProperty);
			dataGridCell.BorderBrush = borderBrush;
			dataGridCell.BorderThickness = borderThickness;
			if (dataGridCell.Content is TextBlock textBlock)
			{
				textBlock.TextDecorations = null;
			}
			string key = CellAddress(rowIndex, i);
			dataGridCell.ToolTip = book.Sheets[activeSheet].CellNotes.GetValueOrDefault(key);
			if (book.Sheets[activeSheet].CellStyles.TryGetValue(key, out CellStyleInfo value))
			{
				dataGridCell.FontFamily = new FontFamily(value.FontFamily);
				dataGridCell.FontSize = value.FontSize;
				dataGridCell.FontWeight = (value.Bold ? FontWeights.Bold : FontWeights.Normal);
				dataGridCell.FontStyle = (value.Italic ? FontStyles.Italic : FontStyles.Normal);
				DataGridCell dataGridCell2 = dataGridCell;
				string horizontalAlignment = value.HorizontalAlignment;
				HorizontalAlignment horizontalContentAlignment = ((horizontalAlignment == "Center") ? HorizontalAlignment.Center : ((horizontalAlignment == "Right") ? HorizontalAlignment.Right : HorizontalAlignment.Left));
				dataGridCell2.HorizontalContentAlignment = horizontalContentAlignment;
				if (value.FontColor != null)
				{
					Brush brush = TryBrush(value.FontColor);
					if (brush != null)
					{
						dataGridCell.Foreground = brush;
					}
				}
				if (value.FillColor != null)
				{
					Brush brush2 = TryBrush(value.FillColor);
					if (brush2 != null)
					{
						dataGridCell.Background = brush2;
					}
				}
				if (value.BorderColor != null)
				{
					Brush brush3 = TryBrush(value.BorderColor);
					if (brush3 != null)
					{
						dataGridCell.BorderBrush = brush3;
						dataGridCell.BorderThickness = new Thickness(0.0, 0.0, 1.0, 1.0);
					}
				}
				if (dataGridCell.Content is TextBlock textBlock2)
				{
					textBlock2.TextDecorations = (value.Underline ? TextDecorations.Underline : null);
				}
			}
			if (dataGridCell.IsSelected)
			{
				dataGridCell.Background = new SolidColorBrush(Color.FromArgb(95, 76, 175, 80));
				dataGridCell.BorderBrush = new SolidColorBrush(Color.FromRgb(33, 115, 70));
				dataGridCell.BorderThickness = new Thickness(1.0);
			}
		}
	}

	private static T? FindVisualChild<T>(DependencyObject parent) where T : DependencyObject
	{
		for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
		{
			DependencyObject child = VisualTreeHelper.GetChild(parent, i);
			if (child is T result)
			{
				return result;
			}
			T val = FindVisualChild<T>(child);
			if (val != null)
			{
				return val;
			}
		}
		return null;
	}

	private static Brush? TryBrush(string? value)
	{
		if (string.IsNullOrWhiteSpace(value))
		{
			return null;
		}
		try
		{
			return (Brush)new BrushConverter().ConvertFromString(value);
		}
		catch
		{
			return null;
		}
	}

	private void ApplyCurrentRowStyles()
	{
		if (Grid.SelectedCells.Count != 0 && Grid.SelectedCells[0].Item is DataRowView dataRowView)
		{
			Grid.ScrollIntoView(dataRowView, Grid.SelectedCells[0].Column);
			Grid.UpdateLayout();
			int rowIndex = table.Rows.IndexOf(dataRowView.Row);
			if (Grid.ItemContainerGenerator.ContainerFromItem(dataRowView) is DataGridRow row)
			{
				ApplyRowStyles(row, rowIndex);
			}
		}
	}

	private CellStyleInfo SelectedStyle()
	{
		if (Grid.SelectedCells.Count == 0 || !(Grid.SelectedCells[0].Item is DataRowView dataRowView))
		{
			return new CellStyleInfo();
		}
		int r = table.Rows.IndexOf(dataRowView.Row);
		int displayIndex = Grid.SelectedCells[0].Column.DisplayIndex;
		string key = CellAddress(r, displayIndex);
		Sheet sheet = book.Sheets[activeSheet];
		if (!sheet.CellStyles.TryGetValue(key, out CellStyleInfo value))
		{
			value = new CellStyleInfo();
			sheet.CellStyles[key] = value;
		}
		return value;
	}

	private List<(int row, int col)> SelectedCoordinates()
	{
		List<(int, int)> list = (from c in Grid.SelectedCells
			select (!(c.Item is DataRowView dataRowView)) ? (row: -1, col: -1) : (row: table.Rows.IndexOf(dataRowView.Row), col: c.Column.DisplayIndex) into x
			where x.row >= 0
			select x).Distinct().ToList();
		bool flag = Grid.IsKeyboardFocusWithin || Grid.IsMouseCaptureWithin;
		if ((list.Count > 1) | flag)
		{
			if (list.Count > 0)
			{
				lastSelection = list;
			}
			if (list.Count <= 0)
			{
				return lastSelection.ToList();
			}
			return list;
		}
		if (lastSelection.Count > 1)
		{
			return lastSelection.ToList();
		}
		if (list.Count <= 0)
		{
			return lastSelection.ToList();
		}
		return list;
	}

	private void SetSelectedStyle(Action<CellStyleInfo> update)
	{
		List<(int, int)> list = SelectedCoordinates();
		if (list.Count == 0)
		{
			StatusText.Text = "Seleccioná una celda para aplicar formato";
			return;
		}
		HashSet<int> hashSet = new HashSet<int>();
		Sheet sheet = book.Sheets[activeSheet];
		foreach (var item3 in list)
		{
			int item = item3.Item1;
			int item2 = item3.Item2;
			string key = CellAddress(item, item2);
			if (!sheet.CellStyles.TryGetValue(key, out CellStyleInfo value))
			{
				value = (sheet.CellStyles[key] = new CellStyleInfo());
			}
			update(value);
			hashSet.Add(item);
		}
		foreach (int row in hashSet)
		{
			DataRowView dataRowView = table.DefaultView.Cast<DataRowView>().FirstOrDefault((DataRowView v) => table.Rows.IndexOf(v.Row) == row);
			if (dataRowView != null && Grid.ItemContainerGenerator.ContainerFromItem(dataRowView) is DataGridRow row2)
			{
				ApplyRowStyles(row2, row);
			}
		}
		Persist();
		StatusText.Text = $"Formato aplicado a {list.Count} celdas";
	}

	private void ShowColorPalette(string title, bool fill)
	{
		if (SelectedCoordinates().Count == 0)
		{
			StatusText.Text = "Seleccioná una celda primero";
			return;
		}
		ContextMenu contextMenu = new ContextMenu();
		string[] array = new string[14]
		{
			"#000000", "#FFFFFF", "#C00000", "#ED7D31", "#FFC000", "#70AD47", "#4472C4", "#7030A0", "#00B0F0", "#808080",
			"#F4CCCC", "#D9EAD3", "#CFE2F3", "#FFF2CC"
		};
		foreach (string hex in array)
		{
			MenuItem menuItem = new MenuItem
			{
				Header = hex,
				Icon = new Border
				{
					Width = 18.0,
					Height = 18.0,
					Background = TryBrush(hex),
					BorderBrush = Brushes.Gray,
					BorderThickness = new Thickness(0.5)
				}
			};
			menuItem.Click += (object _, RoutedEventArgs _) =>
			{
				SetSelectedStyle((CellStyleInfo st) =>
				{
					if (fill)
					{
						st.FillColor = hex;
					}
					else
					{
						st.FontColor = hex;
					}
				});
			};
			contextMenu.Items.Add(menuItem);
		}
		contextMenu.Items.Add(new Separator());
		MenuItem menuItem2 = new MenuItem
		{
			Header = "Elegir color personalizado…"
		};
		menuItem2.Click += (object _, RoutedEventArgs _) =>
		{
			string hex2 = PromptText("Color personalizado", "Ingresá el color en formato #RRGGBB:", fill ? "#D9EAD3" : "#000000");
			if (hex2 != null)
			{
				if (!Regex.IsMatch(hex2, "^#[0-9A-Fa-f]{6}$"))
				{
					MessageBox.Show("Usá el formato #RRGGBB, por ejemplo #217346.", title, MessageBoxButton.OK, MessageBoxImage.Asterisk);
				}
				else
				{
					SetSelectedStyle((CellStyleInfo st) =>
					{
						if (fill)
						{
							st.FillColor = hex2;
						}
						else
						{
							st.FontColor = hex2;
						}
					});
				}
			}
		};
		contextMenu.Items.Add(menuItem2);
		contextMenu.PlacementTarget = Grid;
		contextMenu.IsOpen = true;
	}

	private void ShowStartScreen()
	{
		Hide();
		Window dialog = new Window
		{
			Title = "GEXE · Inicio",
			Owner = this,
			ShowInTaskbar = false,
			WindowState = WindowState.Maximized,
			Width = 800.0,
			Height = 500.0,
			MinWidth = 680.0,
			MinHeight = 420.0,
			WindowStartupLocation = WindowStartupLocation.CenterOwner,
			ResizeMode = ResizeMode.CanResize,
			Background = Brushes.White
		};
		DockPanel dockPanel = new DockPanel
		{
			Background = Brushes.White
		};
		StackPanel side = new StackPanel
		{
			Width = 190.0,
			Background = new SolidColorBrush(Color.FromRgb(246, 248, 250)),
			Margin = new Thickness(0.0)
		};
		DockPanel.SetDock(side, Dock.Left);
		dockPanel.Children.Add(side);
		side.Children.Add(new TextBlock
		{
			Text = "GEXE",
			FontSize = 21.0,
			FontWeight = FontWeights.SemiBold,
			Foreground = new SolidColorBrush(Color.FromRgb(33, 115, 70)),
			Margin = new Thickness(20.0, 24.0, 10.0, 26.0)
		});
		Nav("Inicio", () =>
		{
		});
		Nav("Nuevo", () =>
		{
			New_Click(this, new RoutedEventArgs());
		});
		Nav("Abrir", () =>
		{
			Open_Click(this, new RoutedEventArgs());
		});
		Nav("Compartir", () =>
		{
			Drive_Click(this, new RoutedEventArgs());
		});
		StackPanel content = new StackPanel
		{
			Margin = new Thickness(34.0, 28.0, 34.0, 22.0)
		};
		content.Children.Add(new TextBlock
		{
			Text = "¿Qué querés hacer?",
			FontSize = 25.0,
			FontWeight = FontWeights.SemiBold,
			Foreground = new SolidColorBrush(Color.FromRgb(37, 50, 71)),
			Margin = new Thickness(0.0, 0.0, 0.0, 8.0)
		});
		content.Children.Add(new TextBlock
		{
			Text = "Creá un libro nuevo o abrí una hoja de cálculo existente.",
			Foreground = new SolidColorBrush(Color.FromRgb(100, 112, 128)),
			Margin = new Thickness(0.0, 0.0, 0.0, 24.0)
		});
		content.Children.Add(BuildStartGoogleAccount(dialog));
		content.Children.Add(BuildLicenseSummary(dialog));
		content.Children.Add(BuildUpdateCard(dialog));
		Card("Libro en blanco", "Empezá con una hoja nueva.", () =>
		{
			New_Click(this, new RoutedEventArgs());
		});
		Card("Abrir archivo de Excel", "Abrí un archivo .xlsx desde esta computadora.", () =>
		{
			Open_Click(this, new RoutedEventArgs());
		});
		Card("Continuar libro guardado", "Seguí trabajando con la recuperación local.", () =>
		{
		});
		Card("Compartir / Google Drive", "Conectá Google y subí o abrí tu libro.", () =>
		{
			Drive_Click(this, new RoutedEventArgs());
		});
		AddRecentWorkbooks(content, dialog);
		AddManagedBooks(content, dialog);
		dockPanel.Children.Add(new ScrollViewer
		{
			VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
			Content = content
		});
		dialog.Content = dockPanel;
		dialog.ShowDialog();
		Show();
		Activate();
		void Card(string title, string detail, Action action)
		{
			Button button = new Button
			{
				HorizontalContentAlignment = HorizontalAlignment.Left,
				Padding = new Thickness(16.0),
				Margin = new Thickness(0.0, 0.0, 0.0, 12.0),
				Background = Brushes.White,
				BorderBrush = new SolidColorBrush(Color.FromRgb(218, 224, 231))
			};
			button.Content = new StackPanel
			{
				Children = 
				{
					(UIElement)new TextBlock
					{
						Text = title,
						FontWeight = FontWeights.SemiBold,
						FontSize = 16.0,
						Foreground = new SolidColorBrush(Color.FromRgb(33, 115, 70))
					},
					(UIElement)new TextBlock
					{
						Text = detail,
						Margin = new Thickness(0.0, 5.0, 0.0, 0.0),
						Foreground = new SolidColorBrush(Color.FromRgb(100, 112, 128))
					}
				}
			};
			button.Click += (object _, RoutedEventArgs _) =>
			{
				dialog.Close();
				action();
			};
			content.Children.Add(button);
		}
		void Nav(string text, Action action)
		{
			Button button = new Button
			{
				Content = text,
				HorizontalContentAlignment = HorizontalAlignment.Left,
				Padding = new Thickness(18.0, 10.0, 10.0, 10.0),
				Margin = new Thickness(8.0, 2.0, 8.0, 2.0),
				Background = Brushes.Transparent,
				BorderThickness = new Thickness(0.0),
				FontSize = 14.0
			};
			button.Click += (object _, RoutedEventArgs _) =>
			{
				dialog.Close();
				action();
			};
			side.Children.Add(button);
		}
	}

	private void ShowFileBackstage()
	{
		Window screen = new Window
		{
			Title = "GEXE · Archivo",
			Owner = this,
			WindowStyle = WindowStyle.SingleBorderWindow,
			ResizeMode = ResizeMode.CanResize,
			WindowStartupLocation = WindowStartupLocation.CenterOwner,
			ShowInTaskbar = false,
			Width = Math.Max(760.0, ActualWidth - 20.0),
			Height = Math.Max(520.0, ActualHeight - 20.0),
			Background = Brushes.White,
			Icon = Icon
		};
		Grid grid = new Grid();
		grid.RowDefinitions.Add(new RowDefinition
		{
			Height = new GridLength(48.0)
		});
		grid.RowDefinitions.Add(new RowDefinition
		{
			Height = new GridLength(1.0, GridUnitType.Star)
		});
		Border border = new Border
		{
			Background = new SolidColorBrush(Color.FromRgb(243, 243, 243)),
			BorderBrush = new SolidColorBrush(Color.FromRgb(214, 214, 214)),
			BorderThickness = new Thickness(0.0, 0.0, 0.0, 1.0)
		};
		DockPanel dockPanel = new DockPanel
		{
			Margin = new Thickness(18.0, 0.0, 18.0, 0.0)
		};
		Button button = new Button
		{
			Content = "← Volver al libro",
			Padding = new Thickness(12.0, 6.0, 12.0, 6.0),
			VerticalAlignment = VerticalAlignment.Center,
			Foreground = new SolidColorBrush(Color.FromRgb(33, 115, 70))
		};
		button.Click += (object _, RoutedEventArgs _) =>
		{
			screen.Close();
		};
		DockPanel.SetDock(button, Dock.Left);
		dockPanel.Children.Add(button);
		dockPanel.Children.Add(new TextBlock
		{
			Text = "Archivo",
			FontSize = 15.0,
			FontWeight = FontWeights.SemiBold,
			Foreground = new SolidColorBrush(Color.FromRgb(55, 55, 55)),
			VerticalAlignment = VerticalAlignment.Center,
			Margin = new Thickness(18.0, 0.0, 0.0, 0.0)
		});
		border.Child = dockPanel;
		grid.Children.Add(border);
		Grid grid2 = new Grid();
		grid2.ColumnDefinitions.Add(new ColumnDefinition
		{
			Width = new GridLength(220.0)
		});
		grid2.ColumnDefinitions.Add(new ColumnDefinition
		{
			Width = new GridLength(1.0, GridUnitType.Star)
		});
		System.Windows.Controls.Grid.SetRow(grid2, 1);
		grid.Children.Add(grid2);
		StackPanel stackPanel = new StackPanel
		{
			Background = new SolidColorBrush(Color.FromRgb(247, 247, 247)),
			Margin = new Thickness(0.0)
		};
		grid2.Children.Add(stackPanel);
		ScrollViewer scrollViewer = new ScrollViewer
		{
			VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
			Margin = new Thickness(42.0, 30.0, 34.0, 28.0)
		};
		System.Windows.Controls.Grid.SetColumn(scrollViewer, 1);
		grid2.Children.Add(scrollViewer);
		StackPanel pageContent = new StackPanel
		{
			MaxWidth = 900.0,
			HorizontalAlignment = HorizontalAlignment.Left
		};
		scrollViewer.Content = pageContent;
		string active = "Inicio";
		Dictionary<string, Button> navButtons = new Dictionary<string, Button>();
		string[] array = new string[13]
		{
			"Inicio", "Nuevo", "Abrir", "Información", "Guardar", "Guardar como", "Imprimir", "Compartir", "Exportar", "Cuenta",
			"Planes y facturación", "Opciones", "Cerrar"
		};
		foreach (string label in array)
		{
			Button button2 = new Button
			{
				Content = label,
				HorizontalContentAlignment = HorizontalAlignment.Left,
				Padding = new Thickness(24.0, 10.0, 12.0, 10.0),
				Margin = new Thickness(8.0, 1.0, 8.0, 1.0),
				Background = Brushes.Transparent,
				BorderBrush = Brushes.Transparent,
				BorderThickness = new Thickness(3.0, 0.0, 0.0, 0.0),
				FontSize = 13.0
			};
			button2.Click += (object _, RoutedEventArgs _) =>
			{
				RenderPage(label);
			};
			stackPanel.Children.Add(button2);
			navButtons[label] = button2;
		}
		screen.Content = grid;
		screen.KeyDown += (object _, KeyEventArgs e) =>
		{
			if (e.Key == Key.Escape)
			{
				screen.Close();
				e.Handled = true;
			}
		};
		RenderPage(active);
		screen.ShowDialog();
		void Card(string title, string detail, Action action, Panel? host = null)
		{
			Button button3 = new Button
			{
				HorizontalContentAlignment = HorizontalAlignment.Left,
				Padding = new Thickness(17.0),
				Margin = new Thickness(0.0, 0.0, 12.0, 12.0),
				MinWidth = 250.0,
				MaxWidth = 360.0,
				Background = Brushes.White,
				BorderBrush = new SolidColorBrush(Color.FromRgb(210, 210, 210))
			};
			button3.Content = new StackPanel
			{
				Children = 
				{
					(UIElement)new TextBlock
					{
						Text = title,
						FontSize = 15.0,
						FontWeight = FontWeights.SemiBold,
						Foreground = new SolidColorBrush(Color.FromRgb(33, 115, 70))
					},
					(UIElement)new TextBlock
					{
						Text = detail,
						FontSize = 12.0,
						TextWrapping = TextWrapping.Wrap,
						Foreground = new SolidColorBrush(Color.FromRgb(100, 100, 100)),
						Margin = new Thickness(0.0, 5.0, 0.0, 0.0)
					}
				}
			};
			button3.Click += (object _, RoutedEventArgs _) =>
			{
				Run(action);
			};
			(host ?? pageContent).Children.Add(button3);
		}
		void Heading(string title, string subtitle)
		{
			pageContent.Children.Add(new TextBlock
			{
				Text = title,
				FontSize = 27.0,
				FontWeight = FontWeights.SemiBold,
				Foreground = new SolidColorBrush(Color.FromRgb(45, 45, 45)),
				Margin = new Thickness(0.0, 0.0, 0.0, 7.0)
			});
			if (!string.IsNullOrWhiteSpace(subtitle))
			{
				pageContent.Children.Add(new TextBlock
				{
					Text = subtitle,
					FontSize = 13.0,
					Foreground = new SolidColorBrush(Color.FromRgb(100, 100, 100)),
					Margin = new Thickness(0.0, 0.0, 0.0, 24.0)
				});
			}
		}
		void RecentFiles()
		{
			List<string> source = new List<string>();
			try
			{
				if (File.Exists(RecentWorkbooksPath))
				{
					source = JsonSerializer.Deserialize<List<string>>(File.ReadAllText(RecentWorkbooksPath)) ?? new List<string>();
				}
			}
			catch
			{
			}
			List<string> list = source.Where(File.Exists).Distinct(StringComparer.OrdinalIgnoreCase).Take(10)
				.ToList();
			if (list.Count == 0)
			{
				pageContent.Children.Add(new TextBlock
				{
					Text = "Los libros que abras aparecerán aquí.",
					Foreground = new SolidColorBrush(Color.FromRgb(120, 120, 120)),
					Margin = new Thickness(0.0, 10.0, 0.0, 0.0)
				});
				return;
			}
			pageContent.Children.Add(new TextBlock
			{
				Text = "Recientes",
				FontSize = 17.0,
				FontWeight = FontWeights.SemiBold,
				Margin = new Thickness(0.0, 18.0, 0.0, 9.0)
			});
			foreach (string path in list)
			{
				Button button3 = new Button
				{
					Content = System.IO.Path.GetFileName(path) + "   ·   " + System.IO.Path.GetDirectoryName(path),
					HorizontalContentAlignment = HorizontalAlignment.Left,
					Background = Brushes.Transparent,
					BorderBrush = Brushes.Transparent,
					Padding = new Thickness(8.0, 10.0, 8.0, 10.0)
				};
				button3.Click += (object _, RoutedEventArgs _) =>
				{
					Run(() =>
					{
						OpenWorkbookFile(path);
					});
				};
				pageContent.Children.Add(button3);
			}
		}
		void RenderOptions()
		{
			Heading("Opciones", "Preferencias funcionales de GEXE en esta computadora.");
			CheckBox checkBox = new CheckBox
			{
				Content = "Guardar recuperación automáticamente",
				IsChecked = autoSave,
				FontSize = 14.0,
				Margin = new Thickness(0.0, 0.0, 0.0, 12.0)
			};
			checkBox.Checked += (object _, RoutedEventArgs _) =>
			{
				autoSave = true;
				Persist();
			};
			checkBox.Unchecked += (object _, RoutedEventArgs _) =>
			{
				autoSave = false;
				SaveStatus.Text = "Autoguardado pausado";
			};
			pageContent.Children.Add(checkBox);
			pageContent.Children.Add(new TextBlock
			{
				Text = "La recuperación se guarda localmente y no sube datos a la nube. Si la pausás, los cambios no se escribirán en la copia de recuperación hasta guardar el libro manualmente.",
				TextWrapping = TextWrapping.Wrap,
				Foreground = new SolidColorBrush(Color.FromRgb(90, 90, 90)),
				Margin = new Thickness(0.0, 0.0, 0.0, 18.0)
			});
			StackPanel stackPanel2 = new StackPanel
			{
				Orientation = Orientation.Horizontal,
				VerticalAlignment = VerticalAlignment.Center,
				Margin = new Thickness(0.0, 0.0, 0.0, 18.0)
			};
			stackPanel2.Children.Add(new TextBlock
			{
				Text = "Zoom de la hoja",
				Width = 150.0,
				VerticalAlignment = VerticalAlignment.Center
			});
			TextBlock zoomLabel = new TextBlock
			{
				Text = $"{zoom:P0}",
				Width = 65.0,
				VerticalAlignment = VerticalAlignment.Center,
				TextAlignment = TextAlignment.Center
			};
			Button button3 = new Button
			{
				Content = "−",
				Width = 38.0,
				Margin = new Thickness(3.0)
			};
			button3.Click += (object _, RoutedEventArgs _) =>
			{
				ZoomBy(-0.1);
			};
			Button button4 = new Button
			{
				Content = "+",
				Width = 38.0,
				Margin = new Thickness(3.0)
			};
			button4.Click += (object _, RoutedEventArgs _) =>
			{
				ZoomBy(0.1);
			};
			Button button5 = new Button
			{
				Content = "Restablecer 100 %",
				Padding = new Thickness(9.0, 5.0, 9.0, 5.0),
				Margin = new Thickness(8.0, 3.0, 3.0, 3.0)
			};
			button5.Click += (object _, RoutedEventArgs _) =>
			{
				ResetZoom();
				zoomLabel.Text = "100 %";
			};
			stackPanel2.Children.Add(button3);
			stackPanel2.Children.Add(zoomLabel);
			stackPanel2.Children.Add(button4);
			stackPanel2.Children.Add(button5);
			pageContent.Children.Add(stackPanel2);
			Card("Google Drive", "Configura la conexión y sincronización desde la sección Compartir. Requiere autorizar una cuenta Google; no se conecta desde esta pantalla.", () =>
			{
				Drive_Click(this, new RoutedEventArgs());
			});
			Border border2 = new Border
			{
				Padding = new Thickness(14.0),
				Margin = new Thickness(0.0, 10.0, 0.0, 0.0),
				Background = new SolidColorBrush(Color.FromRgb(247, 248, 250)),
				BorderBrush = new SolidColorBrush(Color.FromRgb(225, 228, 232)),
				BorderThickness = new Thickness(1.0)
			};
			border2.Child = new TextBlock
			{
				Text = "Las opciones de recuperación local, zoom y configuración de Drive están disponibles. Las opciones avanzadas de compatibilidad, complementos, macros VBA, impresión y administración de cuentas de Microsoft 365 no están implementadas en esta versión.",
				TextWrapping = TextWrapping.Wrap,
				Foreground = new SolidColorBrush(Color.FromRgb(80, 85, 92))
			};
			pageContent.Children.Add(border2);
			void ZoomBy(double delta)
			{
				ChangeZoom(delta);
				zoomLabel.Text = $"{zoom:P0}";
			}
		}
		void RenderPage(string page)
		{
			active = page;
			foreach (var (text2, button4) in navButtons)
			{
				bool flag = text2 == active;
				button4.Background = (flag ? new SolidColorBrush(Color.FromRgb(232, 241, 234)) : Brushes.Transparent);
				button4.Foreground = (flag ? new SolidColorBrush(Color.FromRgb(33, 115, 70)) : new SolidColorBrush(Color.FromRgb(55, 55, 55)));
				button4.BorderBrush = (flag ? new SolidColorBrush(Color.FromRgb(33, 115, 70)) : Brushes.Transparent);
			}
			pageContent.Children.Clear();
			switch (page)
			{
			case "Inicio":
			{
				Heading("Inicio", "Administra tus libros y continúa trabajando.");
				WrapPanel wrapPanel = new WrapPanel();
				pageContent.Children.Add(wrapPanel);
				Card("Libro en blanco", "Crea una hoja de cálculo nueva.", () =>
				{
					New_Click(this, new RoutedEventArgs());
				}, wrapPanel);
				Card("Abrir otros libros", "Busca un archivo .xlsx en esta computadora.", () =>
				{
					Open_Click(this, new RoutedEventArgs());
				}, wrapPanel);
				RecentFiles();
				break;
			}
			case "Nuevo":
				Heading("Nuevo", "Crea un libro de cálculo.");
				Card("Libro en blanco", "Comienza con una hoja nueva.", () =>
				{
					New_Click(this, new RoutedEventArgs());
				});
				break;
			case "Abrir":
				Heading("Abrir", "Abre un libro de Excel o vuelve a uno reciente.");
				Card("Examinar", "Busca un archivo .xlsx en tu computadora.", () =>
				{
					Open_Click(this, new RoutedEventArgs());
				});
				RecentFiles();
				break;
			case "Información":
				Heading("Información", "Detalles del libro actual.");
				pageContent.Children.Add(new TextBlock
				{
					Text = $"Hojas: {book.Sheets.Count}\nArchivo: {currentWorkbookPath ?? "Libro sin guardar"}\nRecuperación automática local: activa",
					FontSize = 14.0,
					TextWrapping = TextWrapping.Wrap,
					Margin = new Thickness(0.0, 4.0, 0.0, 18.0)
				});
				Card("Guardar cambios", "Guarda el libro actual.", SaveCurrentWorkbook);
				Card("Guardar como", "Guarda una copia XLSX.", SaveAsWorkbook);
				break;
			case "Guardar":
				Heading("Guardar", "Guarda los cambios del libro actual.");
				Card("Guardar ahora", currentWorkbookPath ?? "Si aún no tiene ubicación, podrás elegir dónde guardarlo.", SaveCurrentWorkbook);
				break;
			case "Guardar como":
				Heading("Guardar como", "Elige el nombre y la ubicación del archivo.");
				Card("Libro de Excel (.xlsx)", "Guarda una copia compatible con Excel.", SaveAsWorkbook);
				Card("Libro GEXE multiplataforma (.gexe)", "Guarda un archivo editable entre Android y Windows.", SaveAsGexeBook);
				break;
			case "Compartir":
				Heading("Compartir", "Comparte el libro mediante Google Drive.");
				Card("Google Drive", "Configura la cuenta y sube el libro para abrirlo en otro equipo.", () =>
				{
					Drive_Click(this, new RoutedEventArgs());
				});
				break;
			case "Exportar":
				Heading("Exportar", "Exporta el libro para Excel o para GEXE móvil.");
				Card("Exportar como XLSX", "Guarda una copia .xlsx.", SaveAsWorkbook);
				Card("Exportar como GEXE multiplataforma", "Guarda una copia .gexe para abrir en Android.", SaveAsGexeBook);
				break;
			case "Imprimir":
				Heading("Imprimir", "La impresión directa todavía no está disponible en GEXE.");
				break;
			case "Cuenta":
				Heading("Cuenta", "Conecta la cuenta de Google para usar Drive.");
				Card("Google Drive", "Abrir la configuración de la cuenta y sincronización.", () =>
				{
					Drive_Click(this, new RoutedEventArgs());
				});
				break;
			case "Planes y facturación":
				Heading("Planes y facturación", "Administra el plan de GEXE.");
				Card("Ver planes", "Consulta la interfaz de planes y suscripción.", ShowPlansWindow);
				break;
			case "Cerrar":
				Heading("Cerrar libro", "Vuelve a la pantalla de inicio de GEXE.");
				Card("Ir al inicio", "El libro queda guardado en recuperación local.", ShowStartScreen);
				break;
			default:
				RenderOptions();
				break;
			}
		}
		void Run(Action action)
		{
			screen.Close();
			action();
		}
	}

	private void RenderTabs()
	{
		SheetTabs.Children.Clear();
		for (int i = 0; i < book.Sheets.Count; i++)
		{
			int n = i;
			Button button = new Button
			{
				Content = book.Sheets[i].Name,
				ToolTip = "Clic: abrir · doble clic o clic derecho: renombrar · menú contextual: opciones",
				Margin = new Thickness(0.0, 0.0, 2.0, 0.0),
				Padding = new Thickness(13.0, 6.0, 13.0, 6.0),
				Background = ((i == activeSheet) ? Brushes.White : new SolidColorBrush(Color.FromRgb(230, 230, 230))),
				Foreground = ((i == activeSheet) ? new SolidColorBrush(Color.FromRgb(33, 115, 70)) : new SolidColorBrush(Color.FromRgb(70, 70, 70))),
				BorderBrush = ((i == activeSheet) ? new SolidColorBrush(Color.FromRgb(33, 115, 70)) : new SolidColorBrush(Color.FromRgb(214, 214, 214))),
				BorderThickness = ((i == activeSheet) ? new Thickness(0.0, 2.0, 0.0, 0.0) : new Thickness(0.0, 0.0, 0.0, 1.0))
			};
			button.Click += (object _, RoutedEventArgs _) =>
			{
				CommitTable();
				lastSelection = new List<(int, int)>();
				activeSheet = n;
				RenderSheet();
				RenderTabs();
			};
			button.MouseDoubleClick += (object _, MouseButtonEventArgs _) =>
			{
				RenameSheet(n);
			};
			ContextMenu contextMenu = new ContextMenu();
			MenuItem menuItem = new MenuItem
			{
				Header = "Cambiar nombre…"
			};
			menuItem.Click += (object _, RoutedEventArgs _) =>
			{
				RenameSheet(n);
			};
			contextMenu.Items.Add(menuItem);
			MenuItem menuItem2 = new MenuItem
			{
				Header = "Duplicar hoja"
			};
			menuItem2.Click += (object _, RoutedEventArgs _) =>
			{
				DuplicateSheet(n);
			};
			contextMenu.Items.Add(menuItem2);
			contextMenu.Items.Add(new Separator());
			MenuItem menuItem3 = new MenuItem
			{
				Header = "Eliminar hoja"
			};
			menuItem3.Click += (object _, RoutedEventArgs _) =>
			{
				DeleteSheet(n);
			};
			contextMenu.Items.Add(menuItem3);
			button.ContextMenu = contextMenu;
			SheetTabs.Children.Add(button);
		}
	}

	private void CommitTable()
	{
		if (book.Sheets.Count == 0)
		{
			return;
		}
		Sheet sheet = book.Sheets[activeSheet];
		while (sheet.Rows.Count < table.Rows.Count)
		{
			sheet.Rows.Add(new List<string>());
		}
		for (int i = 0; i < table.Rows.Count; i++)
		{
			while (sheet.Rows[i].Count < table.Columns.Count)
			{
				sheet.Rows[i].Add("");
			}
			for (int j = 0; j < table.Columns.Count; j++)
			{
				string text = Convert.ToString(table.Rows[i][j], CultureInfo.InvariantCulture) ?? "";
				string v = sheet.Rows[i][j];
				if (text != Display(v, i, j))
				{
					sheet.Rows[i][j] = text;
					string key = CellAddress(i, j);
					sheet.CachedFormulaValues.Remove(key);
					sheet.CachedFormulaTypes.Remove(key);
				}
			}
		}
	}

	private string CreateHistorySnapshot()
	{
		return JsonSerializer.Serialize(new Book
		{
			SyncId = book.SyncId,
			Title = "",
			Active = 0,
			Sheets = book.Sheets
		});
	}

	private void ResetHistory()
	{
		undoHistory.Clear();
		redoHistory.Clear();
		book.Active = activeSheet;
		lastHistorySnapshot = CreateHistorySnapshot();
		UpdateHistoryButtons();
	}

	private void UpdateHistoryButtons()
	{
		UndoButton.IsEnabled = undoHistory.Count > 0;
		RedoButton.IsEnabled = redoHistory.Count > 0;
	}

	private void TrackHistorySnapshot()
	{
		book.Active = activeSheet;
		string a = CreateHistorySnapshot();
		if (restoringHistory)
		{
			lastHistorySnapshot = a;
			UpdateHistoryButtons();
			return;
		}
		if (lastHistorySnapshot == null)
		{
			lastHistorySnapshot = a;
			UpdateHistoryButtons();
			return;
		}
		if (!string.Equals(a, lastHistorySnapshot, StringComparison.Ordinal))
		{
			undoHistory.Add(lastHistorySnapshot);
			if (undoHistory.Count > 100)
			{
				undoHistory.RemoveAt(0);
			}
			redoHistory.Clear();
			lastHistorySnapshot = a;
		}
		UpdateHistoryButtons();
	}

	private void Persist()
	{
		TrackHistorySnapshot();
		if (!autoSave)
		{
			SaveStatus.Text = "Autoguardado pausado";
			return;
		}
		try
		{
			Directory.CreateDirectory(System.IO.Path.GetDirectoryName(AutoPath));
			book.Active = activeSheet;
			File.WriteAllText(AutoPath, JsonSerializer.Serialize(book));
			CloudBookChanged();
			SaveStatus.Text = "Guardado local · " + DateTime.Now.ToString("HH:mm");
		}
		catch
		{
			SaveStatus.Text = "No se pudo guardar";
		}
	}

	private void RestoreHistorySnapshot(string snapshot, string action)
	{
		Book book = JsonSerializer.Deserialize<Book>(snapshot);
		if (book != null && book.Sheets.Count != 0)
		{
			string text = WorkbookTitle.Text;
			string currentSheetName = this.book.Sheets.ElementAtOrDefault(activeSheet)?.Name;
			this.book.Sheets = book.Sheets;
			int num = this.book.Sheets.FindIndex((Sheet sheet) => string.Equals(sheet.Name, currentSheetName, StringComparison.OrdinalIgnoreCase));
			activeSheet = ((num >= 0) ? num : Math.Clamp(book.Active, 0, book.Sheets.Count - 1));
			this.book.Active = activeSheet;
			this.book.Title = text;
			lastSelection = new List<(int, int)>();
			lastHistorySnapshot = CreateHistorySnapshot();
			restoringHistory = true;
			try
			{
				RenderSheet();
				RenderTabs();
				Persist();
			}
			finally
			{
				restoringHistory = false;
				UpdateHistoryButtons();
			}
			StatusText.Text = action;
		}
	}

	private void CommitPendingEditForHistory()
	{
		if (gridCellEditing)
		{
			Grid.CommitEdit(DataGridEditingUnit.Cell, exitEditingMode: true);
			Grid.CommitEdit(DataGridEditingUnit.Row, exitEditingMode: true);
		}
		FlushPendingCellWrites();
	}

	private void Undo_Click(object s, RoutedEventArgs e)
	{
		if (CanUseApp)
		{
			CommitPendingEditForHistory();
			if (undoHistory.Count != 0)
			{
				redoHistory.Add(CreateHistorySnapshot());
				List<string> list = undoHistory;
				string snapshot = list[list.Count - 1];
				undoHistory.RemoveAt(undoHistory.Count - 1);
				RestoreHistorySnapshot(snapshot, "Última acción deshecha");
			}
		}
	}

	private void Redo_Click(object s, RoutedEventArgs e)
	{
		if (!CanUseApp)
		{
			return;
		}
		CommitPendingEditForHistory();
		if (redoHistory.Count != 0)
		{
			undoHistory.Add(CreateHistorySnapshot());
			if (undoHistory.Count > 100)
			{
				undoHistory.RemoveAt(0);
			}
			List<string> list = redoHistory;
			string snapshot = list[list.Count - 1];
			redoHistory.RemoveAt(redoHistory.Count - 1);
			RestoreHistorySnapshot(snapshot, "Acción recuperada");
		}
	}

	private void Grid_CellEditEnding(object s, DataGridCellEditEndingEventArgs e)
	{
		gridCellEditing = false;
		if (e.EditAction == DataGridEditAction.Commit && e.EditingElement is TextBox textBox && e.Row.Item is DataRowView dataRowView)
		{
			int row = table.Rows.IndexOf(dataRowView.Row);
			int displayIndex = e.Column.DisplayIndex;
			string text = textBox.Text;
			if (!text.StartsWith('=') && pendingNavigation != null)
			{
				text = SuggestExistingCellValue(row, displayIndex, text) ?? text;
			}
			string navigation = pendingNavigation;
			pendingNavigation = null;
			CloseCellSuggestions();
			QueueCellWrite(row, displayIndex, text, navigation);
		}
	}

	private void QueueCellWrite(int row, int col, string value, string? navigation)
	{
		int id = ++nextPendingCellWriteId;
		pendingCellWrites[id] = new PendingCellWrite(book.Sheets[activeSheet], row, col, value, navigation);
		Dispatcher.BeginInvoke((Action)(() =>
		{
			if (pendingCellWrites.Remove(id, out PendingCellWrite value2))
			{
				ApplyPendingCellWrite(value2);
			}
		}));
	}

	private void FlushPendingCellWrites()
	{
		KeyValuePair<int, PendingCellWrite>[] array = pendingCellWrites.ToArray();
		for (int i = 0; i < array.Length; i++)
		{
			var (key, pending) = array[i];
			pendingCellWrites.Remove(key);
			ApplyPendingCellWrite(pending);
		}
	}

	private void ApplyPendingCellWrite(PendingCellWrite pending)
	{
		if (!CanUseApp || !book.Sheets.Contains(pending.Sheet))
		{
			return;
		}
		if (book.Sheets[activeSheet] == pending.Sheet)
		{
			WriteCell(pending.Row, pending.Col, pending.Value);
		}
		else
		{
			Sheet sheet = pending.Sheet;
			while (sheet.Rows.Count <= pending.Row)
			{
				sheet.Rows.Add(new List<string>());
			}
			while (sheet.Rows[pending.Row].Count <= pending.Col)
			{
				sheet.Rows[pending.Row].Add("");
			}
			string key = CellAddress(pending.Row, pending.Col);
			sheet.Rows[pending.Row][pending.Col] = pending.Value;
			sheet.CellLinks.Remove(key);
			sheet.CachedFormulaValues.Remove(key);
			sheet.CachedFormulaTypes.Remove(key);
			Persist();
		}
		string navigation = pending.Navigation;
		if (navigation != null && book.Sheets[activeSheet] == pending.Sheet)
		{
			int num = ((navigation == "left") ? (-1) : ((navigation == "right") ? 1 : 0));
			int num2 = ((navigation == "up") ? (-1) : ((navigation == "down") ? 1 : 0));
			SelectCell(Math.Clamp(pending.Row + num2, 0, table.Rows.Count - 1), Math.Clamp(pending.Col + num, 0, table.Columns.Count - 1));
		}
	}

	private void Recalculate()
	{
		for (int i = 0; i < table.Rows.Count; i++)
		{
			for (int j = 0; j < table.Columns.Count; j++)
			{
				string v = book.Sheets[activeSheet].Rows.ElementAtOrDefault(i)?.ElementAtOrDefault(j) ?? "";
				table.Rows[i][j] = Display(v, i, j);
			}
		}
	}

	private void WriteCell(int row, int col, string value)
	{
		if (CanUseApp && row >= 0 && col >= 0 && row < table.Rows.Count && col < table.Columns.Count)
		{
			Sheet sheet = book.Sheets[activeSheet];
			while (sheet.Rows.Count <= row)
			{
				sheet.Rows.Add(new List<string>());
			}
			while (sheet.Rows[row].Count <= col)
			{
				sheet.Rows[row].Add("");
			}
			string text = CellAddress(row, col);
			sheet.Rows[row][col] = value;
			sheet.CellLinks.Remove(text);
			sheet.CachedFormulaValues.Remove(text);
			sheet.CachedFormulaTypes.Remove(text);
			table.Rows[row][col] = Display(value, row, col);
			FormulaBox.Text = value;
			Recalculate();
			Persist();
			StatusText.Text = text + " actualizado";
		}
	}

	private void SelectCell(int row, int col)
	{
		DataRowView dataRowView = table.DefaultView.Cast<DataRowView>().FirstOrDefault((DataRowView x) => table.Rows.IndexOf(x.Row) == row);
		if (dataRowView != null)
		{
			col = Math.Clamp(col, 0, Grid.Columns.Count - 1);
			DataGridCellInfo dataGridCellInfo = new DataGridCellInfo(dataRowView, Grid.Columns[col]);
			shiftAnchor = (row, col);
			applyingSelection = true;
			try
			{
				Grid.SelectedCells.Clear();
				Grid.CurrentCell = dataGridCellInfo;
				Grid.SelectedCells.Add(dataGridCellInfo);
				int num = 1;
				List<(int, int)> list = new List<(int, int)>(num);
				CollectionsMarshal.SetCount(list, num);
				CollectionsMarshal.AsSpan(list)[0] = (row, col);
				lastSelection = list;
			}
			finally
			{
				applyingSelection = false;
			}
			Grid.ScrollIntoView(dataRowView, Grid.Columns[col]);
			Grid.Focus();
			UpdateActiveCellFromGrid();
			RefreshSelectionRows(new _003C_003Ez__ReadOnlySingleElementList<(int, int)>((row, col)));
		}
	}

	private void MoveSelectedCell(int dx, int dy)
	{
		List<DataRowView> list = table.DefaultView.Cast<DataRowView>().ToList();
		if (list.Count != 0)
		{
			int num = ((Grid.SelectedCells.Count > 0 && Grid.SelectedCells[0].Item is DataRowView item) ? list.IndexOf(item) : 0);
			int num2 = ((Grid.SelectedCells.Count > 0) ? Grid.SelectedCells[0].Column.DisplayIndex : 0);
			int index = Math.Clamp(num + dy, 0, list.Count - 1);
			SelectCell(table.Rows.IndexOf(list[index].Row), Math.Clamp(num2 + dx, 0, Grid.Columns.Count - 1));
		}
	}

	private void Grid_PreviewKeyDown(object sender, KeyEventArgs e)
	{
		if (e.Key == Key.Escape && copiedCells != null)
		{
			CancelCopyMode();
			e.Handled = true;
			return;
		}
		Key key;
		if (e.OriginalSource is TextBox textBox)
		{
			if (TryAppendFormulaReference(textBox, e.Key))
			{
				e.Handled = true;
				return;
			}
			key = e.Key;
			if ((key == Key.Tab || key == Key.Enter || (uint)(key - 23) <= 3u) ? true : false)
			{
				bool flag = !textBox.Text.StartsWith('=');
				if (flag)
				{
					key = e.Key;
					bool flag2 = ((key == Key.Tab || (uint)(key - 23) <= 3u) ? true : false);
					flag = flag2;
				}
				if (flag)
				{
					AcceptCellSuggestion(textBox);
				}
				ModifierKeys modifiers = Keyboard.Modifiers;
				pendingNavigation = e.Key switch
				{
					Key.Enter => modifiers.HasFlag(ModifierKeys.Shift) ? "up" : "down", 
					Key.Tab => modifiers.HasFlag(ModifierKeys.Shift) ? "left" : "right", 
					Key.Left => "left", 
					Key.Right => "right", 
					Key.Up => "up", 
					_ => "down", 
				};
				Grid.CommitEdit(DataGridEditingUnit.Cell, exitEditingMode: true);
				Grid.CommitEdit(DataGridEditingUnit.Row, exitEditingMode: true);
				e.Handled = true;
			}
			return;
		}
		ModifierKeys modifiers2 = Keyboard.Modifiers;
		key = e.Key;
		if ((uint)(key - 23) <= 3u)
		{
			int num = ((e.Key == Key.Left) ? (-1) : ((e.Key == Key.Right) ? 1 : 0));
			int num2 = ((e.Key == Key.Up) ? (-1) : ((e.Key == Key.Down) ? 1 : 0));
			DataGridCellInfo currentCell = Grid.CurrentCell;
			int num3 = ((currentCell.Item is DataRowView dataRowView) ? table.Rows.IndexOf(dataRowView.Row) : 0);
			int num4 = (currentCell.IsValid ? currentCell.Column.DisplayIndex : 0);
			int num5 = Math.Clamp(num3 + num2, 0, table.Rows.Count - 1);
			int num6 = Math.Clamp(num4 + num, 0, Grid.Columns.Count - 1);
			if (modifiers2.HasFlag(ModifierKeys.Shift))
			{
				(int, int) value = shiftAnchor ?? (num3, num4);
				SelectCoordinateRange(Math.Min(value.Item1, num5), Math.Min(value.Item2, num6), Math.Max(value.Item1, num5), Math.Max(value.Item2, num6), (row: num5, col: num6));
				shiftAnchor = value;
			}
			else
			{
				SelectCell(num5, num6);
			}
			e.Handled = true;
			return;
		}
		if (modifiers2.HasFlag(ModifierKeys.Control) && e.Key == Key.A)
		{
			Grid.SelectAll();
			lastSelection = (from r in Enumerable.Range(0, table.Rows.Count)
				from c in Enumerable.Range(0, Grid.Columns.Count)
				select (r: r, c: c)).ToList();
			e.Handled = true;
			return;
		}
		if (modifiers2.HasFlag(ModifierKeys.Control) && e.Key == Key.C)
		{
			CopyCell();
			e.Handled = true;
			return;
		}
		if (modifiers2.HasFlag(ModifierKeys.Control) && e.Key == Key.X)
		{
			CutCell();
			e.Handled = true;
			return;
		}
		if (modifiers2.HasFlag(ModifierKeys.Control) && e.Key == Key.V)
		{
			PasteCell();
			e.Handled = true;
			return;
		}
		key = e.Key;
		if ((key == Key.Back || key == Key.Delete) ? true : false)
		{
			ClearCell();
			e.Handled = true;
			return;
		}
		key = e.Key;
		if ((key == Key.Tab || key == Key.Enter) ? true : false)
		{
			ModifierKeys modifiers3 = Keyboard.Modifiers;
			MoveSelectedCell((e.Key == Key.Tab) ? ((!modifiers3.HasFlag(ModifierKeys.Shift)) ? 1 : (-1)) : 0, (e.Key == Key.Enter) ? ((!modifiers3.HasFlag(ModifierKeys.Shift)) ? 1 : (-1)) : 0);
			e.Handled = true;
		}
		else if (e.Key == Key.Space && Grid.SelectedCells.Count > 0 && Grid.SelectedCells[0].Item is DataRowView dataRowView2)
		{
			int num7 = table.Rows.IndexOf(dataRowView2.Row);
			int displayIndex = Grid.SelectedCells[0].Column.DisplayIndex;
			string text = book.Sheets[activeSheet].Rows.ElementAtOrDefault(num7)?.ElementAtOrDefault(displayIndex) ?? "";
			if ((text == "☐" || text == "☑") ? true : false)
			{
				ToggleCheckbox(num7, displayIndex);
				e.Handled = true;
			}
		}
	}

	private void Grid_PreviewTextInput(object sender, TextCompositionEventArgs e)
	{
		if (e.Handled || e.Text.Length == 0 || e.OriginalSource is TextBox)
		{
			return;
		}
		ModifierKeys modifiers = Keyboard.Modifiers;
		if (modifiers.HasFlag(ModifierKeys.Control) || modifiers.HasFlag(ModifierKeys.Alt))
		{
			return;
		}
		DataGridCellInfo currentCell = Grid.CurrentCell;
		if (!currentCell.IsValid || !(currentCell.Item is DataRowView dataRowView))
		{
			return;
		}
		int row = table.Rows.IndexOf(dataRowView.Row);
		int col = currentCell.Column.DisplayIndex;
		string typed = e.Text;
		e.Handled = true;
		if (!Grid.BeginEdit())
		{
			WriteCell(row, col, typed);
			return;
		}
		Dispatcher.BeginInvoke((Action)(() =>
		{
			TextBox textBox = FindVisualChild<TextBox>(Grid);
			if (textBox == null)
			{
				WriteCell(row, col, typed);
			}
			else
			{
				AttachAutocompleteEditor(textBox, row, col);
				textBox.Text = typed;
				textBox.CaretIndex = textBox.Text.Length;
				textBox.Focus();
				FormulaBox.Text = typed;
			}
		}), DispatcherPriority.Input);
	}

	private bool TryAppendFormulaReference(TextBox editor, Key key)
	{
		int num = ((key == Key.Left) ? (-1) : ((key == Key.Right) ? 1 : 0));
		int num2 = ((key == Key.Up) ? (-1) : ((key == Key.Down) ? 1 : 0));
		if (num == 0 && num2 == 0)
		{
			return false;
		}
		string text = editor.Text;
		if (!text.StartsWith('='))
		{
			return false;
		}
		string text2 = text.TrimEnd();
		if (text2.Length != 0)
		{
			if ("=+-*/^&(:,;".Contains(text2[text2.Length - 1]))
			{
				int? num3 = formulaTargetRow;
				if (num3.HasValue)
				{
					num3 = formulaTargetCol;
					if (num3.HasValue)
					{
						goto IL_010c;
					}
				}
				if (Grid.SelectedCells.Count == 0 || !(Grid.SelectedCells[0].Item is DataRowView dataRowView))
				{
					return false;
				}
				formulaTargetRow = table.Rows.IndexOf(dataRowView.Row);
				formulaTargetCol = Grid.SelectedCells[0].Column.DisplayIndex;
				goto IL_010c;
			}
		}
		return false;
		IL_010c:
		int num4 = Math.Clamp(formulaTargetRow.Value + num2, 0, 499);
		int num5 = Math.Clamp(formulaTargetCol.Value + num, 0, 25);
		formulaTargetRow = num4;
		formulaTargetCol = num5;
		editor.Text += CellAddress(num4, num5);
		editor.CaretIndex = editor.Text.Length;
		if (editor != FormulaBox)
		{
			FormulaBox.Text = editor.Text;
		}
		formulaReferenceRange = (num4, num5, num4, num5);
		UpdateFormulaReferenceOutline();
		StatusText.Text = "Referencia insertada: " + CellAddress(num4, num5);
		return true;
	}

	private void FormulaBox_PreviewKeyDown(object sender, KeyEventArgs e)
	{
		if (TryAppendFormulaReference(FormulaBox, e.Key))
		{
			e.Handled = true;
		}
	}

	private void Grid_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
	{
		DataGridCell dataGridCell = FindVisualParent<DataGridCell>(e.OriginalSource as DependencyObject);
		if (!(dataGridCell?.DataContext is DataRowView dataRowView))
		{
			return;
		}
		int num = table.Rows.IndexOf(dataRowView.Row);
		int col = dataGridCell.Column.DisplayIndex;
		if (TryInsertMouseFormulaReference(num, col))
		{
			e.Handled = true;
			return;
		}
		ModifierKeys modifiers = Keyboard.Modifiers;
		if (modifiers.HasFlag(ModifierKeys.Shift))
		{
			(int row, int col) anchor = shiftAnchor ?? ((Grid.CurrentCell.Item is DataRowView dataRowView2) ? (table.Rows.IndexOf(dataRowView2.Row), Grid.CurrentCell.Column.DisplayIndex) : (num, col));
			List<(int, int)> cells = (from r in Enumerable.Range(Math.Min(anchor.row, num), Math.Abs(anchor.row - num) + 1)
				from c in Enumerable.Range(Math.Min(anchor.col, col), Math.Abs(anchor.col - col) + 1)
				select (r: r, c: c)).ToList();
			RestoreSelection(cells, (num, col));
			Grid.Focus();
			e.Handled = true;
		}
		else
		{
			shiftAnchor = (num, col);
			string text = book.Sheets[activeSheet].Rows.ElementAtOrDefault(num)?.ElementAtOrDefault(col) ?? "";
			if ((text == "☐" || text == "☑") ? true : false)
			{
				SelectCell(num, col);
				ToggleCheckbox(num, col);
				e.Handled = true;
			}
		}
	}

	private bool TryInsertMouseFormulaReference(int row, int col)
	{
		if (!(Keyboard.FocusedElement is TextBox textBox) || FindVisualParent<DataGridCell>(textBox) == null || !textBox.Text.StartsWith('='))
		{
			return false;
		}
		string text = CellAddress(row, col);
		string text2 = textBox.Text;
		string text3 = text2.TrimEnd();
		if (text3.Length == 0)
		{
			return false;
		}
		int num = -1;
		if ("=+-*/^&(:,;".Contains(text3[text3.Length - 1]))
		{
			bool flag = text3[text3.Length - 1] == ':';
			num = text2.Length;
			textBox.Text = text2 + text;
			if (!flag)
			{
				formulaMouseReferenceAnchor = (row, col);
			}
			goto IL_012e;
		}
		int? num2 = formulaReferenceTextStart;
		if (num2.HasValue)
		{
			int valueOrDefault = num2.GetValueOrDefault();
			(int, int)? tuple = formulaMouseReferenceAnchor;
			if (tuple.HasValue)
			{
				var (r, c) = tuple.GetValueOrDefault();
				if (lastMouseReference != null && text2.EndsWith(lastMouseReference, StringComparison.Ordinal))
				{
					num = valueOrDefault;
					string text4 = CellAddress(r, c);
					textBox.Text = text2.Substring(0, valueOrDefault) + text4 + ":" + text;
					goto IL_012e;
				}
			}
		}
		return false;
		IL_012e:
		textBox.CaretIndex = textBox.Text.Length;
		FormulaBox.Text = textBox.Text;
		formulaMouseReferenceAnchor = formulaMouseReferenceAnchor ?? (row, col);
		formulaReferenceTextStart = num;
		lastMouseReference = text;
		(int, int) value = formulaMouseReferenceAnchor.Value;
		formulaReferenceRange = (Math.Min(value.Item1, row), Math.Min(value.Item2, col), Math.Max(value.Item1, row), Math.Max(value.Item2, col));
		UpdateFormulaReferenceOutline();
		StatusText.Text = "Referencia " + CellAddress(row, col) + " insertada en la fórmula";
		return true;
	}

	private void Grid_PreviewMouseRightButtonDown(object sender, MouseButtonEventArgs e)
	{
		DataGridCell dataGridCell = FindVisualParent<DataGridCell>(e.OriginalSource as DependencyObject);
		if (!(dataGridCell?.DataContext is DataRowView dataRowView))
		{
			return;
		}
		int row = table.Rows.IndexOf(dataRowView.Row);
		int col = dataGridCell.Column.DisplayIndex;
		List<(int, int)> list = SelectedCoordinates();
		if (!list.Contains((row, col)))
		{
			SelectCell(row, col);
		}
		else
		{
			lastSelection = list;
		}
		ContextMenu menu = new ContextMenu();
		TextBox search = new TextBox
		{
			Width = 218.0,
			Height = 24.0,
			Padding = new Thickness(4.0, 1.0, 4.0, 1.0),
			Text = "",
			ToolTip = "Buscar en los menús"
		};
		MenuItem searchHost = new MenuItem
		{
			Header = search,
			StaysOpenOnClick = true
		};
		menu.Items.Add(searchHost);
		Add("Cortar", CutCell);
		Add("Copiar", CopyCell);
		Add("Pegar", PasteCell);
		Add("Pegado especial…", PasteCell).ToolTip = "Pegar el contenido disponible del portapapeles";
		menu.Items.Add(new Separator());
		MenuItem menuItem = new MenuItem
		{
			Header = "Insertar"
		};
		MenuItem menuItem2 = new MenuItem
		{
			Header = "Nueva hoja"
		};
		menuItem2.Click += (object _, RoutedEventArgs _) =>
		{
			AddSheet_Click(this, new RoutedEventArgs());
		};
		menuItem.Items.Add(menuItem2);
		MenuItem menuItem3 = new MenuItem
		{
			Header = "Insertar casilla"
		};
		menuItem3.Click += (object _, RoutedEventArgs _) =>
		{
			InsertCheckbox();
		};
		menuItem.Items.Add(menuItem3);
		menu.Items.Add(menuItem);
		MenuItem menuItem4 = new MenuItem
		{
			Header = "Eliminar"
		};
		MenuItem menuItem5 = new MenuItem
		{
			Header = "Borrar contenido seleccionado"
		};
		menuItem5.Click += (object _, RoutedEventArgs _) =>
		{
			ClearCell();
		};
		menuItem4.Items.Add(menuItem5);
		MenuItem menuItem6 = new MenuItem
		{
			Header = "Borrar formato"
		};
		menuItem6.Click += (object _, RoutedEventArgs _) =>
		{
			ClearCellFormat();
		};
		menuItem4.Items.Add(menuItem6);
		menu.Items.Add(menuItem4);
		MenuItem menuItem7 = new MenuItem
		{
			Header = "Seleccionar"
		};
		MenuItem menuItem8 = new MenuItem
		{
			Header = "Fila completa"
		};
		menuItem8.Click += (object _, RoutedEventArgs _) =>
		{
			SelectCoordinateRange(row, 0, row, Grid.Columns.Count - 1, (row: row, col: col));
		};
		menuItem7.Items.Add(menuItem8);
		MenuItem menuItem9 = new MenuItem
		{
			Header = "Columna completa"
		};
		menuItem9.Click += (object _, RoutedEventArgs _) =>
		{
			SelectCoordinateRange(0, col, table.Rows.Count - 1, col, (row: row, col: col));
		};
		menuItem7.Items.Add(menuItem9);
		menu.Items.Add(menuItem7);
		Add("Borrar contenido", ClearCell);
		menu.Items.Add(new Separator());
		MenuItem menuItem10 = new MenuItem
		{
			Header = "Análisis rápido"
		};
		MenuItem menuItem11 = new MenuItem
		{
			Header = "Autosuma"
		};
		menuItem11.Click += (object _, RoutedEventArgs _) =>
		{
			AutoSum();
		};
		menuItem10.Items.Add(menuItem11);
		MenuItem menuItem12 = new MenuItem
		{
			Header = "Gráfico"
		};
		menuItem12.Click += (object _, RoutedEventArgs _) =>
		{
			Chart_Click(this, new RoutedEventArgs());
		};
		menuItem10.Items.Add(menuItem12);
		MenuItem menuItem13 = new MenuItem
		{
			Header = "Formato como tabla"
		};
		menuItem13.Click += (object _, RoutedEventArgs _) =>
		{
			Table_Click(this, new RoutedEventArgs());
		};
		menuItem10.Items.Add(menuItem13);
		menu.Items.Add(menuItem10);
		MenuItem menuItem14 = new MenuItem
		{
			Header = "Ordenar"
		};
		MenuItem menuItem15 = new MenuItem
		{
			Header = "Ordenar de A a Z"
		};
		menuItem15.Click += (object _, RoutedEventArgs _) =>
		{
			SortSelectedColumn(ascending: true);
		};
		menuItem14.Items.Add(menuItem15);
		MenuItem menuItem16 = new MenuItem
		{
			Header = "Ordenar de Z a A"
		};
		menuItem16.Click += (object _, RoutedEventArgs _) =>
		{
			SortSelectedColumn(ascending: false);
		};
		menuItem14.Items.Add(menuItem16);
		menu.Items.Add(menuItem14);
		MenuItem menuItem17 = new MenuItem
		{
			Header = "Filtrar"
		};
		MenuItem menuItem18 = new MenuItem
		{
			Header = "Filtrar por valor…"
		};
		menuItem18.Click += (object _, RoutedEventArgs _) =>
		{
			Filter_Click(this, new RoutedEventArgs());
		};
		menuItem17.Items.Add(menuItem18);
		MenuItem menuItem19 = new MenuItem
		{
			Header = "Quitar filtros"
		};
		menuItem19.Click += (object _, RoutedEventArgs _) =>
		{
			ClearFilters();
		};
		menuItem17.Items.Add(menuItem19);
		menu.Items.Add(menuItem17);
		MenuItem menuItem20 = new MenuItem
		{
			Header = "Tabla"
		};
		MenuItem menuItem21 = new MenuItem
		{
			Header = "Aplicar estilo de tabla"
		};
		menuItem21.Click += (object _, RoutedEventArgs _) =>
		{
			Table_Click(this, new RoutedEventArgs());
		};
		menuItem20.Items.Add(menuItem21);
		MenuItem menuItem22 = new MenuItem
		{
			Header = "Filtrar tabla"
		};
		menuItem22.Click += (object _, RoutedEventArgs _) =>
		{
			Filter_Click(this, new RoutedEventArgs());
		};
		menuItem20.Items.Add(menuItem22);
		menu.Items.Add(menuItem20);
		MenuItem newItem = new MenuItem
		{
			Header = "Obtener datos de Tabla/Rango…",
			IsEnabled = false,
			ToolTip = "La importación avanzada de datos todavía no está implementada."
		};
		menu.Items.Add(newItem);
		Add("Nuevo comentario", () =>
		{
			SetCellNote(row, col, "comentario");
		});
		Add("Nueva nota", () =>
		{
			SetCellNote(row, col, "nota");
		});
		MenuItem menuItem23 = new MenuItem
		{
			Header = "Formato de celdas…"
		};
		(string, string)[] array = new (string, string)[5]
		{
			("General", "General"),
			("Número", "Number"),
			("Número con separador de miles", "Thousands"),
			("Moneda", "Currency"),
			("Porcentaje", "Percent")
		};
		for (int num = 0; num < array.Length; num++)
		{
			(string, string) tuple = array[num];
			string item = tuple.Item1;
			string key = tuple.Item2;
			MenuItem menuItem24 = new MenuItem
			{
				Header = item
			};
			menuItem24.Click += (object _, RoutedEventArgs _) =>
			{
				SetNumberFormatSelection(key);
			};
			menuItem23.Items.Add(menuItem24);
		}
		menu.Items.Add(menuItem23);
		Add("Elegir de la lista desplegable…", () =>
		{
			MessageBox.Show("La edición de listas desplegables todavía no está disponible en esta versión.", "GEXE", MessageBoxButton.OK, MessageBoxImage.Asterisk);
		});
		MenuItem menuItem25 = new MenuItem
		{
			Header = "Vínculo"
		};
		if (copiedCells != null && !string.Equals(copiedSheet, book.Sheets[activeSheet].Name, StringComparison.OrdinalIgnoreCase))
		{
			MenuItem menuItem26 = new MenuItem
			{
				Header = "Pegar vínculo al origen"
			};
			menuItem26.Click += (object _, RoutedEventArgs _) =>
			{
				PasteLink(row, col);
			};
			menuItem25.Items.Add(menuItem26);
		}
		MenuItem menuItem27 = new MenuItem
		{
			Header = "Insertar vínculo desde el portapapeles"
		};
		menuItem27.Click += (object _, RoutedEventArgs _) =>
		{
			PasteCell();
		};
		menuItem25.Items.Add(menuItem27);
		menu.Items.Add(menuItem25);
		search.TextChanged += (object _, TextChangedEventArgs _) =>
		{
			string text = search.Text.Trim();
			using IEnumerator<MenuItem> enumerator = (from x in menu.Items.OfType<MenuItem>()
				where x != searchHost
				select x).GetEnumerator();
			MenuItem current;
			int visibility;
			for (; enumerator.MoveNext(); current.Visibility = (Visibility)visibility)
			{
				current = enumerator.Current;
				if (text.Length != 0)
				{
					string? text2 = Convert.ToString(current.Header);
					if (text2 == null || !text2.Contains(text, StringComparison.CurrentCultureIgnoreCase))
					{
						visibility = 2;
						continue;
					}
				}
				visibility = 0;
			}
		};
		menu.PlacementTarget = dataGridCell;
		menu.Placement = PlacementMode.MousePoint;
		menu.IsOpen = true;
		e.Handled = true;
		MenuItem Add(string caption, Action action)
		{
			MenuItem menuItem28 = new MenuItem
			{
				Header = caption
			};
			menuItem28.Click += (object _, RoutedEventArgs _) =>
			{
				action();
			};
			menu.Items.Add(menuItem28);
			return menuItem28;
		}
	}

	private void SetNumberFormat(int row, int col, string format)
	{
		Sheet sheet = book.Sheets[activeSheet];
		string text = CellAddress(row, col);
		if (format == "General")
		{
			sheet.NumberFormats.Remove(text);
		}
		else
		{
			sheet.NumberFormats[text] = format;
		}
		Recalculate();
		Persist();
		StatusText.Text = "Formato " + format + " aplicado a " + text;
	}

	private void SetNumberFormatSelection(string format)
	{
		List<(int, int)> list = SelectedCoordinates();
		if (list.Count == 0)
		{
			return;
		}
		Sheet sheet = book.Sheets[activeSheet];
		foreach (var item3 in list)
		{
			int item = item3.Item1;
			int item2 = item3.Item2;
			string key = CellAddress(item, item2);
			if (format == "General")
			{
				sheet.NumberFormats.Remove(key);
			}
			else
			{
				sheet.NumberFormats[key] = format;
			}
		}
		Recalculate();
		Persist();
		StatusText.Text = $"Formato {format} aplicado a {list.Count} celdas";
	}

	private static T? FindVisualParent<T>(DependencyObject? node) where T : DependencyObject
	{
		while (node != null)
		{
			if (node is T result)
			{
				return result;
			}
			node = VisualTreeHelper.GetParent(node);
		}
		return null;
	}

	private void ToggleCheckbox(int row, int col)
	{
		string text = book.Sheets[activeSheet].Rows.ElementAtOrDefault(row)?.ElementAtOrDefault(col) ?? "☐";
		WriteCell(row, col, (text == "☑") ? "☐" : "☑");
	}

	private void Grid_BeginningEdit(object s, DataGridBeginningEditEventArgs e)
	{
		if (!CanUseApp)
		{
			e.Cancel = true;
			Dispatcher.BeginInvoke(new Action(CheckTrialAccess));
			return;
		}
		gridCellEditing = true;
		if (!(e.Row.Item is DataRowView dataRowView))
		{
			return;
		}
		int row = table.Rows.IndexOf(dataRowView.Row);
		int col = e.Column.DisplayIndex;
		NameBox.Text = $"{ColName(col)}{row + 1}";
		FormulaBox.Text = book.Sheets[activeSheet].Rows.ElementAtOrDefault(row)?.ElementAtOrDefault(col) ?? "";
		formulaTargetRow = row;
		formulaTargetCol = col;
		formulaMouseReferenceAnchor = null;
		formulaReferenceTextStart = null;
		lastMouseReference = null;
		Dispatcher.BeginInvoke((Action)(() =>
		{
			TextBox textBox = FindVisualChild<TextBox>(Grid);
			if (textBox != null)
			{
				AttachAutocompleteEditor(textBox, row, col);
			}
		}), DispatcherPriority.Input);
	}

	private void AttachAutocompleteEditor(TextBox editor, int row, int col)
	{
		if (autocompleteEditor != null)
		{
			autocompleteEditor.TextChanged -= CellEditor_TextChanged;
		}
		if (autocompletePopup != null)
		{
			autocompletePopup.IsOpen = false;
		}
		autocompleteEditor = editor;
		autocompleteRow = row;
		autocompleteCol = col;
		editor.TextChanged += CellEditor_TextChanged;
		EnsureAutocompletePopup(editor);
		RefreshCellSuggestions(editor);
	}

	private void EnsureAutocompletePopup(TextBox editor)
	{
		if (autocompletePopup == null || autocompletePopup.PlacementTarget != editor)
		{
			autocompleteList = new ListBox
			{
				Focusable = false,
				IsHitTestVisible = false,
				MaxHeight = 150.0,
				Padding = new Thickness(5.0),
				FontSize = 12.0,
				Background = Brushes.White,
				BorderThickness = new Thickness(0.0)
			};
			Border child = new Border
			{
				Background = Brushes.White,
				BorderBrush = new SolidColorBrush(Color.FromRgb(170, 180, 190)),
				BorderThickness = new Thickness(1.0),
				CornerRadius = new CornerRadius(2.0),
				Child = autocompleteList,
				MinWidth = Math.Max(180.0, editor.ActualWidth)
			};
			autocompletePopup = new Popup
			{
				Placement = PlacementMode.Bottom,
				PlacementTarget = editor,
				StaysOpen = true,
				AllowsTransparency = true,
				Focusable = false,
				Child = child
			};
		}
	}

	private void CellEditor_TextChanged(object sender, TextChangedEventArgs e)
	{
		if (sender is TextBox editor)
		{
			RefreshCellSuggestions(editor);
		}
	}

	private void RefreshCellSuggestions(TextBox editor)
	{
		if (editor != autocompleteEditor || autocompleteList == null || autocompletePopup == null)
		{
			return;
		}
		if (SuggestExistingCellValue(autocompleteRow, autocompleteCol, editor.Text) == null)
		{
			autocompletePopup.IsOpen = false;
			return;
		}
		List<string> list = (from x in book.Sheets[activeSheet].Rows.Select((List<string> cells, int index) => (cells: cells, index: index))
			where x.index != autocompleteRow && autocompleteCol < x.cells.Count
			select x.cells[autocompleteCol] into value
			where IsAutocompleteText(value) && value.StartsWith(editor.Text, StringComparison.CurrentCultureIgnoreCase) && !value.Equals(editor.Text, StringComparison.CurrentCultureIgnoreCase)
			select value).Distinct(StringComparer.CurrentCultureIgnoreCase).Take(6).ToList();
		if (list.Count == 0)
		{
			autocompletePopup.IsOpen = false;
			return;
		}
		autocompleteList.ItemsSource = list;
		autocompletePopup.PlacementTarget = editor;
		autocompletePopup.IsOpen = true;
	}

	private string? SuggestExistingCellValue(int row, int col, string prefix)
	{
		if (string.IsNullOrWhiteSpace(prefix) || prefix.StartsWith('=') || row < 0 || col < 0 || activeSheet >= book.Sheets.Count)
		{
			return null;
		}
		return (from x in book.Sheets[activeSheet].Rows.Select((List<string> cells, int index) => (cells: cells, index: index))
			where x.index != row && col < x.cells.Count
			select x.cells[col]).FirstOrDefault((string value) => IsAutocompleteText(value) && value.StartsWith(prefix, StringComparison.CurrentCultureIgnoreCase) && !value.Equals(prefix, StringComparison.CurrentCultureIgnoreCase));
	}

	private static bool IsAutocompleteText(string value)
	{
		DateTime result2;
		if (!string.IsNullOrWhiteSpace(value) && !value.StartsWith('=') && !double.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out var result) && !double.TryParse(value, NumberStyles.Any, CultureInfo.CurrentCulture, out result))
		{
			return !DateTime.TryParse(value, CultureInfo.CurrentCulture, DateTimeStyles.None, out result2);
		}
		return false;
	}

	private void AcceptCellSuggestion(TextBox editor)
	{
		string text = SuggestExistingCellValue(autocompleteRow, autocompleteCol, editor.Text);
		if (text != null)
		{
			editor.Text = text;
			editor.CaretIndex = editor.Text.Length;
			if (editor != FormulaBox)
			{
				FormulaBox.Text = text;
			}
			if (autocompletePopup != null)
			{
				autocompletePopup.IsOpen = false;
			}
		}
	}

	private void CloseCellSuggestions()
	{
		if (autocompletePopup != null)
		{
			autocompletePopup.IsOpen = false;
		}
	}

	private void Grid_SelectedCellsChanged(object s, SelectedCellsChangedEventArgs e)
	{
		List<int> changed = (from c in e.AddedCells.Concat(e.RemovedCells)
			select (!(c.Item is DataRowView dataRowView)) ? (-1) : table.Rows.IndexOf(dataRowView.Row) into r
			where r >= 0
			select r).Distinct().ToList();
		Dispatcher.BeginInvoke((Action)(() =>
		{
			foreach (int row in changed)
			{
				DataRowView dataRowView = table.DefaultView.Cast<DataRowView>().FirstOrDefault((DataRowView v) => table.Rows.IndexOf(v.Row) == row);
				if (dataRowView != null && Grid.ItemContainerGenerator.ContainerFromItem(dataRowView) is DataGridRow row2)
				{
					ApplyRowStyles(row2, row);
				}
			}
		}));
		if (Grid.SelectedCells.Count == 0 || applyingSelection)
		{
			return;
		}
		(int, int, int, int)? tuple = formulaReferenceRange;
		if (tuple.HasValue)
		{
			formulaReferenceRange = null;
			UpdateFormulaReferenceOutline();
		}
		List<(int, int)> list = (from c in Grid.SelectedCells
			select (!(c.Item is DataRowView dataRowView)) ? (row: -1, col: -1) : (row: table.Rows.IndexOf(dataRowView.Row), col: c.Column.DisplayIndex) into x
			where x.row >= 0
			select x).Distinct().ToList();
		if (list.Count != 0)
		{
			lastSelection = list;
			if (list.Count == 1 && !Keyboard.Modifiers.HasFlag(ModifierKeys.Shift))
			{
				shiftAnchor = list[0];
			}
			UpdateActiveCellFromGrid();
			Dispatcher.BeginInvoke(new Action(RefreshRibbonForSelection));
		}
	}

	private void UpdateActiveCellFromGrid()
	{
		DataGridCellInfo currentCell = Grid.CurrentCell;
		if (!currentCell.IsValid || !(currentCell.Item is DataRowView dataRowView))
		{
			return;
		}
		int num = table.Rows.IndexOf(dataRowView.Row);
		int displayIndex = currentCell.Column.DisplayIndex;
		if (num >= 0 && displayIndex >= 0)
		{
			NameBox.Text = $"{ColName(displayIndex)}{num + 1}";
			formulaTargetRow = num;
			formulaTargetCol = displayIndex;
			formulaEdit = true;
			FormulaBox.Text = book.Sheets[activeSheet].Rows.ElementAtOrDefault(num)?.ElementAtOrDefault(displayIndex) ?? "";
			formulaEdit = false;
			if (IsUsingCachedFormulaResult(activeSheet, num, displayIndex))
			{
				StatusText.Text = "Resultado conservado del XLSX; GOZT no puede recalcular esta fórmula.";
			}
		}
	}

	private static string FormatExcelDate(double serial, string fallback)
	{
		try
		{
			if (serial < 60.0)
			{
				serial++;
			}
			return DateTime.FromOADate(serial).ToString("d", CultureInfo.CurrentCulture);
		}
		catch
		{
			return fallback;
		}
	}

	private bool IsUsingCachedFormulaResult(int sheetIndex, int row, int col)
	{
		if (sheetIndex < 0 || sheetIndex >= book.Sheets.Count)
		{
			return false;
		}
		Sheet sheet = book.Sheets[sheetIndex];
		string key = CellAddress(row, col);
		string text = sheet.Rows.ElementAtOrDefault(row)?.ElementAtOrDefault(col) ?? "";
		if (!text.StartsWith('=') || !sheet.CachedFormulaValues.ContainsKey(key))
		{
			return false;
		}
		string text2 = EvaluateFormula(text, sheetIndex, row, col, new HashSet<string>());
		if (text2.StartsWith('#'))
		{
			return text2 != "#CIRC!";
		}
		return false;
	}

	private void RefreshSelectionRows(IEnumerable<(int row, int col)> cells)
	{
		Dispatcher.BeginInvoke((Action)(() =>
		{
			foreach (int row in cells.Select(((int row, int col) x) => x.row).Distinct())
			{
				DataRowView dataRowView = table.DefaultView.Cast<DataRowView>().FirstOrDefault((DataRowView v) => table.Rows.IndexOf(v.Row) == row);
				if (dataRowView != null && Grid.ItemContainerGenerator.ContainerFromItem(dataRowView) is DataGridRow row2)
				{
					ApplyRowStyles(row2, row);
				}
			}
		}));
	}

	private void SelectCoordinateRange(int top, int left, int bottom, int right, (int row, int col) active)
	{
		List<(int, int)> cells = (from r in Enumerable.Range(Math.Clamp(top, 0, table.Rows.Count - 1), Math.Clamp(bottom, top, table.Rows.Count - 1) - Math.Clamp(top, 0, table.Rows.Count - 1) + 1)
			from c in Enumerable.Range(Math.Clamp(left, 0, Grid.Columns.Count - 1), Math.Clamp(right, left, Grid.Columns.Count - 1) - Math.Clamp(left, 0, Grid.Columns.Count - 1) + 1)
			select (r: r, c: c)).ToList();
		shiftAnchor = (top, left);
		RestoreSelection(cells, active);
		Grid.Focus();
	}

	private void SetCellNote(int row, int col, string kind)
	{
		string text = CellAddress(row, col);
		Dictionary<string, string> cellNotes = book.Sheets[activeSheet].CellNotes;
		string text2 = PromptText((kind == "nota") ? "Nueva nota" : "Nuevo comentario", "Texto para " + text + ":", cellNotes.GetValueOrDefault(text) ?? "");
		if (text2 != null)
		{
			if (string.IsNullOrWhiteSpace(text2))
			{
				cellNotes.Remove(text);
			}
			else
			{
				cellNotes[text] = text2;
			}
			Persist();
			DataRowView dataRowView = table.DefaultView.Cast<DataRowView>().FirstOrDefault((DataRowView v) => table.Rows.IndexOf(v.Row) == row);
			if (dataRowView != null && Grid.ItemContainerGenerator.ContainerFromItem(dataRowView) is DataGridRow row2)
			{
				ApplyRowStyles(row2, row);
			}
			StatusText.Text = (string.IsNullOrWhiteSpace(text2) ? ("Nota de " + text + " eliminada") : ("Nota guardada en " + text + " · pasá el cursor para verla"));
		}
	}

	private void RefreshRibbonForSelection()
	{
		if (ribbonFontControl == null && ribbonFontSizeControl == null && ribbonNumberControl == null)
		{
			return;
		}
		List<(int, int)> list = SelectedCoordinates();
		if (list.Count == 0)
		{
			return;
		}
		(int, int) tuple = list[0];
		int item = tuple.Item1;
		int item2 = tuple.Item2;
		Sheet sheet = book.Sheets[activeSheet];
		CellStyleInfo cellStyleInfo = sheet.CellStyles.GetValueOrDefault(CellAddress(item, item2)) ?? new CellStyleInfo();
		string valueOrDefault = sheet.NumberFormats.GetValueOrDefault(CellAddress(item, item2), "General");
		refreshingRibbon = true;
		try
		{
			if (ribbonFontControl != null && ribbonFontControl.Items.Contains(cellStyleInfo.FontFamily))
			{
				ribbonFontControl.SelectedItem = cellStyleInfo.FontFamily;
			}
			if (ribbonFontSizeControl != null)
			{
				ribbonFontSizeControl.Text = cellStyleInfo.FontSize.ToString(CultureInfo.InvariantCulture);
			}
			if (ribbonNumberControl != null)
			{
				ComboBox comboBox = ribbonNumberControl;
				comboBox.SelectedItem = valueOrDefault switch
				{
					"Number" => (object)"Número", 
					"Thousands" => "Miles", 
					"Currency" => "Moneda", 
					"Percent" => "Porcentaje", 
					_ => "General", 
				};
			}
			if (ribbonFontColorBar != null)
			{
				ribbonFontColorBar.Background = TryBrush(cellStyleInfo.FontColor ?? "#C00000");
			}
			if (ribbonFontColorGlyph != null)
			{
				ribbonFontColorGlyph.Foreground = TryBrush(cellStyleInfo.FontColor) ?? new SolidColorBrush(Color.FromRgb(65, 65, 65));
			}
			if (ribbonFillColorBar != null)
			{
				ribbonFillColorBar.Background = TryBrush(cellStyleInfo.FillColor ?? "#FFC000");
			}
		}
		finally
		{
			refreshingRibbon = false;
		}
	}

	private void FormulaBox_Changed(object s, TextChangedEventArgs e)
	{
		if (!formulaEdit)
		{
			_ = Grid.SelectedCells.Count;
			_ = 0;
		}
	}

	private void FormulaBox_KeyDown(object s, KeyEventArgs e)
	{
		if (e.Key == Key.Enter && Grid.SelectedCells.Count != 0)
		{
			DataGridCellInfo dataGridCellInfo = Grid.SelectedCells[0];
			if (dataGridCellInfo.Item is DataRowView dataRowView)
			{
				int row = table.Rows.IndexOf(dataRowView.Row);
				int displayIndex = dataGridCellInfo.Column.DisplayIndex;
				WriteCell(row, displayIndex, FormulaBox.Text);
				e.Handled = true;
				MoveSelectedCell(0, 1);
			}
		}
	}

	private void AddSheet_Click(object s, RoutedEventArgs e)
	{
		CommitTable();
		string initial = "Hoja" + (book.Sheets.Count + 1);
		string text = PromptText("Nueva hoja", "Nombre de la hoja:", initial);
		if (text != null)
		{
			text = UniqueSheetName(text, -1);
			book.Sheets.Add(new Sheet
			{
				Name = text
			});
			activeSheet = book.Sheets.Count - 1;
			lastSelection = new List<(int, int)>();
			RenderSheet();
			RenderTabs();
			Persist();
		}
	}

	private string? PromptText(string title, string label, string initial)
	{
		Window dialog = new Window
		{
			Title = title,
			Width = 380.0,
			Height = 170.0,
			WindowStartupLocation = WindowStartupLocation.CenterScreen,
			ResizeMode = ResizeMode.NoResize,
			Background = Brushes.White
		};
		StackPanel stackPanel = new StackPanel
		{
			Margin = new Thickness(16.0)
		};
		stackPanel.Children.Add(new TextBlock
		{
			Text = label,
			Margin = new Thickness(0.0, 0.0, 0.0, 8.0)
		});
		TextBox input = new TextBox
		{
			Text = initial,
			Padding = new Thickness(6.0)
		};
		stackPanel.Children.Add(input);
		StackPanel stackPanel2 = new StackPanel
		{
			Orientation = Orientation.Horizontal,
			HorizontalAlignment = HorizontalAlignment.Right,
			Margin = new Thickness(0.0, 14.0, 0.0, 0.0)
		};
		Button button = new Button
		{
			Content = "Cancelar",
			Padding = new Thickness(10.0, 4.0, 10.0, 4.0),
			Margin = new Thickness(0.0, 0.0, 8.0, 0.0)
		};
		Button button2 = new Button
		{
			Content = "Aceptar",
			Padding = new Thickness(10.0, 4.0, 10.0, 4.0),
			IsDefault = true,
			Background = new SolidColorBrush(Color.FromRgb(33, 115, 70)),
			Foreground = Brushes.White
		};
		stackPanel2.Children.Add(button);
		stackPanel2.Children.Add(button2);
		stackPanel.Children.Add(stackPanel2);
		dialog.Content = stackPanel;
		string result = null;
		button.Click += (object _, RoutedEventArgs _) =>
		{
			dialog.Close();
		};
		button2.Click += (object _, RoutedEventArgs _) =>
		{
			string text = input.Text.Trim();
			if (text.Length == 0)
			{
				MessageBox.Show("El nombre no puede estar vacío.", title, MessageBoxButton.OK, MessageBoxImage.Asterisk);
			}
			else
			{
				result = text;
				dialog.Close();
			}
		};
		dialog.Loaded += (object _, RoutedEventArgs _) =>
		{
			input.Focus();
			input.SelectAll();
		};
		dialog.ShowDialog();
		return result;
	}

	private string UniqueSheetName(string candidate, int except)
	{
		candidate = SafeSheetName(candidate.Trim());
		if (candidate.Length == 0)
		{
			candidate = "Hoja";
		}
		string name = candidate;
		int num = 2;
		while (book.Sheets.Where((Sheet _, int i) => i != except).Any((Sheet sh) => string.Equals(sh.Name, name, StringComparison.OrdinalIgnoreCase)))
		{
			name = SafeSheetName(candidate + " (" + num++ + ")");
		}
		return name;
	}

	private void RenameSheet(int index)
	{
		if (index < 0 || index >= book.Sheets.Count)
		{
			return;
		}
		string name = book.Sheets[index].Name;
		string text = PromptText("Cambiar nombre de hoja", "Nombre de la hoja:", name);
		if (text == null)
		{
			return;
		}
		book.Sheets[index].Name = UniqueSheetName(text, index);
		foreach (Sheet sheet in book.Sheets)
		{
			foreach (CellLink value in sheet.CellLinks.Values)
			{
				if (string.Equals(value.SourceSheet, name, StringComparison.OrdinalIgnoreCase))
				{
					value.SourceSheet = book.Sheets[index].Name;
				}
			}
		}
		RenderTabs();
		Persist();
		StatusText.Text = "Hoja renombrada: " + book.Sheets[index].Name;
	}

	private void DuplicateSheet(int index)
	{
		if (index >= 0 && index < book.Sheets.Count)
		{
			CommitTable();
			Sheet sheet = JsonSerializer.Deserialize<Sheet>(JsonSerializer.Serialize(book.Sheets[index]));
			sheet.Name = UniqueSheetName(sheet.Name + " copia", -1);
			book.Sheets.Insert(index + 1, sheet);
			activeSheet = index + 1;
			lastSelection = new List<(int, int)>();
			RenderSheet();
			RenderTabs();
			Persist();
			StatusText.Text = "Hoja duplicada: " + sheet.Name;
		}
	}

	private void DeleteSheet(int index)
	{
		if (book.Sheets.Count <= 1)
		{
			MessageBox.Show("El libro debe conservar al menos una hoja.", "Eliminar hoja", MessageBoxButton.OK, MessageBoxImage.Asterisk);
		}
		else if (MessageBox.Show("¿Eliminar la hoja «" + book.Sheets[index].Name + "» y su contenido? Esta acción no se puede deshacer.", "Eliminar hoja", MessageBoxButton.YesNo, MessageBoxImage.Exclamation) == MessageBoxResult.Yes)
		{
			CommitTable();
			int num = activeSheet;
			book.Sheets.RemoveAt(index);
			if (index < activeSheet)
			{
				activeSheet--;
			}
			else if (index == activeSheet)
			{
				activeSheet = Math.Min(index, book.Sheets.Count - 1);
			}
			if (activeSheet != num)
			{
				lastSelection = new List<(int, int)>();
			}
			RenderSheet();
			RenderTabs();
			Persist();
		}
	}

	private void New_Click(object s, RoutedEventArgs e)
	{
		if (MessageBox.Show("¿Crear un libro nuevo? El libro actual queda en recuperación local.", "Nuevo libro", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
		{
			CommitTable();
			currentWorkbookPath = null;
			this.book.SyncId = Guid.NewGuid().ToString("N");
			this.book.Title = "Libro1";
			WorkbookTitle.Text = this.book.Title;
			Book book = this.book;
			int num = 1;
			List<Sheet> list = new List<Sheet>(num);
			CollectionsMarshal.SetCount(list, num);
			CollectionsMarshal.AsSpan(list)[0] = new Sheet
			{
				Name = "Hoja1"
			};
			book.Sheets = list;
			activeSheet = 0;
			lastSelection = new List<(int, int)>();
			RenderSheet();
			RenderTabs();
			CommitTable();
			ResetHistory();
			Persist();
		}
	}

	private void Open_Click(object s, RoutedEventArgs e)
	{
		OpenFileDialog openFileDialog = new OpenFileDialog
		{
			Filter = "Libros GEXE y Excel (*.gexe;*.xlsx)|*.gexe;*.xlsx|Libro GEXE multiplataforma (*.gexe)|*.gexe|Libro de Excel (*.xlsx)|*.xlsx"
		};
		if (openFileDialog.ShowDialog() == true)
		{
			OpenWorkbookFile(openFileDialog.FileName);
		}
	}

	private void OpenWorkbookFile(string path)
	{
		try
		{
			if (System.IO.Path.GetExtension(path).Equals(".gexe", StringComparison.OrdinalIgnoreCase))
			{
				Book book = JsonSerializer.Deserialize<Book>(File.ReadAllText(path));
				if (book == null || book.Sheets.Count == 0)
				{
					throw new InvalidDataException("El archivo GEXE no contiene hojas para abrir.");
				}
				this.book.SyncId = book.SyncId;
				this.book.Title = book.Title;
				this.book.Sheets = book.Sheets;
				this.book.Active = Math.Clamp(book.Active, 0, this.book.Sheets.Count - 1);
				activeSheet = this.book.Active;
				currentWorkbookPath = path;
				lastSelection = new List<(int, int)>();
				WorkbookTitle.Text = this.book.Title;
				RenderSheet();
				RenderTabs();
				CommitTable();
				ResetHistory();
				Persist();
				StatusText.Text = "Libro GEXE multiplataforma abierto";
				RememberRecentWorkbook(path);
				SaveStatus.Text = "Abierto · " + DateTime.Now.ToString("HH:mm");
				return;
			}
			using ZipArchive zipArchive = ZipFile.OpenRead(path);
			XNamespace m = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
			XNamespace xNamespace = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
			List<string> list = new List<string>();
			ZipArchiveEntry entry = zipArchive.GetEntry("xl/sharedStrings.xml");
			if (entry != null)
			{
				using Stream stream = entry.Open();
				list = (from si in XDocument.Load(stream).Descendants(m + "si")
					select string.Concat(from t in si.Descendants(m + "t")
						select t.Value)).ToList();
			}
			Dictionary<int, string> dictionary = ReadXlsxNumberFormats(zipArchive, m);
			Dictionary<int, CellStyleInfo> dictionary2 = ReadXlsxCellStyles(zipArchive, m);
			List<string> themeColors = ReadXlsxThemeColors(zipArchive);
			XDocument xDocument = LoadXml(zipArchive, "xl/workbook.xml");
			Dictionary<string, string> dictionary3 = (from x in LoadXml(zipArchive, "xl/_rels/workbook.xml.rels").Root.Elements()
				where x.Attribute("Id") != null && x.Attribute("Target") != null
				select x).ToDictionary((XElement x) => (string?)x.Attribute("Id"), (XElement x) => ResolveXlsxPartPath("xl/workbook.xml", (string?)x.Attribute("Target")));
			this.book.Sheets = new List<Sheet>();
			foreach (XElement item in xDocument.Descendants(m + "sheet"))
			{
				string name = ((string?)item.Attribute("name")) ?? "Hoja";
				string key = (string?)item.Attribute(xNamespace + "id");
				if (!dictionary3.TryGetValue(key, out var value))
				{
					continue;
				}
				XDocument xDocument2 = LoadXml(zipArchive, value);
				Sheet sheet = new Sheet
				{
					Name = name
				};
				List<XElement> list2 = xDocument2.Descendants(m + "c").ToList();
				int num = Math.Min(list2.Select((XElement c) => CellRow((string?)c.Attribute("r")) + 1).DefaultIfEmpty(1).Max(), 500);
				int num2 = Math.Min(list2.Select((XElement c) => CellCol((string?)c.Attribute("r")) + 1).DefaultIfEmpty(1).Max(), 26);
				for (int num3 = 0; num3 < num; num3++)
				{
					sheet.Rows.Add(Enumerable.Repeat("", num2).ToList());
				}
				Dictionary<string, (int, int, string)> dictionary4 = new Dictionary<string, (int, int, string)>();
				foreach (XElement item2 in list2)
				{
					string text = (string?)item2.Attribute("r");
					int num4 = CellRow(text);
					int num5 = CellCol(text);
					if (num4 >= num || num5 >= num2)
					{
						continue;
					}
					XElement xElement = item2.Element(m + "f");
					string text2 = item2.Element(m + "v")?.Value ?? "";
					int result;
					if (xElement != null)
					{
						string text3 = ((string?)xElement.Attribute("t")) ?? "";
						string text4 = (string?)xElement.Attribute("si");
						string value2 = xElement.Value;
						(int, int, string) value4;
						if (value2.Length > 0)
						{
							if (text3 == "shared" && text4 != null)
							{
								dictionary4[text4] = (num4, num5, value2);
							}
							Match match = Regex.Match(value2, "^(.+)!\\$?([A-Z]{1,3})\\$?(\\d+)$");
							string value3 = match.Groups[1].Value;
							if (match.Success && value3.StartsWith("'") && value3.EndsWith("'"))
							{
								string text5 = value3;
								value3 = text5.Substring(1, text5.Length - 1 - 1).Replace("''", "'");
								sheet.CellLinks[text] = new CellLink
								{
									SourceSheet = value3,
									SourceRow = int.Parse(match.Groups[3].Value) - 1,
									SourceCol = ColIndex(match.Groups[2].Value)
								};
							}
							else
							{
								sheet.Rows[num4][num5] = "=" + value2;
							}
						}
						else if (text3 == "shared" && text4 != null && dictionary4.TryGetValue(text4, out value4))
						{
							sheet.Rows[num4][num5] = "=" + TranslateSharedFormula(value4.Item3, num4 - value4.Item1, num5 - value4.Item2);
						}
						else if (text2.Length > 0)
						{
							sheet.Rows[num4][num5] = text2;
						}
						XElement xElement2 = item2.Element(m + "v");
						if (xElement2 != null)
						{
							sheet.CachedFormulaValues[text] = xElement2.Value;
							string text6 = (string?)item2.Attribute("t");
							if (text6 != null)
							{
								sheet.CachedFormulaTypes[text] = text6;
							}
						}
					}
					else if ((string?)item2.Attribute("t") == "s" && int.TryParse(text2, out result) && result < list.Count)
					{
						sheet.Rows[num4][num5] = list[result];
					}
					else if ((string?)item2.Attribute("t") == "inlineStr")
					{
						sheet.Rows[num4][num5] = string.Concat(from t in item2.Descendants(m + "t")
							select t.Value);
					}
					else
					{
						sheet.Rows[num4][num5] = text2;
					}
					if (int.TryParse((string?)item2.Attribute("s"), out var result2))
					{
						if (dictionary.TryGetValue(result2, out var value5))
						{
							sheet.NumberFormats[text] = value5;
						}
						if (dictionary2.TryGetValue(result2, out var value6))
						{
							sheet.CellStyles[text] = value6;
						}
					}
				}
				ApplyXlsxTableStyles(zipArchive, xDocument2, value, sheet, m, themeColors);
				this.book.Sheets.Add(sheet);
			}
			if (this.book.Sheets.Count == 0)
			{
				this.book.Sheets.Add(new Sheet());
			}
			this.book.SyncId = Guid.NewGuid().ToString("N");
			this.book.Title = System.IO.Path.GetFileNameWithoutExtension(path);
			activeSheet = 0;
			lastSelection = new List<(int, int)>();
			currentWorkbookPath = path;
			WorkbookTitle.Text = this.book.Title;
			RenderSheet();
			RenderTabs();
			CommitTable();
			ResetHistory();
			Persist();
			StatusText.Text = "Libro XLSX abierto";
			RememberRecentWorkbook(path);
			SaveStatus.Text = "Guardado · " + DateTime.Now.ToString("HH:mm");
		}
		catch (Exception ex)
		{
			MessageBox.Show("No se pudo abrir el libro: " + ex.Message, "GEXE", MessageBoxButton.OK, MessageBoxImage.Error);
		}
	}

	private void Save_Click(object s, RoutedEventArgs e)
	{
		SaveAsWorkbook();
	}

	private void SaveCurrent_Click(object s, RoutedEventArgs e)
	{
		SaveCurrentWorkbook();
	}

	private void MainWindow_PreviewKeyDown(object sender, KeyEventArgs e)
	{
		if (!CanUseApp)
		{
			e.Handled = true;
			Dispatcher.BeginInvoke(new Action(CheckTrialAccess));
		}
		else
		{
			if (e.Handled || e.OriginalSource is TextBox)
			{
				return;
			}
			ModifierKeys modifiers = Keyboard.Modifiers;
			if (modifiers.HasFlag(ModifierKeys.Control))
			{
				if (e.Key == Key.Y || (e.Key == Key.Z && modifiers.HasFlag(ModifierKeys.Shift)))
				{
					Redo_Click(this, new RoutedEventArgs());
					e.Handled = true;
				}
				else if (e.Key == Key.Z)
				{
					Undo_Click(this, new RoutedEventArgs());
					e.Handled = true;
				}
			}
		}
	}

	private void WorkbookTitle_MouseLeftButtonDown(object s, MouseButtonEventArgs e)
	{
		if (e.ClickCount == 2)
		{
			e.Handled = true;
			RenameWorkbook();
		}
	}

	private void RenameWorkbook_Click(object s, RoutedEventArgs e)
	{
		RenameWorkbook();
	}

	private void RenameWorkbook()
	{
		string text = PromptText("Cambiar nombre del libro", "Escribí el nuevo nombre:", WorkbookTitle.Text);
		if (string.IsNullOrWhiteSpace(text))
		{
			return;
		}
		text = SafeFileName(text.Trim());
		if (text.Length == 0)
		{
			return;
		}
		CommitTable();
		string text2 = currentWorkbookPath;
		book.Title = text;
		WorkbookTitle.Text = text;
		if (string.IsNullOrWhiteSpace(text2))
		{
			Persist();
			StatusText.Text = "Nombre del libro actualizado";
			return;
		}
		try
		{
			Directory.CreateDirectory(BooksDirectory);
			string text3 = System.IO.Path.Combine(BooksDirectory, text + ".xlsx");
			if (string.Equals(text2, text3, StringComparison.OrdinalIgnoreCase))
			{
				Persist();
				StatusText.Text = "Nombre del libro actualizado";
				return;
			}
			if (File.Exists(text3))
			{
				book.Title = System.IO.Path.GetFileNameWithoutExtension(text2);
				WorkbookTitle.Text = book.Title;
				MessageBox.Show("Ya existe un libro con ese nombre en Continuar libro guardado.", "Cambiar nombre", MessageBoxButton.OK, MessageBoxImage.Asterisk);
				return;
			}
			SaveWorkbookTo(text3);
			if (!string.Equals(currentWorkbookPath, text3, StringComparison.OrdinalIgnoreCase))
			{
				book.Title = System.IO.Path.GetFileNameWithoutExtension(text2);
				WorkbookTitle.Text = book.Title;
				return;
			}
			if (IsManagedWorkbook(text2) && File.Exists(text2))
			{
				File.Delete(text2);
			}
			UpdateRecentWorkbookPath(text2, text3);
			Persist();
			StatusText.Text = (IsManagedWorkbook(text2) ? "Libro renombrado" : "Copia renombrada en la biblioteca GOZT; el archivo recibido se conservó");
		}
		catch (Exception ex)
		{
			book.Title = System.IO.Path.GetFileNameWithoutExtension(text2);
			WorkbookTitle.Text = book.Title;
			MessageBox.Show("No se pudo cambiar el nombre del libro: " + ex.Message, "Cambiar nombre", MessageBoxButton.OK, MessageBoxImage.Error);
		}
	}

	private void SaveCurrentWorkbook()
	{
		if (string.IsNullOrWhiteSpace(currentWorkbookPath))
		{
			SaveAsWorkbook();
			return;
		}
		CommitTable();
		if (System.IO.Path.GetExtension(currentWorkbookPath).Equals(".gexe", StringComparison.OrdinalIgnoreCase))
		{
			SaveGexeBook(currentWorkbookPath);
		}
		else if (!IsManagedWorkbook(currentWorkbookPath))
		{
			SaveAsWorkbook();
		}
		else
		{
			SaveWorkbookTo(currentWorkbookPath);
		}
	}

	private void SaveAsWorkbook()
	{
		CommitTable();
		Directory.CreateDirectory(BooksDirectory);
		string name = (string.IsNullOrWhiteSpace(currentWorkbookPath) ? System.IO.Path.GetFileNameWithoutExtension(WorkbookTitle.Text) : System.IO.Path.GetFileNameWithoutExtension(currentWorkbookPath));
		SaveFileDialog saveFileDialog = new SaveFileDialog
		{
			Filter = "Libro de Excel (*.xlsx)|*.xlsx|Libro GEXE multiplataforma (*.gexe)|*.gexe",
			InitialDirectory = BooksDirectory,
			FileName = SafeFileName(name) + "-GOZT.xlsx",
			DefaultExt = ".xlsx",
			AddExtension = true,
			OverwritePrompt = true
		};
		if (saveFileDialog.ShowDialog() == true)
		{
			if (System.IO.Path.GetExtension(saveFileDialog.FileName).Equals(".gexe", StringComparison.OrdinalIgnoreCase))
			{
				SaveGexeBook(saveFileDialog.FileName);
			}
			else
			{
				SaveWorkbookTo(saveFileDialog.FileName);
			}
			if (IsManagedWorkbook(saveFileDialog.FileName))
			{
				StatusText.Text = "Libro guardado en Mi biblioteca GOZT";
			}
		}
	}

	private void SaveAsGexeBook()
	{
		CommitTable();
		Directory.CreateDirectory(BooksDirectory);
		string name = (string.IsNullOrWhiteSpace(currentWorkbookPath) ? System.IO.Path.GetFileNameWithoutExtension(WorkbookTitle.Text) : System.IO.Path.GetFileNameWithoutExtension(currentWorkbookPath));
		SaveFileDialog saveFileDialog = new SaveFileDialog
		{
			Filter = "Libro GEXE multiplataforma (*.gexe)|*.gexe",
			InitialDirectory = BooksDirectory,
			FileName = SafeFileName(name) + ".gexe",
			DefaultExt = ".gexe",
			AddExtension = true,
			OverwritePrompt = true
		};
		if (saveFileDialog.ShowDialog() == true)
		{
			SaveGexeBook(saveFileDialog.FileName);
		}
	}

	private void SaveGexeBook(string path)
	{
		try
		{
			book.Active = activeSheet;
			book.Title = System.IO.Path.GetFileNameWithoutExtension(path);
			string text = path + ".tmp";
			File.WriteAllText(text, JsonSerializer.Serialize(book));
			File.Move(text, path, overwrite: true);
			currentWorkbookPath = path;
			WorkbookTitle.Text = book.Title;
			RememberRecentWorkbook(path);
			Persist();
			SaveStatus.Text = "Guardado · " + DateTime.Now.ToString("HH:mm");
			StatusText.Text = "Libro GEXE multiplataforma guardado";
		}
		catch (Exception ex)
		{
			MessageBox.Show("No se pudo guardar el libro GEXE: " + ex.Message, "GEXE", MessageBoxButton.OK, MessageBoxImage.Error);
		}
	}

	private ExportCellStyle GetExportStyle(Sheet sheet, string address)
	{
		sheet.CellStyles.TryGetValue(address, out CellStyleInfo value);
		return new ExportCellStyle(sheet.NumberFormats.GetValueOrDefault(address, ""), value?.FontFamily, value?.FontSize, value?.Bold, value?.Italic, value?.Underline, value?.FontColor, value?.FillColor, value?.HorizontalAlignment, value?.BorderColor);
	}

	private XDocument BuildXlsxStyles(out Dictionary<ExportCellStyle, int> ids)
	{
		XNamespace m = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
		ExportCellStyle defaults = new ExportCellStyle("", null, null, null, null, null, null, null, null, null);
		List<ExportCellStyle> list = (from x in book.Sheets.SelectMany((Sheet sh) => sh.CellStyles.Keys.Concat(sh.NumberFormats.Keys)).Distinct(StringComparer.OrdinalIgnoreCase).SelectMany((string addr) => from sh in book.Sheets
				select (sh: sh, addr: addr) into x
				where x.sh.CellStyles.ContainsKey(addr) || x.sh.NumberFormats.ContainsKey(addr)
				select GetExportStyle(x.sh, addr))
			where x != defaults
			select x).Distinct().ToList();
		List<ExportFont> fonts = new List<ExportFont>
		{
			new ExportFont("Calibri", 11.0, null, null, null, null)
		};
		foreach (ExportFont item2 in from f in list.Select(FontFor)
			where f != fonts[0]
			select f)
		{
			if (!fonts.Contains(item2))
			{
				fonts.Add(item2);
			}
		}
		List<string?> fills = new List<string> { null, "#FFFFFF" };
		foreach (string item3 in from x in list
			select x.FillColor into x
			where !string.IsNullOrWhiteSpace(x) && !string.Equals(x, "#FFFFFF", StringComparison.OrdinalIgnoreCase)
			select x)
		{
			if (!fills.Contains(item3, StringComparer.OrdinalIgnoreCase))
			{
				fills.Add(item3);
			}
		}
		List<string?> borderColors = new List<string> { null };
		foreach (string item4 in from x in list
			select x.BorderColor into x
			where !string.IsNullOrWhiteSpace(x)
			select x)
		{
			if (!borderColors.Contains(item4, StringComparer.OrdinalIgnoreCase))
			{
				borderColors.Add(item4);
			}
		}
		ids = new Dictionary<ExportCellStyle, int> { { defaults, 0 } };
		foreach (ExportCellStyle item5 in list)
		{
			if (!ids.ContainsKey(item5))
			{
				ids[item5] = ids.Count;
			}
		}
		IEnumerable<XElement> enumerable = fonts.Select((ExportFont f) => new XElement(m + "font", (f.Bold == true) ? new XElement(m + "b") : null, (f.Italic == true) ? new XElement(m + "i") : null, (f.Underline == true) ? new XElement(m + "u") : null, new XElement(m + "sz", new XAttribute("val", f.Size ?? 11.0)), (f.Color == null) ? null : new XElement(m + "color", new XAttribute("rgb", "FF" + f.Color.TrimStart('#'))), new XElement(m + "name", new XAttribute("val", f.Family ?? "Calibri"))));
		IEnumerable<XElement> enumerable2 = fills.Select((string color, int i) => new XElement(m + "fill", (color == null) ? new XElement(m + "patternFill", new XAttribute("patternType", (i == 1) ? "gray125" : "none")) : new XElement(m + "patternFill", new XAttribute("patternType", "solid"), new XElement(m + "fgColor", new XAttribute("rgb", "FF" + color.TrimStart('#'))), new XElement(m + "bgColor", new XAttribute("indexed", 64)))));
		IEnumerable<XElement> enumerable3 = borderColors.Select((string color) => new XElement(m + "border", BorderSide("left", color), BorderSide("right", color), BorderSide("top", color), BorderSide("bottom", color), new XElement(m + "diagonal")));
		List<XElement> list2 = new List<XElement>();
		list2.Add(new XElement(m + "xf", new XAttribute("numFmtId", 0), new XAttribute("fontId", 0), new XAttribute("fillId", 0), new XAttribute("borderId", 0), new XAttribute("xfId", 0)));
		List<XElement> list3 = list2;
		foreach (ExportCellStyle item6 in list)
		{
			int num = NumberFormatId(item6.NumberFormat);
			int num2 = BorderId(item6);
			XElement xElement = new XElement(m + "xf", new XAttribute("numFmtId", num), new XAttribute("fontId", FontId(item6)), new XAttribute("fillId", FillId(item6)), new XAttribute("borderId", num2), new XAttribute("xfId", 0), new XAttribute("applyFont", 1), new XAttribute("applyFill", 1));
			if (num2 != 0)
			{
				xElement.Add(new XAttribute("applyBorder", 1));
			}
			if (num != 0)
			{
				xElement.Add(new XAttribute("applyNumberFormat", 1));
			}
			string horizontalAlignment = item6.HorizontalAlignment;
			if ((horizontalAlignment == "Center" || horizontalAlignment == "Right") ? true : false)
			{
				xElement.Add(new XAttribute("applyAlignment", 1), new XElement(m + "alignment", new XAttribute("horizontal", item6.HorizontalAlignment.ToLowerInvariant())));
			}
			list3.Add(xElement);
		}
		return new XDocument(new XElement(m + "styleSheet", new XElement(m + "numFmts", new XAttribute("count", 2), new XElement(m + "numFmt", new XAttribute("numFmtId", 164), new XAttribute("formatCode", "#,##0")), new XElement(m + "numFmt", new XAttribute("numFmtId", 165), new XAttribute("formatCode", "$#,##0.00"))), new XElement(m + "fonts", new XAttribute("count", fonts.Count), enumerable), new XElement(m + "fills", new XAttribute("count", fills.Count), enumerable2), new XElement(m + "borders", new XAttribute("count", enumerable3.Count()), enumerable3), new XElement(m + "cellStyleXfs", new XAttribute("count", 1), new XElement(m + "xf", new XAttribute("numFmtId", 0), new XAttribute("fontId", 0), new XAttribute("fillId", 0), new XAttribute("borderId", 0))), new XElement(m + "cellXfs", new XAttribute("count", list3.Count), list3), new XElement(m + "cellStyles", new XAttribute("count", 1), new XElement(m + "cellStyle", new XAttribute("name", "Normal"), new XAttribute("xfId", 0), new XAttribute("builtinId", 0)))));
		int BorderId(ExportCellStyle s)
		{
			if (string.IsNullOrWhiteSpace(s.BorderColor))
			{
				return 0;
			}
			int num3 = borderColors.FindIndex((string? x) => string.Equals(x, s.BorderColor, StringComparison.OrdinalIgnoreCase));
			if (num3 >= 0)
			{
				return num3;
			}
			return 0;
		}
		XElement BorderSide(string side, string? color)
		{
			if (color != null)
			{
				return new XElement(m + side, new XAttribute("style", "thin"), new XElement(m + "color", new XAttribute("rgb", "FF" + color.TrimStart('#'))));
			}
			return new XElement(m + side);
		}
		int FillId(ExportCellStyle s)
		{
			if (string.IsNullOrWhiteSpace(s.FillColor))
			{
				return 0;
			}
			int num3 = fills.FindIndex((string? x) => string.Equals(x, s.FillColor, StringComparison.OrdinalIgnoreCase));
			if (num3 >= 0)
			{
				return num3;
			}
			return 0;
		}
		static ExportFont FontFor(ExportCellStyle s)
		{
			return new ExportFont(s.FontFamily, s.FontSize, s.Bold, s.Italic, s.Underline, s.FontColor);
		}
		int FontId(ExportCellStyle s)
		{
			ExportFont item = FontFor(s);
			int num3 = fonts.IndexOf(item);
			if (num3 >= 0)
			{
				return num3;
			}
			return 0;
		}
		static int NumberFormatId(string f)
		{
			return f switch
			{
				"Number" => 4, 
				"Thousands" => 3, 
				"Currency" => 165, 
				"Percent" => 10, 
				"Date" => 14, 
				_ => 0, 
			};
		}
	}

	private void SaveWorkbookTo(string path)
	{
		try
		{
			ZipArchive zip = ZipFile.Open(path, ZipArchiveMode.Create);
			try
			{
				XNamespace m = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
				XNamespace rel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
				XNamespace ct = "http://schemas.openxmlformats.org/package/2006/content-types";
				Put("[Content_Types].xml", new XDocument(new XElement(ct + "Types", new XElement(ct + "Default", new XAttribute("Extension", "rels"), new XAttribute("ContentType", "application/vnd.openxmlformats-package.relationships+xml")), new XElement(ct + "Default", new XAttribute("Extension", "xml"), new XAttribute("ContentType", "application/xml")), new XElement(ct + "Override", new XAttribute("PartName", "/xl/workbook.xml"), new XAttribute("ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml")), new XElement(ct + "Override", new XAttribute("PartName", "/xl/styles.xml"), new XAttribute("ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml")), book.Sheets.Select((Sheet _, int i) => new XElement(ct + "Override", new XAttribute("PartName", $"/xl/worksheets/sheet{i + 1}.xml"), new XAttribute("ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"))))));
				XNamespace pkg = "http://schemas.openxmlformats.org/package/2006/relationships";
				Put("_rels/.rels", new XDocument(new XElement(pkg + "Relationships", new XElement(pkg + "Relationship", new XAttribute("Id", "rId1"), new XAttribute("Type", "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument"), new XAttribute("Target", "xl/workbook.xml")))));
				Put("xl/workbook.xml", new XDocument(new XElement(m + "workbook", new XAttribute(XNamespace.Xmlns + "r", rel), new XElement(m + "sheets", book.Sheets.Select((Sheet sh, int i) => new XElement(m + "sheet", new XAttribute("name", SafeSheetName(sh.Name)), new XAttribute("sheetId", i + 1), new XAttribute(rel + "id", $"rId{i + 1}")))))));
				Put("xl/_rels/workbook.xml.rels", new XDocument(new XElement(pkg + "Relationships", book.Sheets.Select((Sheet _, int i) => new XElement(pkg + "Relationship", new XAttribute("Id", $"rId{i + 1}"), new XAttribute("Type", "http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet"), new XAttribute("Target", $"worksheets/sheet{i + 1}.xml"))), new XElement(pkg + "Relationship", new XAttribute("Id", $"rId{book.Sheets.Count + 1}"), new XAttribute("Type", "http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles"), new XAttribute("Target", "styles.xml")))));
				Put("xl/styles.xml", BuildXlsxStyles(out Dictionary<ExportCellStyle, int> ids));
				for (int num = 0; num < book.Sheets.Count; num++)
				{
					Sheet sheet = book.Sheets[num];
					List<XElement> list = new List<XElement>();
					for (int num2 = 0; num2 < sheet.Rows.Count; num2++)
					{
						List<XElement> list2 = new List<XElement>();
						for (int num3 = 0; num3 < sheet.Rows[num2].Count; num3++)
						{
							string text = sheet.Rows[num2][num3];
							string text2 = CellAddress(num2, num3);
							bool flag = sheet.CellLinks.TryGetValue(text2, out CellLink value);
							ExportCellStyle exportStyle = GetExportStyle(sheet, text2);
							bool flag2 = ids.TryGetValue(exportStyle, out var value2) && value2 > 0;
							if (text.Length == 0 && !flag && !flag2)
							{
								continue;
							}
							XElement xElement = new XElement(m + "c", new XAttribute("r", text2));
							if (flag2)
							{
								xElement.Add(new XAttribute("s", value2));
							}
							double result;
							if (flag)
							{
								xElement.Add(new XElement(m + "f", "'" + value.SourceSheet.Replace("'", "''") + "'!" + CellAddress(value.SourceRow, value.SourceCol)));
							}
							else if (text.StartsWith('='))
							{
								xElement.Add(new XElement(m + "f", text.Substring(1)));
								if (sheet.CachedFormulaValues.TryGetValue(text2, out string value3))
								{
									string valueOrDefault = sheet.CachedFormulaTypes.GetValueOrDefault(text2, "");
									bool flag3;
									switch (valueOrDefault)
									{
									case "str":
									case "e":
									case "b":
										flag3 = true;
										break;
									default:
										flag3 = false;
										break;
									}
									if (flag3)
									{
										xElement.Add(new XAttribute("t", valueOrDefault));
									}
									string content;
									if (valueOrDefault == "b")
									{
										content = ((value3.Equals("TRUE", StringComparison.OrdinalIgnoreCase) || value3 == "1") ? "1" : "0");
									}
									else
									{
										content = value3;
									}
									xElement.Add(new XElement(m + "v", content));
								}
							}
							else if (double.TryParse(text, NumberStyles.Any, CultureInfo.InvariantCulture, out result))
							{
								xElement.Add(new XElement(m + "v", result.ToString("R", CultureInfo.InvariantCulture)));
							}
							else
							{
								xElement.Add(new XAttribute("t", "inlineStr"), new XElement(m + "is", new XElement(m + "t", new XAttribute(XNamespace.Xml + "space", "preserve"), text)));
							}
							list2.Add(xElement);
						}
						list.Add(new XElement(m + "row", new XAttribute("r", num2 + 1), list2));
					}
					XDocument doc = new XDocument(new XElement(m + "worksheet", new XElement(m + "sheetViews", new XElement(m + "sheetView", new XAttribute("workbookViewId", 0), new XElement(m + "pane", new XAttribute("ySplit", 1), new XAttribute("topLeftCell", "A2"), new XAttribute("activePane", "bottomLeft"), new XAttribute("state", "frozen")))), new XElement(m + "sheetData", list)));
					Put($"xl/worksheets/sheet{num + 1}.xml", doc);
				}
				currentWorkbookPath = path;
				book.Title = System.IO.Path.GetFileNameWithoutExtension(path);
				WorkbookTitle.Text = book.Title;
				StatusText.Text = "Guardado como XLSX";
				RememberRecentWorkbook(path);
				SaveStatus.Text = "Guardado · " + DateTime.Now.ToString("HH:mm");
				Persist();
			}
			finally
			{
				if (zip != null)
				{
					((IDisposable)zip).Dispose();
				}
			}
			void Put(string entryName, XDocument xDocument)
			{
				using Stream stream = zip.CreateEntry(entryName).Open();
				xDocument.Save(stream);
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show("No se pudo guardar el libro: " + ex.Message, "GEXE", MessageBoxButton.OK, MessageBoxImage.Error);
		}
	}

	private void Filter_Click(object s, RoutedEventArgs e)
	{
		if (Grid.SelectedCells.Count == 0)
		{
			return;
		}
		int col = Grid.SelectedCells[0].Column.DisplayIndex;
		List<string> itemsSource = (from DataRow r in table.Rows
			select Convert.ToString(r[col]) ?? "" into x
			where x.Length > 0
			select x).Distinct().OrderBy((string x) => x, StringComparer.CurrentCultureIgnoreCase).ToList();
		Window picker = new Window
		{
			Title = "Filtrar " + ColName(col),
			Width = 360.0,
			Height = 155.0,
			WindowStartupLocation = WindowStartupLocation.CenterOwner,
			Owner = this,
			ResizeMode = ResizeMode.NoResize,
			Background = Brushes.White
		};
		StackPanel stackPanel = new StackPanel
		{
			Margin = new Thickness(16.0)
		};
		stackPanel.Children.Add(new TextBlock
		{
			Text = "Mostrar filas cuyo valor sea:",
			Margin = new Thickness(0.0, 0.0, 0.0, 8.0)
		});
		ComboBox comboBox = new ComboBox
		{
			IsEditable = true,
			ItemsSource = itemsSource,
			Height = 28.0
		};
		stackPanel.Children.Add(comboBox);
		StackPanel stackPanel2 = new StackPanel
		{
			Orientation = Orientation.Horizontal,
			HorizontalAlignment = HorizontalAlignment.Right,
			Margin = new Thickness(0.0, 12.0, 0.0, 0.0)
		};
		Button button = new Button
		{
			Content = "Quitar filtro",
			Padding = new Thickness(10.0, 5.0, 10.0, 5.0),
			Margin = new Thickness(0.0, 0.0, 8.0, 0.0)
		};
		Button button2 = new Button
		{
			Content = "Aplicar",
			Padding = new Thickness(14.0, 5.0, 14.0, 5.0),
			IsDefault = true,
			Background = new SolidColorBrush(Color.FromRgb(33, 115, 70)),
			Foreground = Brushes.White
		};
		stackPanel2.Children.Add(button);
		stackPanel2.Children.Add(button2);
		stackPanel.Children.Add(stackPanel2);
		picker.Content = stackPanel;
		bool accepted = false;
		button2.Click += (object _, RoutedEventArgs _) =>
		{
			accepted = true;
			picker.Close();
		};
		button.Click += (object _, RoutedEventArgs _) =>
		{
			if (Grid.ItemsSource is DataView dataView2)
			{
				dataView2.RowFilter = "";
			}
			picker.Close();
			StatusText.Text = "Filtro quitado";
		};
		picker.ShowDialog();
		if (accepted)
		{
			string text = comboBox.Text.Replace("'", "''");
			if (Grid.ItemsSource is DataView dataView)
			{
				dataView.RowFilter = ((text.Length == 0) ? ("ISNULL([" + ColName(col) + "], '') = ''") : $"[{ColName(col)}] = '{text}'");
				StatusText.Text = "Filtro " + ColName(col) + ": " + comboBox.Text;
			}
		}
	}

	private void Table_Click(object s, RoutedEventArgs e)
	{
		ShowTableStylePicker();
	}

	private void ShowTableStylePicker()
	{
		List<(int, int)> list = SelectedCoordinates();
		if (list.Count == 0)
		{
			MessageBox.Show("Seleccioná el rango de celdas que querés convertir en tabla. Mantené Shift mientras extendés la selección.", "Insertar tabla", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			return;
		}
		(int, int, int, int) tuple = (list.Min(((int row, int col) x) => x.row), list.Min(((int row, int col) x) => x.col), list.Max(((int row, int col) x) => x.row), list.Max(((int row, int col) x) => x.col));
		Window dialog = new Window
		{
			Title = "Elegir estilo de tabla",
			Width = 540.0,
			Height = 330.0,
			WindowStartupLocation = WindowStartupLocation.CenterScreen,
			ResizeMode = ResizeMode.NoResize,
			Background = Brushes.White
		};
		StackPanel stackPanel = new StackPanel
		{
			Margin = new Thickness(18.0)
		};
		stackPanel.Children.Add(new TextBlock
		{
			Text = "Aplicar al rango " + CellAddress(tuple.Item1, tuple.Item2) + ":" + CellAddress(tuple.Item3, tuple.Item4),
			FontSize = 18.0,
			FontWeight = FontWeights.SemiBold,
			Margin = new Thickness(0.0, 0.0, 0.0, 12.0)
		});
		string selected = null;
		(string, string, string)[] array = new (string, string, string)[6]
		{
			("Verde", "#217346", "#E2F0D9"),
			("Azul", "#4472C4", "#DDEBF7"),
			("Morado", "#7030A0", "#E4DFEC"),
			("Naranja", "#ED7D31", "#FCE4D6"),
			("Rojo", "#C00000", "#F4CCCC"),
			("Gris", "#5B6573", "#E7E9EC")
		};
		UniformGrid uniformGrid = new UniformGrid
		{
			Columns = 3
		};
		(string, string, string)[] array2 = array;
		for (int num = 0; num < array2.Length; num++)
		{
			(string, string, string) tuple2 = array2[num];
			string item = tuple2.Item1;
			string dark = tuple2.Item2;
			string light = tuple2.Item3;
			Button button = new Button
			{
				Padding = new Thickness(10.0),
				Margin = new Thickness(4.0),
				Background = Brushes.White,
				BorderBrush = new SolidColorBrush(Color.FromRgb(218, 224, 231))
			};
			StackPanel stackPanel2 = new StackPanel();
			stackPanel2.Children.Add(new Border
			{
				Height = 26.0,
				Background = TryBrush(dark),
				Child = new TextBlock
				{
					Text = "Encabezado",
					Foreground = Brushes.White,
					FontWeight = FontWeights.SemiBold,
					VerticalAlignment = VerticalAlignment.Center,
					Margin = new Thickness(5.0, 0.0, 5.0, 0.0)
				}
			});
			stackPanel2.Children.Add(new Border
			{
				Height = 25.0,
				Background = TryBrush(light),
				Child = new TextBlock
				{
					Text = "Fila de ejemplo",
					Foreground = Brushes.Black,
					VerticalAlignment = VerticalAlignment.Center,
					Margin = new Thickness(5.0, 0.0, 5.0, 0.0)
				}
			});
			stackPanel2.Children.Add(new TextBlock
			{
				Text = item,
				Margin = new Thickness(0.0, 6.0, 0.0, 0.0),
				HorizontalAlignment = HorizontalAlignment.Center
			});
			button.Content = stackPanel2;
			button.Click += (object _, RoutedEventArgs _) =>
			{
				selected = dark + "|" + light;
				dialog.Close();
			};
			uniformGrid.Children.Add(button);
		}
		stackPanel.Children.Add(uniformGrid);
		dialog.Content = stackPanel;
		dialog.ShowDialog();
		if (selected == null)
		{
			return;
		}
		string[] array3 = selected.Split('|');
		Sheet sheet = book.Sheets[activeSheet];
		foreach (var item4 in list)
		{
			int item2 = item4.Item1;
			int item3 = item4.Item2;
			string key = CellAddress(item2, item3);
			if (!sheet.CellStyles.TryGetValue(key, out CellStyleInfo value))
			{
				value = (sheet.CellStyles[key] = new CellStyleInfo());
			}
			CellStyleInfo cellStyleInfo2 = value;
			string? fillColor;
			if (item2 == tuple.Item1)
			{
				fillColor = array3[0];
			}
			else
			{
				fillColor = (((item2 - tuple.Item1) % 2 == 1) ? array3[1] : "#FFFFFF");
			}
			cellStyleInfo2.FillColor = fillColor;
			value.Bold = item2 == tuple.Item1;
			value.FontColor = ((item2 == tuple.Item1) ? "#FFFFFF" : "#000000");
		}
		RenderSheet();
		Persist();
		SelectCell(tuple.Item1, tuple.Item2);
		StatusText.Text = $"Estilo de tabla aplicado solo a {list.Count} celdas del rango {CellAddress(tuple.Item1, tuple.Item2)}:{CellAddress(tuple.Item3, tuple.Item4)}";
	}

	private void Chart_Click(object s, RoutedEventArgs e)
	{
		if (Grid.SelectedCells.Count == 0)
		{
			MessageBox.Show("Seleccioná una columna de valores para crear un gráfico.", "Gráfico", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			return;
		}
		int displayIndex = Grid.SelectedCells[0].Column.DisplayIndex;
		List<(string Label, double Value)> data = new List<(string, double)>();
		Sheet sheet = book.Sheets[activeSheet];
		int sheetIndex = book.Sheets.IndexOf(sheet);
		for (int i = 0; i < sheet.Rows.Count; i++)
		{
			if (double.TryParse(CalculateCellValue(sheetIndex, i, displayIndex, new HashSet<string>()), NumberStyles.Any, CultureInfo.InvariantCulture, out var result))
			{
				data.Add((Convert.ToString(sheet.Rows[i].ElementAtOrDefault(0)) ?? (i + 1).ToString(), result));
			}
		}
		if (data.Count == 0)
		{
			MessageBox.Show("No hay números en la columna seleccionada.", "Gráfico", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			return;
		}
		Window window = new Window
		{
			Title = "GEXE · Gráfico de columnas",
			Width = 960.0,
			Height = 540.0,
			MinWidth = 640.0,
			MinHeight = 400.0,
			WindowStartupLocation = WindowStartupLocation.CenterScreen,
			Background = Brushes.White
		};
		DockPanel dockPanel = new DockPanel
		{
			Margin = new Thickness(22.0)
		};
		TextBlock element = new TextBlock
		{
			Text = "Gráfico de " + ColName(displayIndex),
			FontSize = 20.0,
			FontWeight = FontWeights.SemiBold,
			Foreground = new SolidColorBrush(Color.FromRgb(37, 50, 71)),
			Margin = new Thickness(0.0, 0.0, 0.0, 14.0)
		};
		DockPanel.SetDock(element, Dock.Top);
		dockPanel.Children.Add(element);
		Canvas canvas = new Canvas
		{
			ClipToBounds = true,
			Background = Brushes.White
		};
		dockPanel.Children.Add(canvas);
		window.Content = dockPanel;
		canvas.SizeChanged += (object _, SizeChangedEventArgs _) =>
		{
			Draw();
		};
		window.Loaded += (object _, RoutedEventArgs _) =>
		{
			Draw();
		};
		window.ShowDialog();
		void Draw()
		{
			canvas.Children.Clear();
			double actualWidth = canvas.ActualWidth;
			double actualHeight = canvas.ActualHeight;
			if (!(actualWidth < 40.0) && !(actualHeight < 40.0))
			{
				double num = Math.Max(1.0, data.Max(((string Label, double Value) p) => Math.Abs(p.Value)));
				double num2 = 58.0;
				double num3 = 18.0;
				double num4 = 18.0;
				double num5 = 58.0;
				double num6 = actualWidth - num2 - num3;
				double num7 = actualHeight - num4 - num5;
				Line element2 = new Line
				{
					X1 = num2,
					Y1 = num4 + num7,
					X2 = num2 + num6,
					Y2 = num4 + num7,
					Stroke = new SolidColorBrush(Color.FromRgb(190, 198, 205)),
					StrokeThickness = 1.0
				};
				canvas.Children.Add(element2);
				double num8 = num6 / (double)data.Count;
				double num9 = Math.Min(52.0, num8 * 0.66);
				for (int num10 = 0; num10 < data.Count; num10++)
				{
					double num11 = Math.Max(1.0, Math.Abs(data[num10].Value) / num * (num7 - 18.0));
					double length = num2 + (double)num10 * num8 + (num8 - num9) / 2.0;
					double num12 = num4 + num7 - num11;
					Rectangle element3 = new Rectangle
					{
						Width = num9,
						Height = num11,
						RadiusX = 3.0,
						RadiusY = 3.0,
						Fill = new SolidColorBrush(Color.FromRgb(33, 115, 70)),
						ToolTip = $"{data[num10].Label}: {data[num10].Value}"
					};
					Canvas.SetLeft(element3, length);
					Canvas.SetTop(element3, num12);
					canvas.Children.Add(element3);
					TextBlock textBlock = new TextBlock
					{
						Text = data[num10].Value.ToString("0.##", CultureInfo.InvariantCulture),
						FontSize = 10.0,
						Foreground = new SolidColorBrush(Color.FromRgb(70, 82, 96)),
						Width = Math.Max(45.0, num8),
						TextAlignment = TextAlignment.Center
					};
					Canvas.SetLeft(textBlock, num2 + (double)num10 * num8 + (num8 - textBlock.Width) / 2.0);
					Canvas.SetTop(textBlock, Math.Max(0.0, num12 - 18.0));
					canvas.Children.Add(textBlock);
					TextBlock textBlock2 = new TextBlock
					{
						Text = ((data[num10].Label.Length > 10) ? data[num10].Label.Substring(0, 10) : data[num10].Label),
						FontSize = 10.0,
						Foreground = new SolidColorBrush(Color.FromRgb(70, 82, 96)),
						Width = Math.Max(48.0, num8),
						TextAlignment = TextAlignment.Center,
						TextTrimming = TextTrimming.CharacterEllipsis
					};
					Canvas.SetLeft(textBlock2, num2 + (double)num10 * num8 + (num8 - textBlock2.Width) / 2.0);
					Canvas.SetTop(textBlock2, num4 + num7 + 8.0);
					canvas.Children.Add(textBlock2);
				}
			}
		}
	}

	private async void Drive_Click(object s, RoutedEventArgs e)
	{
		_ = 5;
		try
		{
			if (!(await EnsureGoogleConnectedAsync()) || cloudDrive == null)
			{
				return;
			}
			switch (ShowDriveActions())
			{
			case "enable":
			{
				if (!autoSave)
				{
					throw new InvalidOperationException("Activá Autoguardado para sincronizar automáticamente.");
				}
				CommitTable();
				Persist();
				CloudBinding cloudBinding = GetCloudBinding();
				cloudBinding.Enabled = true;
				cloudBinding.Conflict = false;
				SaveCloudBindings();
				await SyncCloudAsync(default, force: true);
				break;
			}
			case "download":
				await PickCloudBookAsync();
				break;
			case "now":
				await SyncCloudAsync(default, force: true);
				break;
			case "legacy":
				await ImportLegacyDriveAsync();
				break;
			case "pause":
				GetCloudBinding().Enabled = false;
				SaveCloudBindings();
				SaveStatus.Text = "Sincronización pausada · libro local conservado";
				break;
			case "copy":
				CommitTable();
				book.SyncId = Guid.NewGuid().ToString("N");
				book.Title += " (copia)";
				currentWorkbookPath = null;
				WorkbookTitle.Text = book.Title;
				Persist();
				GetCloudBinding().Enabled = true;
				SaveCloudBindings();
				await SyncCloudAsync(default, force: true);
				break;
			case "disconnect":
				if (MessageBox.Show("¿Desconectar Google en esta computadora? Tus libros locales se conservan.", "GEXE", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
				{
					break;
				}
				cloudTimer?.Stop();
				foreach (CloudBinding value in cloudBindings.Values)
				{
					value.Enabled = false;
				}
				SaveCloudBindings();
				cloudDrive.Disconnect();
				cloudDrive = null;
				UpdateAccountBadge();
				SaveStatus.Text = "Google desconectado";
				break;
			}
		}
		catch (Exception ex)
		{
			SaveStatus.Text = "Google: conexión pendiente";
			MessageBox.Show(ex.Message, "Conectar con Google", MessageBoxButton.OK, MessageBoxImage.Asterisk);
		}
	}

	private string? PromptClientId()
	{
		Window dialog = new Window
		{
			Title = "Conectar Google Drive",
			Width = 540.0,
			Height = 390.0,
			WindowStartupLocation = WindowStartupLocation.CenterScreen,
			ResizeMode = ResizeMode.NoResize,
			Background = Brushes.White
		};
		StackPanel stackPanel = new StackPanel
		{
			Margin = new Thickness(20.0)
		};
		stackPanel.Children.Add(new TextBlock
		{
			Text = "Prepará el acceso de GEXE a tu Google Drive",
			FontSize = 17.0,
			FontWeight = FontWeights.SemiBold,
			Foreground = new SolidColorBrush(Color.FromRgb(33, 115, 70)),
			Margin = new Thickness(0.0, 0.0, 0.0, 10.0)
		});
		stackPanel.Children.Add(new TextBlock
		{
			Text = "En Google Cloud: crea un proyecto, habilita Google Drive API, configura la pantalla OAuth y crea un cliente OAuth de tipo Aplicación de escritorio. Después pega aquí el ID de cliente. Google te pedirá iniciar sesión y autorizar el acceso.",
			TextWrapping = TextWrapping.Wrap,
			LineHeight = 21.0,
			Margin = new Thickness(0.0, 0.0, 0.0, 12.0)
		});
		stackPanel.Children.Add(new TextBlock
		{
			Text = "GEXE solicita permiso solo para los libros que crea. No pegues aquí tu contraseña de Google ni una clave secreta.",
			TextWrapping = TextWrapping.Wrap,
			Foreground = new SolidColorBrush(Color.FromRgb(92, 105, 98)),
			Margin = new Thickness(0.0, 0.0, 0.0, 12.0)
		});
		TextBox field = new TextBox
		{
			Height = 31.0,
			VerticalContentAlignment = VerticalAlignment.Center,
			Padding = new Thickness(6.0),
			ToolTip = "El ID termina en .apps.googleusercontent.com"
		};
		stackPanel.Children.Add(field);
		TextBlock textBlock = new TextBlock
		{
			Text = "Abrir credenciales de Google Cloud",
			Foreground = new SolidColorBrush(Color.FromRgb(33, 115, 70)),
			TextDecorations = TextDecorations.Underline,
			Cursor = Cursors.Hand,
			Margin = new Thickness(0.0, 10.0, 0.0, 14.0)
		};
		textBlock.MouseLeftButtonUp += (object _, MouseButtonEventArgs _) =>
		{
			Process.Start(new ProcessStartInfo("https://console.cloud.google.com/apis/credentials")
			{
				UseShellExecute = true
			});
		};
		stackPanel.Children.Add(textBlock);
		StackPanel stackPanel2 = new StackPanel
		{
			Orientation = Orientation.Horizontal,
			HorizontalAlignment = HorizontalAlignment.Right
		};
		Button button = new Button
		{
			Content = "Cancelar",
			Padding = new Thickness(12.0, 5.0, 12.0, 5.0),
			Margin = new Thickness(0.0, 0.0, 8.0, 0.0)
		};
		Button button2 = new Button
		{
			Content = "Continuar con Google",
			Padding = new Thickness(12.0, 5.0, 12.0, 5.0),
			IsDefault = true,
			Background = new SolidColorBrush(Color.FromRgb(33, 115, 70)),
			Foreground = Brushes.White
		};
		stackPanel2.Children.Add(button);
		stackPanel2.Children.Add(button2);
		stackPanel.Children.Add(stackPanel2);
		dialog.Content = stackPanel;
		string result = null;
		button.Click += (object _, RoutedEventArgs _) =>
		{
			dialog.Close();
		};
		button2.Click += (object _, RoutedEventArgs _) =>
		{
			result = field.Text.Trim();
			dialog.Close();
		};
		dialog.ShowDialog();
		return result;
	}

	private string? ShowDriveActions()
	{
		Window dialog = new Window
		{
			Title = "Cuenta Google · Sincronización GEXE",
			Width = 480.0,
			Height = 620.0,
			Owner = this,
			WindowStartupLocation = WindowStartupLocation.CenterOwner,
			ResizeMode = ResizeMode.NoResize,
			Background = Brushes.White
		};
		StackPanel panel = new StackPanel
		{
			Margin = new Thickness(20.0)
		};
		panel.Children.Add(new TextBlock
		{
			Text = "Tus libros en todas tus computadoras",
			FontSize = 18.0,
			FontWeight = FontWeights.SemiBold,
			TextWrapping = TextWrapping.Wrap,
			Margin = new Thickness(0.0, 0.0, 0.0, 10.0)
		});
		panel.Children.Add(new TextBlock
		{
			Text = "Usá la misma cuenta Google en cada equipo. Los libros se guardan en Drive y se revisan cada 10 segundos mientras GEXE está abierto. La primera vez, abrí el libro desde Google en el otro equipo.",
			TextWrapping = TextWrapping.Wrap,
			Margin = new Thickness(0.0, 0.0, 0.0, 12.0)
		});
		panel.Children.Add(BuildFreeSyncNotice());
		string result = null;
		Add("Activar sincronización automática de este libro", "enable");
		Add("Abrir uno de mis libros de Google", "download");
		Add("Sincronizar ahora", "now");
		Add("Pausar sincronización de este libro", "pause");
		Add("Conservar mi copia como otro libro en Google", "copy");
		Add("Importar libro de la sincronización anterior", "legacy");
		Add("Desconectar esta computadora", "disconnect");
		dialog.Content = panel;
		dialog.ShowDialog();
		return result;
		void Add(string label, string value)
		{
			Button button = new Button
			{
				Content = label,
				HorizontalContentAlignment = HorizontalAlignment.Left,
				Padding = new Thickness(10.0, 7.0, 10.0, 7.0),
				Margin = new Thickness(0.0, 0.0, 0.0, 7.0)
			};
			button.Click += (object _, RoutedEventArgs _) =>
			{
				result = value;
				dialog.Close();
			};
			panel.Children.Add(button);
		}
	}

	private void Ribbon_Click(object s, RoutedEventArgs e)
	{
		if (s is Button button)
		{
			string text = Convert.ToString(button.Tag) ?? "home";
			if (text == "file")
			{
				ShowFileBackstage();
			}
			else
			{
				SetRibbon(text);
			}
		}
	}

	private void SetRibbon(string section)
	{
		StackPanel panel = new StackPanel
		{
			Orientation = Orientation.Horizontal,
			VerticalAlignment = VerticalAlignment.Center,
			Height = 102.0
		};
		Panel destination = panel;
		ribbonFontControl = null;
		ribbonFontSizeControl = null;
		ribbonNumberControl = null;
		ribbonFontColorBar = null;
		ribbonFillColorBar = null;
		ribbonFontColorGlyph = null;
		Dictionary<string, string> ribbonIcons = new Dictionary<string, string>
		{
			{ "Pegar", "\ue77f" },
			{ "Cortar", "\ue8c6" },
			{ "Copiar", "\ue8c8" },
			{ "N", "\ue8dd" },
			{ "K", "\ue8db" },
			{ "S", "\ue8dc" },
			{ "Izq", "\ue8e4" },
			{ "Centro", "\ue8e3" },
			{ "Der", "\ue8e2" },
			{ "%", "%" },
			{ "∑", "∑" },
			{ "Filtro", "\ue71c" },
			{ "Buscar", "\ue721" },
			{ "Gráfico", "\ue9d2" },
			{ "Tabla", "\ue80a" },
			{ "Formato como tabla", "\ue80a" },
			{ "Casilla", "\ue739" },
			{ "Nueva hoja", "\ue710" },
			{ "Borrar", "\ue74d" },
			{ "Borrar formato", "\ue75c" },
			{ "A ▾", "A" },
			{ "▰ ▾", "\ue790" }
		};
		switch (section)
		{
		case "file":
			Add("Inicio", ShowStartScreen);
			Add("Nuevo · libro en blanco", () =>
			{
				New_Click(this, new RoutedEventArgs());
			});
			Add("Abrir archivo Excel o GEXE", () =>
			{
				Open_Click(this, new RoutedEventArgs());
			});
			Add("Guardar", () =>
			{
				SaveCurrentWorkbook();
			});
			Add("Guardar como XLSX…", () =>
			{
				SaveAsWorkbook();
			});
			Add("Guardar copia GEXE…", () =>
			{
				SaveAsGexeBook();
			});
			Add("Compartir / Google Drive", () =>
			{
				Drive_Click(this, new RoutedEventArgs());
			});
			break;
		case "insert":
			Group("Tablas", () =>
			{
				Add("Tabla", () =>
				{
					Table_Click(this, new RoutedEventArgs());
				});
			});
			Group("Ilustraciones", () =>
			{
				Add("Gráfico", () =>
				{
					Chart_Click(this, new RoutedEventArgs());
				});
			});
			Group("Controles", () =>
			{
				Add("Casilla", InsertCheckbox);
				Add("Nueva hoja", () =>
				{
					AddSheet_Click(this, new RoutedEventArgs());
				});
			});
			Group("Funciones", () =>
			{
				Add("Crear fórmula", () =>
				{
					ShowFormulaBuilder(null);
				});
			});
			break;
		case "draw":
			Group("Herramientas de celda", () =>
			{
				PaletteButton("Color de lápiz", fill: false);
				Add("Subrayar celda", Underline_Click);
			});
			Group("Borrar", () =>
			{
				Add("Borrar formato", ClearCellFormat);
			});
			break;
		case "layout":
			Group("Configurar página", () =>
			{
				Add("Color de página", ChoosePageColor);
				Add("Ajustar columnas", AutoFitColumns);
			});
			Group("Escala", () =>
			{
				Add("Reducir zoom", () =>
				{
					ChangeZoom(-0.1);
				});
				Add("Aumentar zoom", () =>
				{
					ChangeZoom(0.1);
				});
				Add("Zoom 100%", ResetZoom);
			});
			Group("Opciones de hoja", () =>
			{
				Add("Líneas de cuadrícula", ToggleGridlines);
				Add("Maximizar / restaurar", ToggleWindowSize);
			});
			break;
		case "formulas":
			Group("Biblioteca de funciones", () =>
			{
				Add("Autosuma", AutoSum);
				Add("Crear fórmula", () =>
				{
					ShowFormulaBuilder(null);
				});
			});
			Group("Operaciones básicas", () =>
			{
				Add("+ Sumar", () =>
				{
					ShowFormulaBuilder("+");
				});
				Add("− Restar", () =>
				{
					ShowFormulaBuilder("-");
				});
				Add("× Multiplicar", () =>
				{
					ShowFormulaBuilder("*");
				});
			});
			Group("Más operaciones", () =>
			{
				Add("÷ Dividir", () =>
				{
					ShowFormulaBuilder("/");
				});
				Add("Potencia", () =>
				{
					ShowFormulaBuilder("^");
				});
				Add("Porcentaje", () =>
				{
					ShowFormulaBuilder("%");
				});
			});
			break;
		case "data":
			Group("Ordenar", () =>
			{
				Add("Ordenar A → Z", () =>
				{
					SortSelectedColumn(ascending: true);
				});
				Add("Ordenar Z → A", () =>
				{
					SortSelectedColumn(ascending: false);
				});
			});
			Group("Filtrar", () =>
			{
				Add("Filtrar valor", () =>
				{
					Filter_Click(this, new RoutedEventArgs());
				});
				Add("Quitar filtros", ClearFilters);
			});
			break;
		case "review":
			Group("Revisión", () =>
			{
				Add("Buscar / reemplazar", FindReplace);
				Add("Revisar fórmulas", CheckFormulaErrors);
			});
			Group("Libro", () =>
			{
				Add("Guardar copia XLSX", () =>
				{
					Save_Click(this, new RoutedEventArgs());
				});
			});
			break;
		case "view":
			Group("Zoom", () =>
			{
				Add("Alejar", () =>
				{
					ChangeZoom(-0.1);
				});
				Add("Acercar", () =>
				{
					ChangeZoom(0.1);
				});
				Add("Restablecer zoom", ResetZoom);
			});
			Group("Mostrar", () =>
			{
				Add("Mostrar / ocultar cuadrícula", ToggleGridlines);
			});
			Group("Ventana", () =>
			{
				Add("Maximizar / restaurar", ToggleWindowSize);
			});
			break;
		case "automate":
			Add("Autosuma", AutoSum);
			Add("Insertar fecha", () =>
			{
				WriteSelectedValue(DateTime.Today.ToString("yyyy-MM-dd"));
			});
			Add("Revisar fórmulas", CheckFormulaErrors);
			Add("Automatizar acciones", () =>
			{
				MessageBox.Show("Las macros y los scripts no están disponibles todavía. Podés usar fórmulas y Autosuma para automatizar cálculos.", "Automatizar", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			});
			break;
		case "help":
			Add("Actualizaciones", ShowAppUpdates);
			Add("Atajos de teclado", ShowKeyboardHelp);
			Add("Funciones disponibles", () =>
			{
				MessageBox.Show("Se admiten operaciones aritméticas, referencias y funciones comunes como SUMA, PROMEDIO, SI, CONTAR, MAX, MIN, REDONDEAR y FECHA.", "Ayuda", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			});
			Add("Acerca de GEXE", () =>
			{
				MessageBox.Show("GEXE · hoja de cálculo experimental para Windows.", "Acerca de", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			});
			break;
		case "table":
			Group("Estilos de tabla", () =>
			{
				Add("Aplicar estilo de tabla", () =>
				{
					Table_Click(this, new RoutedEventArgs());
				});
			});
			Group("Opciones de filtro", () =>
			{
				Add("Filtrar valor", () =>
				{
					Filter_Click(this, new RoutedEventArgs());
				});
				Add("Quitar filtros", ClearFilters);
			});
			break;
		default:
			Group("Portapapeles", () =>
			{
				Panel panel2 = destination;
				StackPanel stackPanel = (StackPanel)(destination = new StackPanel
				{
					Orientation = Orientation.Horizontal
				});
				Add("Pegar", PasteCell);
				StackPanel element = (StackPanel)(destination = new StackPanel());
				Add("Cortar", CutCell);
				Add("Copiar", CopyCell);
				stackPanel.Children.Add(element);
				destination = panel2;
				panel2.Children.Add(stackPanel);
			});
			Group("Fuente", () =>
			{
				AddFontControls();
				Add("N", () =>
				{
					Bold_Click(this, new RoutedEventArgs());
				}, "Negrita");
				Add("K", () =>
				{
					SetSelectedStyle((CellStyleInfo st) =>
					{
						st.Italic = !st.Italic;
					});
				}, "Cursiva");
				Add("S", Underline_Click, "Subrayado");
				Add("A+", () =>
				{
					ChangeFontSize(1.0);
				}, "Aumentar tamaño de fuente");
				Add("A−", () =>
				{
					ChangeFontSize(-1.0);
				}, "Disminuir tamaño de fuente");
				PaletteButton("A ▾", fill: false);
				PaletteButton("▰ ▾", fill: true);
			});
			Group("Alineación", () =>
			{
				Add("Izq", () =>
				{
					SetSelectedStyle((CellStyleInfo st) =>
					{
						st.HorizontalAlignment = "Left";
					});
				});
				Add("Centro", () =>
				{
					SetSelectedStyle((CellStyleInfo st) =>
					{
						st.HorizontalAlignment = "Center";
					});
				});
				Add("Der", () =>
				{
					SetSelectedStyle((CellStyleInfo st) =>
					{
						st.HorizontalAlignment = "Right";
					});
				});
			});
			Group("Número", () =>
			{
				ComboBox formats = new ComboBox
				{
					Width = 112.0,
					Height = 27.0,
					Margin = new Thickness(2.0),
					ItemsSource = new string[5] { "General", "Número", "Miles", "Moneda", "Porcentaje" },
					SelectedItem = "Número",
					ToolTip = "Formato numérico"
				};
				ribbonNumberControl = formats;
				formats.SelectionChanged += (object _, SelectionChangedEventArgs _) =>
				{
					if (!refreshingRibbon)
					{
						string numberFormatSelection = Convert.ToString(formats.SelectedItem) switch
						{
							"Número" => "Number", 
							"Miles" => "Thousands", 
							"Moneda" => "Currency", 
							"Porcentaje" => "Percent", 
							_ => "General", 
						};
						SetNumberFormatSelection(numberFormatSelection);
					}
				};
				destination.Children.Add(formats);
				Add("$", () =>
				{
					SetNumberFormatSelection("Currency");
				}, "Formato de moneda");
				Add("%", () =>
				{
					SetNumberFormatSelection("Percent");
				});
				Add("Miles", () =>
				{
					SetNumberFormatSelection("Thousands");
				}, "Separador de miles");
			});
			Group("Estilos", () =>
			{
				Add("Formato como tabla", () =>
				{
					Table_Click(this, new RoutedEventArgs());
				});
				Add("Borrar formato", ClearCellFormat);
			});
			Group("Celdas", () =>
			{
				Add("Casilla", InsertCheckbox);
				Add("Nueva hoja", () =>
				{
					AddSheet_Click(this, new RoutedEventArgs());
				});
				Add("Borrar", ClearCell);
			});
			Group("Edición", () =>
			{
				Add("∑", AutoSum, "Autosuma");
				Add("Ordenar A–Z", () =>
				{
					SortSelectedColumn(ascending: true);
				});
				Add("Filtro", () =>
				{
					Filter_Click(this, new RoutedEventArgs());
				});
				Add("Buscar", FindReplace);
			});
			Group("Complementos", () =>
			{
				Add("Gráfico", () =>
				{
					Chart_Click(this, new RoutedEventArgs());
				});
				Add("Fórmula", () =>
				{
					ShowFormulaBuilder(null);
				});
			});
			break;
		}
		RibbonPanel.Child = new ScrollViewer
		{
			Content = panel,
			HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
			VerticalScrollBarVisibility = ScrollBarVisibility.Disabled,
			CanContentScroll = true,
			VerticalAlignment = VerticalAlignment.Center
		};
		foreach (Button item in RibbonTabs.Children.OfType<Button>())
		{
			bool flag = string.Equals(Convert.ToString(item.Tag), section, StringComparison.OrdinalIgnoreCase);
			item.Background = Brushes.Transparent;
			item.Foreground = (flag ? new SolidColorBrush(Color.FromRgb(33, 115, 70)) : new SolidColorBrush(Color.FromRgb(37, 37, 37)));
			item.BorderBrush = (flag ? new SolidColorBrush(Color.FromRgb(33, 115, 70)) : Brushes.Transparent);
			item.BorderThickness = new Thickness(0.0, 0.0, 0.0, flag ? 3 : 0);
		}
		TextBlock statusText = StatusText;
		statusText.Text = section switch
		{
			"file" => "Archivo · nuevo, abrir, guardar y compartir", 
			"insert" => "Insertar · casillas, tablas, gráficos y hojas", 
			"draw" => "Dibujar · color de lápiz y subrayado", 
			"layout" => "Disposición de página · color, columnas y vista", 
			"formulas" => "Fórmulas · operaciones y funciones", 
			"data" => "Datos · filtros y orden", 
			"review" => "Revisar · buscar y comprobar fórmulas", 
			"view" => "Vista · zoom y cuadrícula", 
			"automate" => "Automatizar · funciones básicas disponibles", 
			"help" => "Ayuda · funciones y atajos", 
			"table" => "Diseño de tabla · estilos y filtros", 
			_ => "Inicio · portapapeles, fuente, color y autosuma", 
		};
		void Add(string label, Action action, string? tip = null)
		{
			IReadOnlyDictionary<string, string> dictionary = ribbonIcons;
			string defaultValue;
			switch (label)
			{
			case "Crear fórmula":
			case "Fórmula":
			case "Autosuma":
				defaultValue = "ƒx";
				break;
			case "Ordenar Z → A":
			case "Ordenar A → Z":
			case "Ordenar A–Z":
				defaultValue = "\ue8cb";
				break;
			case "Filtrar valor":
			case "Quitar filtros":
				defaultValue = "\ue71c";
				break;
			case "Buscar / reemplazar":
				defaultValue = "\ue721";
				break;
			case "Guardar copia XLSX":
				defaultValue = "\ue74e";
				break;
			case "Alejar":
			case "Reducir zoom":
				defaultValue = "\ue71f";
				break;
			case "Aumentar zoom":
			case "Acercar":
				defaultValue = "\ue8a3";
				break;
			case "Atajos de teclado":
				defaultValue = "\ue765";
				break;
			case "Acerca de GEXE":
			case "Funciones disponibles":
				defaultValue = "\ue946";
				break;
			default:
				defaultValue = "\ue713";
				break;
			}
			string valueOrDefault = dictionary.GetValueOrDefault(label, defaultValue);
			bool flag2;
			switch (label)
			{
			case "Pegar":
			case "Tabla":
			case "Gráfico":
			case "Formato como tabla":
				flag2 = true;
				break;
			default:
				flag2 = false;
				break;
			}
			bool flag3 = flag2;
			if (label != null)
			{
				switch (label.Length)
				{
				case 1:
				{
					char c = label[0];
					if ((uint)c <= 75u)
					{
						if (c != '$' && c != '%' && c != 'K')
						{
							break;
						}
					}
					else if (c != 'N' && c != 'S' && c != '∑')
					{
						break;
					}
					goto IL_03f0;
				}
				case 3:
				{
					char c = label[0];
					if (c != 'D')
					{
						if (c != 'I' || !(label == "Izq"))
						{
							break;
						}
					}
					else if (!(label == "Der"))
					{
						break;
					}
					goto IL_03f0;
				}
				case 2:
				{
					char c = label[1];
					if (c != '+')
					{
						if (c != '−' || !(label == "A−"))
						{
							break;
						}
					}
					else if (!(label == "A+"))
					{
						break;
					}
					goto IL_03f0;
				}
				case 6:
					if (!(label == "Centro"))
					{
						break;
					}
					goto IL_03f0;
				case 5:
					{
						if (!(label == "Miles"))
						{
							break;
						}
						goto IL_03f0;
					}
					IL_03f0:
					flag2 = true;
					goto IL_03f8;
				}
			}
			flag2 = false;
			goto IL_03f8;
			IL_03f8:
			bool flag4 = flag2;
			object content;
			if (flag4)
			{
				TextBlock textBlock = new TextBlock();
				TextBlock textBlock2 = textBlock;
				switch (label)
				{
				case "Izq":
				case "Centro":
				case "Der":
					flag2 = true;
					break;
				default:
					flag2 = false;
					break;
				}
				textBlock2.Text = (flag2 ? valueOrDefault : label);
				TextBlock textBlock3 = textBlock;
				bool flag5;
				switch (label)
				{
				case "Izq":
				case "Centro":
				case "Der":
					flag5 = true;
					break;
				default:
					flag5 = false;
					break;
				}
				textBlock3.FontFamily = new FontFamily(flag5 ? "Segoe MDL2 Assets" : "Segoe UI");
				textBlock.FontSize = 13.0;
				textBlock.FontWeight = ((label == "N") ? FontWeights.Bold : FontWeights.Normal);
				textBlock.FontStyle = ((label == "K") ? FontStyles.Italic : FontStyles.Normal);
				textBlock.TextDecorations = ((label == "S") ? TextDecorations.Underline : null);
				textBlock.HorizontalAlignment = HorizontalAlignment.Center;
				content = textBlock;
			}
			else
			{
				StackPanel stackPanel = new StackPanel
				{
					Orientation = (flag3 ? Orientation.Vertical : Orientation.Horizontal),
					VerticalAlignment = VerticalAlignment.Center
				};
				UIElementCollection children = stackPanel.Children;
				TextBlock textBlock3 = new TextBlock
				{
					Text = valueOrDefault
				};
				TextBlock textBlock = textBlock3;
				bool flag5;
				switch (label)
				{
				case "∑":
				case "Autosuma":
				case "Crear fórmula":
				case "Fórmula":
					flag5 = true;
					break;
				default:
					flag5 = false;
					break;
				}
				textBlock.FontFamily = new FontFamily(flag5 ? "Segoe UI" : "Segoe MDL2 Assets");
				textBlock3.FontSize = (flag3 ? 27 : 14);
				textBlock3.Foreground = new SolidColorBrush(Color.FromRgb(33, 115, 70));
				textBlock3.VerticalAlignment = VerticalAlignment.Center;
				textBlock3.HorizontalAlignment = HorizontalAlignment.Center;
				textBlock3.Margin = new Thickness((!flag3) ? 2 : 0, 0.0, (!flag3) ? 6 : 0, flag3 ? 5 : 0);
				children.Add(textBlock3);
				stackPanel.Children.Add(new TextBlock
				{
					Text = ((label == "Formato como tabla") ? "Dar formato\ncomo tabla" : label),
					FontSize = 11.0,
					TextAlignment = TextAlignment.Center,
					VerticalAlignment = VerticalAlignment.Center,
					HorizontalAlignment = HorizontalAlignment.Center
				});
				content = stackPanel;
			}
			Button button = new Button
			{
				Content = content,
				Height = (flag3 ? 72 : 24),
				MinWidth = (flag4 ? 28 : 0),
				Padding = new Thickness(4.0, 2.0, 4.0, 2.0),
				Margin = new Thickness(1.0),
				Background = Brushes.White,
				BorderBrush = Brushes.Transparent,
				ToolTip = (tip ?? label)
			};
			AutomationProperties.SetName(button, tip ?? label);
			button.Click += (object _, RoutedEventArgs _) =>
			{
				action();
			};
			destination.Children.Add(button);
		}
		void AddFontControls()
		{
			CellStyleInfo cellStyleInfo = SelectedStyle();
			ComboBox fonts = new ComboBox
			{
				Width = 126.0,
				Height = 25.0,
				Margin = new Thickness(2.0),
				ToolTip = "Tipo de letra",
				ItemsSource = new string[13]
				{
					cellStyleInfo.FontFamily, "Aptos Narrow", "Aptos", "Arial", "Calibri", "Cambria", "Comic Sans MS", "Consolas", "Courier New", "Georgia",
					"Segoe UI", "Times New Roman", "Verdana"
				}.Distinct(StringComparer.OrdinalIgnoreCase).ToList(),
				SelectedItem = cellStyleInfo.FontFamily
			};
			ribbonFontControl = fonts;
			fonts.SelectionChanged += (object _, SelectionChangedEventArgs _) =>
			{
				if (!refreshingRibbon)
				{
					object selectedItem = fonts.SelectedItem;
					string name = selectedItem as string;
					if (name != null)
					{
						SetSelectedStyle((CellStyleInfo st) =>
						{
							st.FontFamily = name;
						});
					}
				}
			};
			destination.Children.Add(fonts);
			ComboBox sizes = new ComboBox
			{
				Width = 48.0,
				Height = 25.0,
				Margin = new Thickness(2.0),
				ToolTip = "Tamaño de letra",
				IsEditable = true,
				ItemsSource = new string[15]
				{
					"8", "9", "10", "11", "12", "14", "16", "18", "20", "24",
					"28", "32", "36", "48", "72"
				},
				Text = cellStyleInfo.FontSize.ToString(CultureInfo.InvariantCulture)
			};
			ribbonFontSizeControl = sizes;
			sizes.SelectionChanged += (object _, SelectionChangedEventArgs _) =>
			{
				if (!refreshingRibbon && double.TryParse(Convert.ToString(sizes.SelectedItem), out var size))
				{
					SetSelectedStyle((CellStyleInfo st) =>
					{
						st.FontSize = Math.Clamp(size, 6.0, 96.0);
					});
				}
			};
			sizes.LostFocus += (object _, RoutedEventArgs _) =>
			{
				if (!refreshingRibbon && double.TryParse(sizes.Text, out var size))
				{
					SetSelectedStyle((CellStyleInfo st) =>
					{
						st.FontSize = Math.Clamp(size, 6.0, 96.0);
					});
				}
			};
			destination.Children.Add(sizes);
		}
		void ChangeFontSize(double delta)
		{
			SetSelectedStyle((CellStyleInfo st) =>
			{
				st.FontSize = Math.Clamp(st.FontSize + delta, 6.0, 96.0);
			});
		}
		void Group(string caption, Action build)
		{
			double width = caption switch
			{
				"Portapapeles" => 144, 
				"Fuente" => 220, 
				"Alineación" => 104, 
				"Número" => 136, 
				"Estilos" => 210, 
				"Celdas" => 112, 
				"Edición" => 142, 
				_ => 190, 
			};
			WrapPanel wrapPanel = new WrapPanel
			{
				Width = width,
				Height = 78.0,
				VerticalAlignment = VerticalAlignment.Top
			};
			Panel panel2 = destination;
			destination = wrapPanel;
			build();
			destination = panel2;
			Grid grid = new Grid
			{
				Width = width,
				Height = 100.0
			};
			grid.RowDefinitions.Add(new RowDefinition
			{
				Height = new GridLength(78.0)
			});
			grid.RowDefinitions.Add(new RowDefinition
			{
				Height = new GridLength(22.0)
			});
			grid.Children.Add(wrapPanel);
			TextBlock element = new TextBlock
			{
				Text = caption,
				FontSize = 11.0,
				Foreground = new SolidColorBrush(Color.FromRgb(95, 95, 95)),
				HorizontalAlignment = HorizontalAlignment.Center,
				VerticalAlignment = VerticalAlignment.Center
			};
			System.Windows.Controls.Grid.SetRow(element, 1);
			grid.Children.Add(element);
			panel.Children.Add(new Border
			{
				Child = grid,
				BorderBrush = new SolidColorBrush(Color.FromRgb(220, 220, 220)),
				BorderThickness = new Thickness(0.0, 0.0, 1.0, 0.0),
				Padding = new Thickness(5.0, 0.0, 5.0, 0.0)
			});
		}
		void PaletteButton(string label, bool fill)
		{
			StackPanel stackPanel = new StackPanel
			{
				HorizontalAlignment = HorizontalAlignment.Center
			};
			CellStyleInfo cellStyleInfo = SelectedStyle();
			TextBlock element = new TextBlock
			{
				Text = ribbonIcons.GetValueOrDefault(label, fill ? "\ue790" : "A"),
				FontFamily = new FontFamily(fill ? "Segoe MDL2 Assets" : "Segoe UI"),
				FontSize = 17.0,
				HorizontalAlignment = HorizontalAlignment.Center,
				Foreground = (fill ? new SolidColorBrush(Color.FromRgb(65, 65, 65)) : (TryBrush(cellStyleInfo.FontColor) ?? new SolidColorBrush(Color.FromRgb(65, 65, 65))))
			};
			stackPanel.Children.Add(element);
			Border element2 = new Border
			{
				Width = 27.0,
				Height = 3.0,
				Background = TryBrush(fill ? (cellStyleInfo.FillColor ?? "#FFC000") : (cellStyleInfo.FontColor ?? "#C00000")),
				Margin = new Thickness(0.0, 0.0, 0.0, 2.0)
			};
			stackPanel.Children.Add(element2);
			stackPanel.Children.Add(new TextBlock
			{
				Text = (fill ? "Relleno" : "Fuente"),
				FontSize = 10.0,
				HorizontalAlignment = HorizontalAlignment.Center
			});
			if (fill)
			{
				ribbonFillColorBar = element2;
			}
			else
			{
				ribbonFontColorBar = element2;
				ribbonFontColorGlyph = element;
			}
			Button button = new Button
			{
				Content = stackPanel,
				Width = 38.0,
				Height = 41.0,
				Padding = new Thickness(3.0),
				Margin = new Thickness(1.0),
				Background = Brushes.White,
				BorderBrush = Brushes.Transparent,
				Foreground = new SolidColorBrush(Color.FromRgb(45, 45, 45)),
				ToolTip = (fill ? "Color de relleno" : "Color de fuente")
			};
			button.Click += (object _, RoutedEventArgs _) =>
			{
				ShowColorPalette(label, fill);
			};
			destination.Children.Add(button);
		}
	}

	private void OpenPlans_Click(object s, RoutedEventArgs e)
	{
		ShowPlansWindow();
	}

	private void AddFormulaBuilder(string? op = null)
	{
		ShowFormulaBuilder(op);
	}

	private void ChangeZoom(double delta)
	{
		zoom = Math.Clamp(zoom + delta, 0.6, 1.6);
		Grid.FontSize = 11.0 * zoom;
		Grid.RowHeight = 22.0 * zoom;
		foreach (DataGridColumn column in Grid.Columns)
		{
			column.Width = 115.0 * zoom;
		}
		ZoomStatus.Content = $"{Math.Round(zoom * 100.0)} %";
		StatusText.Text = $"Zoom {Math.Round(zoom * 100.0)}%";
	}

	private void ResetZoom()
	{
		zoom = 1.0;
		Grid.FontSize = 11.0;
		Grid.RowHeight = 22.0;
		foreach (DataGridColumn column in Grid.Columns)
		{
			column.Width = 115.0;
		}
		ZoomStatus.Content = "100 %";
		StatusText.Text = "Zoom 100%";
	}

	private void ToggleGridlines()
	{
		gridlinesVisible = !gridlinesVisible;
		Grid.GridLinesVisibility = DataGridGridLinesVisibility.None;
		for (int i = 0; i < Grid.Items.Count; i++)
		{
			if (Grid.ItemContainerGenerator.ContainerFromIndex(i) is DataGridRow { Item: DataRowView item } dataGridRow)
			{
				ApplyRowStyles(dataGridRow, table.Rows.IndexOf(item.Row));
			}
		}
		StatusText.Text = (gridlinesVisible ? "Cuadrícula visible" : "Cuadrícula oculta");
	}

	private void ToggleWindowSize()
	{
		WindowState = ((WindowState != WindowState.Maximized) ? WindowState.Maximized : WindowState.Normal);
	}

	private void AutoFitColumns()
	{
		foreach (DataGridTextColumn column in Grid.Columns)
		{
			int displayIndex = column.DisplayIndex;
			int num = ColName(displayIndex).Length;
			for (int i = 0; i < table.Rows.Count; i++)
			{
				num = Math.Max(num, (Convert.ToString(table.Rows[i][displayIndex]) ?? "").Length);
			}
			column.Width = Math.Clamp(34.0 + (double)(num * 7) * zoom, 72.0, 300.0);
		}
		StatusText.Text = "Ancho de columnas ajustado al contenido";
	}

	private void ClearFilters()
	{
		table.DefaultView.RowFilter = "";
		StatusText.Text = "Filtros quitados";
	}

	private void SortSelectedColumn(bool ascending)
	{
		if (Grid.SelectedCells.Count != 0)
		{
			int displayIndex = Grid.SelectedCells[0].Column.DisplayIndex;
			table.DefaultView.Sort = "[" + ColName(displayIndex) + "] " + (ascending ? "ASC" : "DESC");
			StatusText.Text = "Ordenado por " + ColName(displayIndex) + " " + (ascending ? "A → Z" : "Z → A");
		}
	}

	private (int top, int left, int bottom, int right)? SelectedBounds()
	{
		List<(int, int)> list = SelectedCoordinates();
		if (list.Count == 0)
		{
			return null;
		}
		return (list.Min(((int row, int col) x) => x.row), list.Min(((int row, int col) x) => x.col), list.Max(((int row, int col) x) => x.row), list.Max(((int row, int col) x) => x.col));
	}

	private Rect? CopyOutlineRectangle()
	{
		if (copiedCells == null || copiedSheet == null || !string.Equals(book.Sheets[activeSheet].Name, copiedSheet, StringComparison.OrdinalIgnoreCase))
		{
			return null;
		}
		double num = double.PositiveInfinity;
		double num2 = double.PositiveInfinity;
		double num3 = double.NegativeInfinity;
		double num4 = double.NegativeInfinity;
		int num5 = copiedTop + copiedCells.Count - 1;
		int num6 = copiedLeft + copiedCells.Max((List<string> r) => r.Count) - 1;
		for (int num7 = 0; num7 < Grid.Items.Count; num7++)
		{
			if (!(Grid.Items[num7] is DataRowView dataRowView))
			{
				continue;
			}
			int num8 = table.Rows.IndexOf(dataRowView.Row);
			if (num8 < copiedTop || num8 > num5 || !(Grid.ItemContainerGenerator.ContainerFromIndex(num7) is DataGridRow parent))
			{
				continue;
			}
			DataGridCellsPresenter dataGridCellsPresenter = FindVisualChild<DataGridCellsPresenter>(parent);
			if (dataGridCellsPresenter == null)
			{
				continue;
			}
			for (int num9 = copiedLeft; num9 <= num6; num9++)
			{
				if (dataGridCellsPresenter.ItemContainerGenerator.ContainerFromIndex(num9) is DataGridCell dataGridCell)
				{
					try
					{
						Rect rect = dataGridCell.TransformToAncestor(Grid).TransformBounds(new Rect(dataGridCell.RenderSize));
						num = Math.Min(num, rect.Left);
						num2 = Math.Min(num2, rect.Top);
						num3 = Math.Max(num3, rect.Right);
						num4 = Math.Max(num4, rect.Bottom);
					}
					catch (InvalidOperationException)
					{
					}
				}
			}
		}
		if (double.IsInfinity(num) || double.IsInfinity(num2))
		{
			return null;
		}
		num = Math.Clamp(num, 0.0, Grid.ActualWidth);
		num3 = Math.Clamp(num3, 0.0, Grid.ActualWidth);
		num2 = Math.Clamp(num2, 0.0, Grid.ActualHeight);
		num4 = Math.Clamp(num4, 0.0, Grid.ActualHeight);
		if (!(num3 > num) || !(num4 > num2))
		{
			return null;
		}
		return new Rect(num, num2, num3 - num, num4 - num2);
	}

	private Rect? FormulaReferenceRectangle()
	{
		(int, int, int, int)? tuple = formulaReferenceRange;
		if (tuple.HasValue)
		{
			(int, int, int, int) valueOrDefault = tuple.GetValueOrDefault();
			double num = double.PositiveInfinity;
			double num2 = double.PositiveInfinity;
			double num3 = double.NegativeInfinity;
			double num4 = double.NegativeInfinity;
			for (int i = 0; i < Grid.Items.Count; i++)
			{
				if (!(Grid.Items[i] is DataRowView dataRowView))
				{
					continue;
				}
				int num5 = table.Rows.IndexOf(dataRowView.Row);
				if (num5 < valueOrDefault.Item1 || num5 > valueOrDefault.Item3 || !(Grid.ItemContainerGenerator.ContainerFromIndex(i) is DataGridRow parent))
				{
					continue;
				}
				DataGridCellsPresenter dataGridCellsPresenter = FindVisualChild<DataGridCellsPresenter>(parent);
				if (dataGridCellsPresenter == null)
				{
					continue;
				}
				for (int j = valueOrDefault.Item2; j <= valueOrDefault.Item4; j++)
				{
					if (dataGridCellsPresenter.ItemContainerGenerator.ContainerFromIndex(j) is DataGridCell dataGridCell)
					{
						try
						{
							Rect rect = dataGridCell.TransformToAncestor(Grid).TransformBounds(new Rect(dataGridCell.RenderSize));
							num = Math.Min(num, rect.Left);
							num2 = Math.Min(num2, rect.Top);
							num3 = Math.Max(num3, rect.Right);
							num4 = Math.Max(num4, rect.Bottom);
						}
						catch (InvalidOperationException)
						{
						}
					}
				}
			}
			if (double.IsInfinity(num) || double.IsInfinity(num2))
			{
				return null;
			}
			num = Math.Clamp(num, 0.0, Grid.ActualWidth);
			num3 = Math.Clamp(num3, 0.0, Grid.ActualWidth);
			num2 = Math.Clamp(num2, 0.0, Grid.ActualHeight);
			num4 = Math.Clamp(num4, 0.0, Grid.ActualHeight);
			if (!(num3 > num) || !(num4 > num2))
			{
				return null;
			}
			return new Rect(num, num2, num3 - num, num4 - num2);
		}
		return null;
	}

	private void UpdateFormulaReferenceOutline()
	{
		AdornerLayer adornerLayer = AdornerLayer.GetAdornerLayer(Grid);
		(int, int, int, int)? tuple = formulaReferenceRange;
		if (!tuple.HasValue)
		{
			if (formulaReferenceAdorner != null && adornerLayer != null)
			{
				formulaReferenceAdorner.Stop();
				adornerLayer.Remove(formulaReferenceAdorner);
			}
			formulaReferenceAdorner = null;
		}
		else if (adornerLayer != null)
		{
			if (formulaReferenceAdorner == null)
			{
				formulaReferenceAdorner = new CopyMarchingAdorner(Grid, FormulaReferenceRectangle);
				adornerLayer.Add(formulaReferenceAdorner);
			}
			formulaReferenceAdorner.InvalidateVisual();
		}
	}

	private void UpdateCopyOutline()
	{
		if (copiedCells == null)
		{
			if (copyAdorner != null && copyAdornerLayer != null)
			{
				copyAdorner.Stop();
				copyAdornerLayer.Remove(copyAdorner);
			}
			copyAdorner = null;
			copyAdornerLayer = null;
			return;
		}
		if (copyAdornerLayer == null)
		{
			copyAdornerLayer = AdornerLayer.GetAdornerLayer(Grid);
		}
		if (copyAdornerLayer != null)
		{
			if (copyAdorner == null)
			{
				copyAdorner = new CopyMarchingAdorner(Grid, CopyOutlineRectangle);
				copyAdornerLayer.Add(copyAdorner);
			}
			copyAdorner.InvalidateVisual();
		}
	}

	private void CancelCopyMode()
	{
		copiedCells = null;
		copiedSheet = null;
		cutPending = false;
		UpdateCopyOutline();
	}

	private void CopyCell()
	{
		List<(int, int)> source = SelectedCoordinates();
		(int, int, int, int)? tuple = SelectedBounds();
		if (!tuple.HasValue)
		{
			return;
		}
		(int, int, int, int) value = tuple.Value;
		lastSelection = source.ToList();
		Sheet sheet = book.Sheets[activeSheet];
		copiedTop = value.Item1;
		copiedLeft = value.Item2;
		copiedSheet = sheet.Name;
		copiedCells = new List<List<string>>();
		cutPending = false;
		List<string> list = new List<string>();
		var (i, _, _, _) = value;
		for (; i <= value.Item3; i++)
		{
			List<string> list2 = new List<string>();
			List<string> list3 = new List<string>();
			for (int j = value.Item2; j <= value.Item4; j++)
			{
				string item = sheet.Rows.ElementAtOrDefault(i)?.ElementAtOrDefault(j) ?? "";
				list2.Add(item);
				list3.Add(item);
			}
			copiedCells.Add(list3);
			list.Add(string.Join("\t", list2));
		}
		Clipboard.SetText(string.Join("\r\n", list));
		Dispatcher.BeginInvoke(new Action(UpdateCopyOutline), DispatcherPriority.Loaded);
		StatusText.Text = $"Copiadas {value.Item3 - value.Item1 + 1}×{value.Item4 - value.Item2 + 1} celdas · elegí dónde pegar";
	}

	private void PasteLink(int targetRow, int targetCol)
	{
		if (copiedCells == null || copiedSheet == null)
		{
			return;
		}
		int num = book.Sheets.FindIndex((Sheet s) => string.Equals(s.Name, copiedSheet, StringComparison.OrdinalIgnoreCase));
		if (num < 0 || num == activeSheet)
		{
			MessageBox.Show("El vínculo al origen se ofrece al pegar en otra hoja del mismo libro.", "Pegar vínculo", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			return;
		}
		Sheet sheet = book.Sheets[activeSheet];
		int num2 = 0;
		for (int num3 = 0; num3 < copiedCells.Count && targetRow + num3 < 500; num3++)
		{
			for (int num4 = 0; num4 < copiedCells[num3].Count && targetCol + num4 < 26; num4++)
			{
				string key = CellAddress(targetRow + num3, targetCol + num4);
				SetRawCell(sheet, targetRow + num3, targetCol + num4, "");
				sheet.CellLinks[key] = new CellLink
				{
					SourceSheet = copiedSheet,
					SourceRow = copiedTop + num3,
					SourceCol = copiedLeft + num4
				};
				num2++;
			}
		}
		if (num2 != 0)
		{
			RenderSheet();
			Persist();
			SelectCell(targetRow, targetCol);
			StatusText.Text = $"Vínculo al origen creado en {num2} celdas; los cambios de «{copiedSheet}» se reflejarán aquí";
		}
	}

	private void PasteCell()
	{
		(int, int, int, int)? tuple = SelectedBounds();
		if (!tuple.HasValue || !Clipboard.ContainsText())
		{
			return;
		}
		(int, int, int, int) value = tuple.Value;
		string[] array = Clipboard.GetText().Replace("\r\n", "\n").Split('\n');
		int num = Math.Min(array.Length, 500 - value.Item1);
		for (int i = 0; i < num; i++)
		{
			string[] array2 = array[i].Split('\t');
			for (int j = 0; j < Math.Min(array2.Length, 26 - value.Item2); j++)
			{
				SetRawCell(book.Sheets[activeSheet], value.Item1 + i, value.Item2 + j, array2[j]);
			}
		}
		if (cutPending)
		{
			CancelCopyMode();
		}
		RenderSheet();
		Persist();
		SelectCell(value.Item1, value.Item2);
		Dispatcher.BeginInvoke(new Action(UpdateCopyOutline), DispatcherPriority.Loaded);
		StatusText.Text = "Celdas pegadas en " + CellAddress(value.Item1, value.Item2);
	}

	private void SetRawCell(Sheet sh, int row, int col, string value)
	{
		if (CanUseApp)
		{
			while (sh.Rows.Count <= row)
			{
				sh.Rows.Add(new List<string>());
			}
			while (sh.Rows[row].Count <= col)
			{
				sh.Rows[row].Add("");
			}
			string key = CellAddress(row, col);
			sh.Rows[row][col] = value;
			sh.CellLinks.Remove(key);
			sh.CachedFormulaValues.Remove(key);
			sh.CachedFormulaTypes.Remove(key);
		}
	}

	private void ClearCell()
	{
		List<(int, int)> list = SelectedCoordinates();
		if (!SelectedBounds().HasValue)
		{
			return;
		}
		Sheet sh = book.Sheets[activeSheet];
		foreach (var (row, col) in list)
		{
			SetRawCell(sh, row, col, "");
		}
		lastSelection = list.ToList();
		RenderSheet();
		Persist();
		RestoreSelection(list);
		Dispatcher.BeginInvoke(new Action(UpdateCopyOutline), DispatcherPriority.Loaded);
		StatusText.Text = $"Borradas {list.Count} celdas";
	}

	private void WriteSelectedValue(string value)
	{
		if (Grid.SelectedCells.Count != 0 && Grid.SelectedCells[0].Item is DataRowView dataRowView)
		{
			WriteCell(table.Rows.IndexOf(dataRowView.Row), Grid.SelectedCells[0].Column.DisplayIndex, value);
		}
	}

	private void CutCell()
	{
		CopyCell();
		if (copiedCells != null)
		{
			cutPending = true;
			ClearCell();
			StatusText.Text = "Celdas cortadas · elegí dónde moverlas";
		}
	}

	private void Bold_Click(object s, RoutedEventArgs e)
	{
		SetSelectedStyle((CellStyleInfo st) =>
		{
			st.Bold = !st.Bold;
		});
	}

	private void Underline_Click()
	{
		SetSelectedStyle((CellStyleInfo st) =>
		{
			st.Underline = !st.Underline;
		});
	}

	private void Fill_Click(object s, RoutedEventArgs e)
	{
		ShowColorPalette("Color de relleno", fill: true);
	}

	private void ClearCellFormat()
	{
		List<(int, int)> list = SelectedCoordinates();
		if (list.Count == 0)
		{
			return;
		}
		foreach (var (r, c) in list)
		{
			book.Sheets[activeSheet].CellStyles.Remove(CellAddress(r, c));
		}
		RenderSheet();
		Persist();
	}

	private void ChoosePageColor()
	{
		ContextMenu contextMenu = new ContextMenu();
		string[] array = new string[8] { "#FFFFFF", "#F2F2F2", "#E2F0D9", "#DDEBF7", "#FFF2CC", "#FCE4D6", "#E4DFEC", "#D9EAD3" };
		foreach (string hex in array)
		{
			MenuItem menuItem = new MenuItem
			{
				Header = hex,
				Icon = new Border
				{
					Width = 18.0,
					Height = 18.0,
					Background = TryBrush(hex),
					BorderBrush = Brushes.Gray,
					BorderThickness = new Thickness(0.5)
				}
			};
			menuItem.Click += (object _, RoutedEventArgs _) =>
			{
				SetPageColor(hex);
			};
			contextMenu.Items.Add(menuItem);
		}
		contextMenu.Items.Add(new Separator());
		MenuItem menuItem2 = new MenuItem
		{
			Header = "Color personalizado…"
		};
		menuItem2.Click += (object _, RoutedEventArgs _) =>
		{
			string text = PromptText("Color de página", "Ingresá el color en formato #RRGGBB:", book.Sheets[activeSheet].PageColor);
			if (text != null)
			{
				if (Regex.IsMatch(text, "^#[0-9A-Fa-f]{6}$"))
				{
					SetPageColor(text);
				}
				else
				{
					MessageBox.Show("Usá un color #RRGGBB, por ejemplo #E2F0D9.", "Color de página");
				}
			}
		};
		contextMenu.Items.Add(menuItem2);
		contextMenu.PlacementTarget = Grid;
		contextMenu.IsOpen = true;
	}

	private void SetPageColor(string hex)
	{
		book.Sheets[activeSheet].PageColor = hex;
		Grid.Background = TryBrush(hex) ?? Brushes.White;
		Persist();
		StatusText.Text = "Color de página aplicado";
	}

	private void ShowKeyboardHelp()
	{
		MessageBox.Show("Flechas: moverse por celdas · Enter: bajar · Tab: derecha · Shift+Enter/Tab: subir/izquierda · escribí = y usá flechas para insertar referencias.", "Atajos de teclado", MessageBoxButton.OK, MessageBoxImage.Asterisk);
	}

	private void InsertCheckbox()
	{
		List<(int, int)> list = SelectedCoordinates();
		if (list.Count == 0)
		{
			StatusText.Text = "Seleccioná una celda para insertar la casilla";
			return;
		}
		foreach (var (row, col) in list)
		{
			SetRawCell(book.Sheets[activeSheet], row, col, "☐");
		}
		RenderSheet();
		Persist();
	}

	private void CheckFormulaErrors()
	{
		List<string> list = new List<string>();
		Sheet sheet = book.Sheets[activeSheet];
		for (int i = 0; i < sheet.Rows.Count; i++)
		{
			for (int j = 0; j < sheet.Rows[i].Count; j++)
			{
				string text = sheet.Rows[i][j];
				if (text.StartsWith('=') && Display(text, i, j).StartsWith('#'))
				{
					list.Add(CellAddress(i, j) + ": " + Display(text, i, j));
				}
			}
		}
		MessageBox.Show((list.Count == 0) ? "No se encontraron errores en las fórmulas." : ("Errores encontrados:\n" + string.Join("\n", list.Take(20))), "Revisión de fórmulas", MessageBoxButton.OK, (list.Count == 0) ? MessageBoxImage.Asterisk : MessageBoxImage.Exclamation);
	}

	private void AutoSum()
	{
		List<(int, int)> list = SelectedCoordinates();
		if (list.Count == 0)
		{
			StatusText.Text = "Seleccioná las celdas numéricas o la celda donde irá el total";
			return;
		}
		(int top, int left, int bottom, int right) b = SelectedBounds().Value;
		Sheet sh = book.Sheets[activeSheet];
		if (list.Count == 1)
		{
			int item = list[0].Item1;
			int item2 = list[0].Item2;
			int num = item - 1;
			while (num >= 0 && IsNumericCell(sh, num, item2))
			{
				num--;
			}
			if (num < item - 1)
			{
				int num2 = num + 1;
				int num3 = item - 1;
				formulaReferenceRange = (num2, item2, num3, item2);
				UpdateFormulaReferenceOutline();
				WriteCell(item, item2, $"=SUM({CellAddress(num2, item2)}:{CellAddress(num3, item2)})");
				StatusText.Text = "Autosuma: " + CellAddress(num2, item2) + ":" + CellAddress(num3, item2);
				return;
			}
			int num4 = item2 - 1;
			while (num4 >= 0 && IsNumericCell(sh, item, num4))
			{
				num4--;
			}
			if (num4 < item2 - 1)
			{
				int num5 = num4 + 1;
				int num6 = item2 - 1;
				formulaReferenceRange = (item, num5, item, num6);
				UpdateFormulaReferenceOutline();
				WriteCell(item, item2, $"=SUM({CellAddress(item, num5)}:{CellAddress(item, num6)})");
				StatusText.Text = "Autosuma: " + CellAddress(item, num5) + ":" + CellAddress(item, num6);
			}
			else
			{
				MessageBox.Show("No encontré una serie continua de números arriba ni a la izquierda.", "Autosuma", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			}
			return;
		}
		bool flag = list.All(((int row, int col) x) => IsBlank(x.row, x.col));
		if (b.top == b.bottom && b.right > b.left && !flag)
		{
			int item3 = b.left;
			int num7 = b.right;
			int num8 = b.right + 1;
			if (IsBlank(b.top, b.right) && b.right > b.left)
			{
				num7--;
				num8 = b.right;
			}
			if (num8 >= Grid.Columns.Count)
			{
				MessageBox.Show("No hay una celda vacía a la derecha para colocar el total.", "Autosuma", MessageBoxButton.OK, MessageBoxImage.Asterisk);
				return;
			}
			if (!IsBlank(b.top, num8))
			{
				MessageBox.Show("No coloqué el total en " + CellAddress(b.top, num8) + " porque ya tiene contenido.", "Autosuma", MessageBoxButton.OK, MessageBoxImage.Asterisk);
				return;
			}
			if (num7 < item3 || !Enumerable.Range(item3, num7 - item3 + 1).Any((int c) => IsNumericCell(sh, b.top, c)))
			{
				MessageBox.Show("No encontré números en el rango horizontal seleccionado.", "Autosuma", MessageBoxButton.OK, MessageBoxImage.Asterisk);
				return;
			}
			SetRawCell(sh, b.top, num8, $"=SUM({CellAddress(b.top, item3)}:{CellAddress(b.top, num7)})");
			formulaReferenceRange = (b.top, item3, b.top, num7);
			RenderSheet();
			Persist();
			int num9 = 1;
			List<(int, int)> list2 = new List<(int, int)>(num9);
			CollectionsMarshal.SetCount(list2, num9);
			CollectionsMarshal.AsSpan(list2)[0] = (b.top, num8);
			RestoreSelection(list2);
			UpdateFormulaReferenceOutline();
			StatusText.Text = "Autosuma horizontal: " + CellAddress(b.top, item3) + ":" + CellAddress(b.top, num7);
			return;
		}
		int num10 = b.bottom + 1;
		int num11 = b.top;
		int num12 = b.bottom;
		if (flag)
		{
			num10 = b.top;
			num11 = -1;
			num12 = num10 - 1;
		}
		else if (b.bottom > b.top && Enumerable.Range(b.left, b.right - b.left + 1).All((int c) => IsBlank(b.bottom, c)))
		{
			num10 = b.bottom;
			num12 = b.bottom - 1;
		}
		if (num10 >= table.Rows.Count)
		{
			MessageBox.Show("No hay una fila disponible debajo para colocar los totales.", "Autosuma", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			return;
		}
		List<(int, int, string, int, int)> list3 = new List<(int, int, string, int, int)>();
		int col;
		for (col = b.left; col <= b.right; col++)
		{
			int num13 = num11;
			int num14 = num12;
			if (num11 < 0)
			{
				num13 = num10 - 1;
				while (num13 >= 0 && !IsNumericCell(sh, num13, col))
				{
					num13--;
				}
				if (num13 < 0)
				{
					continue;
				}
				num14 = num13;
				while (num13 > 0 && IsNumericCell(sh, num13 - 1, col))
				{
					num13--;
				}
			}
			else if (num14 < num13 || !Enumerable.Range(num13, num14 - num13 + 1).Any((int r) => IsNumericCell(sh, r, col)))
			{
				continue;
			}
			if (!IsBlank(num10, col))
			{
				MessageBox.Show("No coloqué el total en " + CellAddress(num10, col) + " porque ya tiene contenido.", "Autosuma", MessageBoxButton.OK, MessageBoxImage.Asterisk);
				return;
			}
			list3.Add((num10, col, $"=SUM({CellAddress(num13, col)}:{CellAddress(num14, col)})", num13, num14));
		}
		if (list3.Count == 0)
		{
			MessageBox.Show("No encontré números en las columnas del rango seleccionado.", "Autosuma", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			return;
		}
		foreach (var item4 in list3)
		{
			SetRawCell(sh, item4.Item1, item4.Item2, item4.Item3);
		}
		formulaReferenceRange = (list3.Min(((int row, int col, string formula, int top, int bottom) f) => f.top), b.left, list3.Max(((int row, int col, string formula, int top, int bottom) f) => f.bottom), b.right);
		RenderSheet();
		Persist();
		RestoreSelection(list3.Select(((int row, int col, string formula, int top, int bottom) f) => (row: f.row, col: f.col)).ToList());
		UpdateFormulaReferenceOutline();
		StatusText.Text = $"Autosuma: {list3.Count} total(es) vertical(es) agregados";
		bool IsBlank(int r, int c)
		{
			return string.IsNullOrWhiteSpace(sh.Rows.ElementAtOrDefault(r)?.ElementAtOrDefault(c));
		}
	}

	private bool IsNumericCell(Sheet sh, int row, int col)
	{
		int num = book.Sheets.IndexOf(sh);
		if (num < 0)
		{
			return false;
		}
		double result;
		return double.TryParse(CalculateCellValue(num, row, col, new HashSet<string>()), NumberStyles.Any, CultureInfo.InvariantCulture, out result);
	}

	private bool TryCellAddress(string address, out int row, out int col)
	{
		Match match = Regex.Match(address.Trim(), "^\\$?([A-Z]{1,2})\\$?(\\d+)$", RegexOptions.IgnoreCase);
		row = (col = -1);
		if (!match.Success)
		{
			return false;
		}
		col = ColIndex(match.Groups[1].Value);
		if (!int.TryParse(match.Groups[2].Value, out var result))
		{
			return false;
		}
		row = result - 1;
		if (row >= 0 && row < 500 && col >= 0)
		{
			return col < 26;
		}
		return false;
	}

	private void ShowFormulaBuilder(string? preset)
	{
		if (Grid.SelectedCells.Count == 0 || !(Grid.SelectedCells[0].Item is DataRowView dataRowView))
		{
			MessageBox.Show("Seleccioná primero la celda donde querés ver el resultado.", "Constructor de fórmulas", MessageBoxButton.OK, MessageBoxImage.Asterisk);
			return;
		}
		int num = table.Rows.IndexOf(dataRowView.Row);
		int displayIndex = Grid.SelectedCells[0].Column.DisplayIndex;
		string text = CellAddress(num, displayIndex);
		int r = num;
		int c = displayIndex;
		int r2 = num;
		int c2 = displayIndex;
		if (displayIndex >= 2)
		{
			c = displayIndex - 2;
			c2 = displayIndex - 1;
		}
		else if (num >= 2)
		{
			r = num - 2;
			r2 = num - 1;
		}
		else
		{
			r = Math.Min(499, num + 1);
			r2 = Math.Min(499, num + 2);
		}
		string[] array = new string[8] { "Suma (+)", "Resta (−)", "Multiplicación (×)", "División (÷)", "Potencia (^) ", "Porcentaje (%)", "Autosuma de rango", "Producto de rango" };
		Window dialog = new Window
		{
			Title = "Constructor de fórmulas",
			Width = 440.0,
			Height = 360.0,
			Owner = this,
			WindowStartupLocation = WindowStartupLocation.CenterOwner,
			ResizeMode = ResizeMode.NoResize,
			Background = Brushes.White
		};
		StackPanel stackPanel = new StackPanel
		{
			Margin = new Thickness(18.0)
		};
		stackPanel.Children.Add(new TextBlock
		{
			Text = "Resultado en " + text,
			FontWeight = FontWeights.SemiBold,
			Margin = new Thickness(0.0, 0.0, 0.0, 12.0)
		});
		stackPanel.Children.Add(new TextBlock
		{
			Text = "Operación"
		});
		ComboBox combo = new ComboBox
		{
			ItemsSource = array,
			SelectedIndex = 0,
			Margin = new Thickness(0.0, 4.0, 0.0, 12.0),
			Padding = new Thickness(5.0)
		};
		if (preset != null)
		{
			int num2 = Array.FindIndex(array, (string x) => x.Contains("(" + preset + ")", StringComparison.Ordinal));
			if (num2 >= 0)
			{
				combo.SelectedIndex = num2;
			}
		}
		stackPanel.Children.Add(combo);
		stackPanel.Children.Add(new TextBlock
		{
			Text = "Celda o inicio del rango"
		});
		TextBox first = new TextBox
		{
			Text = CellAddress(r, c),
			Margin = new Thickness(0.0, 4.0, 0.0, 10.0),
			Padding = new Thickness(5.0)
		};
		stackPanel.Children.Add(first);
		stackPanel.Children.Add(new TextBlock
		{
			Text = "Segunda celda o fin del rango"
		});
		TextBox second = new TextBox
		{
			Text = CellAddress(r2, c2),
			Margin = new Thickness(0.0, 4.0, 0.0, 12.0),
			Padding = new Thickness(5.0)
		};
		stackPanel.Children.Add(second);
		StackPanel stackPanel2 = new StackPanel
		{
			Orientation = Orientation.Horizontal,
			HorizontalAlignment = HorizontalAlignment.Right
		};
		Button button = new Button
		{
			Content = "Cancelar",
			Padding = new Thickness(12.0, 5.0, 12.0, 5.0),
			Margin = new Thickness(0.0, 0.0, 8.0, 0.0)
		};
		Button button2 = new Button
		{
			Content = "Insertar fórmula",
			Padding = new Thickness(12.0, 5.0, 12.0, 5.0),
			IsDefault = true,
			Background = new SolidColorBrush(Color.FromRgb(33, 115, 70)),
			Foreground = Brushes.White
		};
		stackPanel2.Children.Add(button);
		stackPanel2.Children.Add(button2);
		stackPanel.Children.Add(stackPanel2);
		dialog.Content = stackPanel;
		string result = null;
		button.Click += (object _, RoutedEventArgs _) =>
		{
			dialog.Close();
		};
		button2.Click += (object _, RoutedEventArgs _) =>
		{
			if (!TryCellAddress(first.Text, out var row, out var col) || !TryCellAddress(second.Text, out col, out row))
			{
				MessageBox.Show("Usá referencias de celda como A1 o C12.", "Fórmula", MessageBoxButton.OK, MessageBoxImage.Exclamation);
			}
			else
			{
				string text2 = first.Text.Trim().ToUpperInvariant();
				string text3 = second.Text.Trim().ToUpperInvariant();
				result = (Convert.ToString(combo.SelectedItem) ?? "") switch
				{
					"Suma (+)" => "=" + text2 + "+" + text3, 
					"Resta (−)" => "=" + text2 + "-" + text3, 
					"Multiplicación (×)" => "=" + text2 + "*" + text3, 
					"División (÷)" => "=" + text2 + "/" + text3, 
					"Potencia (^) " => "=" + text2 + "^" + text3, 
					"Porcentaje (%)" => "=" + text2 + "/100", 
					"Autosuma de rango" => $"=SUM({text2}:{text3})", 
					"Producto de rango" => $"=PRODUCT({text2}:{text3})", 
					_ => "=" + text2 + "+" + text3, 
				};
				dialog.Close();
			}
		};
		dialog.ShowDialog();
		if (result != null)
		{
			WriteCell(num, displayIndex, result);
		}
	}

	private void FindReplace()
	{
		Window dialog = new Window
		{
			Title = "Buscar y reemplazar",
			Width = 410.0,
			Height = 260.0,
			Owner = this,
			WindowStartupLocation = WindowStartupLocation.CenterOwner,
			ResizeMode = ResizeMode.NoResize,
			Background = Brushes.White
		};
		StackPanel stackPanel = new StackPanel
		{
			Margin = new Thickness(18.0)
		};
		stackPanel.Children.Add(new TextBlock
		{
			Text = "Buscar"
		});
		TextBox find = new TextBox
		{
			Margin = new Thickness(0.0, 4.0, 0.0, 10.0),
			Padding = new Thickness(5.0)
		};
		stackPanel.Children.Add(find);
		stackPanel.Children.Add(new TextBlock
		{
			Text = "Reemplazar por"
		});
		TextBox replace = new TextBox
		{
			Margin = new Thickness(0.0, 4.0, 0.0, 14.0),
			Padding = new Thickness(5.0)
		};
		stackPanel.Children.Add(replace);
		StackPanel stackPanel2 = new StackPanel
		{
			Orientation = Orientation.Horizontal,
			HorizontalAlignment = HorizontalAlignment.Right
		};
		Button button = new Button
		{
			Content = "Buscar siguiente",
			Padding = new Thickness(10.0, 5.0, 10.0, 5.0),
			Margin = new Thickness(0.0, 0.0, 8.0, 0.0)
		};
		Button button2 = new Button
		{
			Content = "Reemplazar todo",
			Padding = new Thickness(10.0, 5.0, 10.0, 5.0)
		};
		Button button3 = new Button
		{
			Content = "Cerrar",
			Padding = new Thickness(10.0, 5.0, 10.0, 5.0),
			Margin = new Thickness(8.0, 0.0, 0.0, 0.0)
		};
		stackPanel2.Children.Add(button);
		stackPanel2.Children.Add(button2);
		stackPanel2.Children.Add(button3);
		stackPanel.Children.Add(stackPanel2);
		dialog.Content = stackPanel;
		button.Click += (object _, RoutedEventArgs _) =>
		{
			if (find.Text.Length != 0)
			{
				FindNext(find.Text);
				dialog.Close();
			}
		};
		button2.Click += (object _, RoutedEventArgs _) =>
		{
			if (find.Text.Length > 0)
			{
				ReplaceAll(find.Text, replace.Text);
			}
			dialog.Close();
		};
		button3.Click += (object _, RoutedEventArgs _) =>
		{
			dialog.Close();
		};
		dialog.ShowDialog();
	}

	private void FindNext(string value)
	{
		Sheet sheet = book.Sheets[activeSheet];
		int num = ((Grid.SelectedCells.Count > 0 && Grid.SelectedCells[0].Item is DataRowView dataRowView) ? table.Rows.IndexOf(dataRowView.Row) : 0);
		int num2 = ((Grid.SelectedCells.Count > 0) ? Grid.SelectedCells[0].Column.DisplayIndex : (-1));
		for (int i = 1; i <= table.Rows.Count * table.Columns.Count; i++)
		{
			int num3 = (num * table.Columns.Count + num2 + i) % (table.Rows.Count * table.Columns.Count);
			int num4 = num3 / table.Columns.Count;
			int num5 = num3 % table.Columns.Count;
			if ((sheet.Rows.ElementAtOrDefault(num4)?.ElementAtOrDefault(num5) ?? "").Contains(value, StringComparison.CurrentCultureIgnoreCase))
			{
				SelectCell(num4, num5);
				StatusText.Text = "Encontrado en " + CellAddress(num4, num5);
				return;
			}
		}
		MessageBox.Show("No se encontró ese texto en esta hoja.", "Buscar", MessageBoxButton.OK, MessageBoxImage.Asterisk);
	}

	private void ReplaceAll(string find, string replacement)
	{
		Sheet sheet = book.Sheets[activeSheet];
		int num = 0;
		for (int i = 0; i < sheet.Rows.Count; i++)
		{
			for (int j = 0; j < sheet.Rows[i].Count; j++)
			{
				string text = sheet.Rows[i][j];
				if (!text.StartsWith('=') && text.Contains(find, StringComparison.CurrentCultureIgnoreCase))
				{
					sheet.Rows[i][j] = Regex.Replace(text, Regex.Escape(find), (Match _) => replacement, RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
					string key = CellAddress(i, j);
					sheet.CachedFormulaValues.Remove(key);
					sheet.CachedFormulaTypes.Remove(key);
					num++;
				}
			}
		}
		Recalculate();
		Persist();
		StatusText.Text = $"Reemplazos: {num}";
	}

	private void UpdateStatus()
	{
		StatusText.Text = $"{book.Sheets[activeSheet].Name} · {table.Rows.Count} filas · {table.Columns.Count} columnas";
	}

	private static string ColName(int c)
	{
		string text = "";
		for (c++; c > 0; c = (c - 1) / 26)
		{
			text = (char)(65 + (c - 1) % 26) + text;
		}
		return text;
	}

	private string Formula(string f)
	{
		return EvaluateFormula(f, activeSheet, 499, 25, new HashSet<string>());
	}

	private string EvaluateFormula(string f, int sheetIndex, int row, int col, HashSet<string> stack)
	{
		return new FormulaEngine((int r, int c) => CalculateCellValue(sheetIndex, r, c, stack)).Evaluate(f);
	}

	private static int ColIndex(string s)
	{
		int num = 0;
		string text = s.ToUpperInvariant();
		foreach (char c in text)
		{
			num = num * 26 + c - 65 + 1;
		}
		return num - 1;
	}

	private static XDocument LoadXml(ZipArchive zip, string path)
	{
		using Stream stream = (zip.GetEntry(path.Replace('\\', '/')) ?? throw new InvalidDataException("Falta el componente " + path)).Open();
		return XDocument.Load(stream);
	}

	private static int CellRow(string a)
	{
		Match match = Regex.Match(a, "\\d+");
		if (!match.Success)
		{
			return 0;
		}
		return Math.Max(0, int.Parse(match.Value) - 1);
	}

	private static int CellCol(string a)
	{
		return ColIndex(new string(a.TakeWhile(char.IsLetter).ToArray()));
	}

	private static string CellAddress(int r, int c)
	{
		string text = "";
		for (c++; c > 0; c = (c - 1) / 26)
		{
			text = (char)(65 + (c - 1) % 26) + text;
		}
		return text + (r + 1);
	}

	private static string SafeSheetName(string name)
	{
		char[] array = new char[7] { '[', ']', ':', '*', '?', '/', '\\' };
		foreach (char oldChar in array)
		{
			name = name.Replace(oldChar, '_');
		}
		if (name.Length <= 31)
		{
			return name;
		}
		return name.Substring(0, 31);
	}

	private void ShowPlansWindow()
	{
		Window window = new Window
		{
			Title = "GEXE · Planes y suscripción",
			Owner = this,
			Width = 1040.0,
			Height = 760.0,
			MinWidth = 760.0,
			MinHeight = 540.0,
			WindowStartupLocation = WindowStartupLocation.CenterOwner,
			Background = new SolidColorBrush(Color.FromRgb(246, 248, 250))
		};
		Grid grid = new Grid
		{
			Margin = new Thickness(24.0),
			Background = window.Background
		};
		grid.RowDefinitions.Add(new RowDefinition
		{
			Height = GridLength.Auto
		});
		grid.RowDefinitions.Add(new RowDefinition
		{
			Height = new GridLength(1.0, GridUnitType.Star)
		});
		grid.RowDefinitions.Add(new RowDefinition
		{
			Height = GridLength.Auto
		});
		StackPanel stackPanel = new StackPanel
		{
			Margin = new Thickness(0.0, 0.0, 0.0, 18.0)
		};
		stackPanel.Children.Add(new TextBlock
		{
			Text = "Elegí tu plan GEXE",
			FontSize = 27.0,
			FontWeight = FontWeights.SemiBold,
			Foreground = new SolidColorBrush(Color.FromRgb(35, 55, 44))
		});
		stackPanel.Children.Add(new TextBlock
		{
			Text = "Empezá gratis o elegí cómo querés pagar.",
			FontSize = 14.0,
			Foreground = Brushes.DimGray,
			Margin = new Thickness(0.0, 6.0, 0.0, 0.0)
		});
		grid.Children.Add(stackPanel);
		TabControl tabControl = new TabControl
		{
			Background = Brushes.White,
			BorderBrush = new SolidColorBrush(Color.FromRgb(218, 225, 221))
		};
		System.Windows.Controls.Grid.SetRow(tabControl, 1);
		grid.Children.Add(tabControl);
		StackPanel stackPanel2 = new StackPanel
		{
			Margin = new Thickness(14.0)
		};
		Grid cards = new Grid();
		for (int i = 0; i < 3; i++)
		{
			cards.ColumnDefinitions.Add(new ColumnDefinition
			{
				Width = new GridLength(1.0, GridUnitType.Star)
			});
		}
		AddCard(Card("free", "Gratis", "USD 0", "Prueba de 5 días", "Después de 5 días, necesitás comprar y activar una licencia para seguir trabajando.", new string[4] { "Hasta 25 libros guardados en GEXE", "1 dispositivo", "Hojas, fórmulas y XLSX local", "Copias y exportaciones locales sin límite" }, "Tu plan actual", null), 0);
		AddCard(Card("personal", "Mensual", "USD 28,15", "por mes", "Una suscripción con pago mensual.", new string[4] { "Renovación mensual", "Trabajo con hojas y fórmulas", "Conexión Google para tus libros", "Copias y exportaciones locales" }, "Pagar mensual", OpenPersonalCheckout), 1);
		AddCard(Card("one_time", "Pago único", "USD 201,09", "un solo pago", "Un pago, sin renovación mensual.", new string[3] { "Sin cuotas mensuales", "Precio fijo en dólares", "Licencia para GEXE 1.x, hasta 3 computadoras" }, "Pagar una vez", () =>
		{
			OpenPlanCheckout("one_time");
		}), 2);
		stackPanel2.Children.Add(cards);
		stackPanel2.Children.Add(new TextBlock
		{
			Name = "PaymentActivationNotice",
			Text = "Después de comprar, ingresá tu clave en Mi plan para activar el mensual o pago único. Actualmente los cobros están en modo de prueba: todavía no hay compras reales ni activación con claves de prueba.",
			TextWrapping = TextWrapping.Wrap,
			Foreground = Brushes.DimGray,
			Margin = new Thickness(6.0, 14.0, 6.0, 6.0),
			FontSize = 12.0
		});
		tabControl.Items.Add(new TabItem
		{
			Header = "Planes",
			Content = new ScrollViewer
			{
				Content = stackPanel2,
				VerticalScrollBarVisibility = ScrollBarVisibility.Auto
			}
		});
		StackPanel stackPanel3 = new StackPanel
		{
			Margin = new Thickness(24.0)
		};
		stackPanel3.Children.Add(BuildLicensePanel());
		tabControl.Items.Add(new TabItem
		{
			Header = "Mi plan",
			Content = new ScrollViewer
			{
				Content = stackPanel3,
				VerticalScrollBarVisibility = ScrollBarVisibility.Auto
			}
		});
		StackPanel stackPanel4 = new StackPanel
		{
			Margin = new Thickness(24.0)
		};
		stackPanel4.Children.Add(new TextBlock
		{
			Text = "Pagos",
			FontSize = 22.0,
			FontWeight = FontWeights.SemiBold,
			Margin = new Thickness(0.0, 0.0, 0.0, 12.0)
		});
		stackPanel4.Children.Add(new TextBlock
		{
			Text = "Elegí la opción que querés pagar. El importe y las condiciones se confirman antes de completar la compra.",
			TextWrapping = TextWrapping.Wrap,
			Foreground = Brushes.DimGray,
			Margin = new Thickness(0.0, 0.0, 0.0, 18.0)
		});
		Button button = new Button
		{
			Name = "BillingMonthlyCheckoutButton",
			Content = "Pagar mensual · USD 28,15 / mes",
			Padding = new Thickness(14.0, 9.0, 14.0, 9.0),
			Margin = new Thickness(0.0, 0.0, 0.0, 10.0),
			HorizontalAlignment = HorizontalAlignment.Left
		};
		button.Click += (object _, RoutedEventArgs _) =>
		{
			OpenPersonalCheckout();
		};
		stackPanel4.Children.Add(button);
		Button button2 = new Button
		{
			Name = "BillingOneTimeCheckoutButton",
			Content = "Pagar una vez · USD 201,09",
			Padding = new Thickness(14.0, 9.0, 14.0, 9.0),
			HorizontalAlignment = HorizontalAlignment.Left
		};
		button2.Click += (object _, RoutedEventArgs _) =>
		{
			OpenPlanCheckout("one_time");
		};
		stackPanel4.Children.Add(button2);
		stackPanel4.Children.Add(new TextBlock
		{
			Text = "Ambos planes se activan con la clave recibida al comprar, desde Mi plan. La prueba gratis dura cinco días desde el primer inicio de esta versión.",
			TextWrapping = TextWrapping.Wrap,
			Foreground = Brushes.DimGray,
			Margin = new Thickness(0.0, 20.0, 0.0, 0.0)
		});
		tabControl.Items.Add(new TabItem
		{
			Header = "Pagos",
			Content = stackPanel4
		});
		Button button3 = new Button
		{
			Content = "Cerrar",
			HorizontalAlignment = HorizontalAlignment.Right,
			Padding = new Thickness(18.0, 7.0, 18.0, 7.0),
			Margin = new Thickness(0.0, 14.0, 0.0, 0.0)
		};
		button3.Click += (object _, RoutedEventArgs _) =>
		{
			window.Close();
		};
		System.Windows.Controls.Grid.SetRow(button3, 2);
		grid.Children.Add(button3);
		window.Content = grid;
		window.ShowDialog();
		void AddCard(Border card, int column)
		{
			System.Windows.Controls.Grid.SetColumn(card, column);
			cards.Children.Add(card);
		}
		Border Card(string code, string title, string price, string period, string summary, string[] features, string buttonText, Action? action)
		{
			bool free = code == "free";
			Grid grid2 = new Grid
			{
				Margin = new Thickness(18.0)
			};
			grid2.RowDefinitions.Add(new RowDefinition
			{
				Height = GridLength.Auto
			});
			grid2.RowDefinitions.Add(new RowDefinition
			{
				Height = new GridLength(1.0, GridUnitType.Star)
			});
			grid2.RowDefinitions.Add(new RowDefinition
			{
				Height = GridLength.Auto
			});
			StackPanel element = new StackPanel
			{
				Children = 
				{
					(UIElement)new TextBlock
					{
						Name = "PlanTitle_" + code,
						Text = title,
						FontSize = 19.0,
						FontWeight = FontWeights.SemiBold
					},
					(UIElement)new TextBlock
					{
						Name = "PlanPrice_" + code,
						Text = price,
						FontSize = 25.0,
						FontWeight = FontWeights.Bold,
						Foreground = new SolidColorBrush(Color.FromRgb(33, 115, 70)),
						Margin = new Thickness(0.0, 14.0, 0.0, 2.0)
					},
					(UIElement)new TextBlock
					{
						Text = period,
						FontSize = 12.0,
						Foreground = Brushes.DimGray
					},
					(UIElement)new TextBlock
					{
						Text = summary,
						TextWrapping = TextWrapping.Wrap,
						Margin = new Thickness(0.0, 14.0, 0.0, 12.0),
						Foreground = Brushes.DimGray
					}
				}
			};
			grid2.Children.Add(element);
			StackPanel stackPanel5 = new StackPanel();
			foreach (string text in features)
			{
				stackPanel5.Children.Add(new TextBlock
				{
					Text = "•  " + text,
					TextWrapping = TextWrapping.Wrap,
					Margin = new Thickness(0.0, 5.0, 0.0, 5.0),
					Foreground = new SolidColorBrush(Color.FromRgb(65, 75, 70))
				});
			}
			if (free)
			{
				stackPanel5.Children.Add(BuildFreeSyncNotice());
			}
			System.Windows.Controls.Grid.SetRow(stackPanel5, 1);
			grid2.Children.Add(stackPanel5);
			Button button4 = new Button
			{
				Name = (free ? "FreePlanButton" : ((code == "personal") ? "MonthlyCheckoutButton" : "OneTimeCheckoutButton")),
				Content = buttonText,
				Padding = new Thickness(12.0, 9.0, 12.0, 9.0),
				Margin = new Thickness(0.0, 20.0, 0.0, 0.0),
				IsEnabled = !free,
				Background = (free ? new SolidColorBrush(Color.FromRgb(238, 243, 240)) : new SolidColorBrush(Color.FromRgb(33, 115, 70))),
				Foreground = (free ? new SolidColorBrush(Color.FromRgb(45, 90, 65)) : Brushes.White)
			};
			ObserveLicense(button4, RefreshPlan);
			if (action != null)
			{
				button4.Click += (object _, RoutedEventArgs _) =>
				{
					action();
				};
			}
			System.Windows.Controls.Grid.SetRow(button4, 2);
			grid2.Children.Add(button4);
			return new Border
			{
				Child = grid2,
				Margin = new Thickness(5.0),
				MinHeight = 380.0,
				Background = Brushes.White,
				BorderBrush = (free ? new SolidColorBrush(Color.FromRgb(135, 183, 151)) : new SolidColorBrush(Color.FromRgb(218, 225, 221))),
				BorderThickness = new Thickness((!free) ? 1 : 2),
				CornerRadius = new CornerRadius(6.0)
			};
			void RefreshPlan()
			{
				bool flag = (free ? (!HasPaidLicense) : (code == licenseView.Plan && HasPaidLicense));
				button4.Content = (flag ? "Tu plan actual" : buttonText);
				button4.IsEnabled = !free && !flag;
			}
		}
	}

	private Border BuildFreeSyncNotice()
	{
		Border notice = new Border
		{
			Padding = new Thickness(10.0),
			Margin = new Thickness(0.0, 10.0, 0.0, 0.0),
			Background = new SolidColorBrush(Color.FromRgb(byte.MaxValue, 247, 224)),
			BorderBrush = new SolidColorBrush(Color.FromRgb(229, 194, 107)),
			BorderThickness = new Thickness(1.0),
			Child = new TextBlock
			{
				Name = "FreeSyncWarning",
				Text = "Plan Gratis: la sincronización puede dejar de estar disponible en este plan. Tus libros locales se conservan; guardá copias de respaldo.",
				TextWrapping = TextWrapping.Wrap,
				Foreground = new SolidColorBrush(Color.FromRgb(112, 78, 15)),
				FontSize = 12.0
			}
		};
		ObserveLicense(notice, () =>
		{
			notice.Visibility = (HasPaidLicense ? Visibility.Collapsed : Visibility.Visible);
		});
		return notice;
	}

	private async Task<bool> EnsureGoogleConnectedAsync(CancellationToken cancellationToken = default(CancellationToken))
	{
		if (cloudDrive == null)
		{
			cloudDrive = GoogleDriveSync.Load(DriveSettingsPath);
		}
		if (cloudDrive == null)
		{
			string text = LoadBundledGoogleClientId() ?? PromptClientId();
			if (string.IsNullOrWhiteSpace(text))
			{
				return false;
			}
			SaveStatus.Text = "Esperando autorización de Google…";
			using CancellationTokenSource timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
			timeout.CancelAfter(TimeSpan.FromMinutes(5L));
			cloudDrive = await GoogleDriveSync.ConnectAsync(text.Trim(), DriveSettingsPath, timeout.Token, LoadBundledGoogleClientSecret());
		}
		UpdateAccountBadge();
		StartCloudSync();
		return true;
	}

	private Border BuildStartGoogleAccount(Window owner)
	{
		StackPanel stackPanel = new StackPanel();
		stackPanel.Children.Add(new TextBlock
		{
			Text = "Tu cuenta Google",
			FontSize = 18.0,
			FontWeight = FontWeights.SemiBold,
			Foreground = new SolidColorBrush(Color.FromRgb(33, 115, 70))
		});
		TextBlock status = new TextBlock
		{
			Name = "StartGoogleAccountStatus",
			TextWrapping = TextWrapping.Wrap,
			Margin = new Thickness(0.0, 7.0, 0.0, 10.0)
		};
		stackPanel.Children.Add(status);
		Button connect = new Button
		{
			Name = "StartGoogleConnectButton",
			Padding = new Thickness(16.0, 8.0, 16.0, 8.0),
			HorizontalAlignment = HorizontalAlignment.Left,
			Background = new SolidColorBrush(Color.FromRgb(33, 115, 70)),
			Foreground = Brushes.White
		};
		Refresh();
		CancellationTokenSource cancellation = new CancellationTokenSource();
		bool connecting = false;
		owner.Closed += (object? _, EventArgs _) =>
		{
			cancellation.Cancel();
			if (!connecting)
			{
				cancellation.Dispose();
			}
		};
		connect.Click += async (object _, RoutedEventArgs _) =>
		{
			connecting = true;
			connect.IsEnabled = false;
			connect.Content = "Conectando…";
			status.Text = "Completá la autorización de tu cuenta en el navegador. Podés volver a esta pantalla al terminar.";
			try
			{
				if (await EnsureGoogleConnectedAsync(cancellation.Token))
				{
					if (owner.IsVisible)
					{
						Refresh();
					}
				}
				else if (owner.IsVisible)
				{
					Refresh();
				}
			}
			catch (OperationCanceledException)
			{
				if (owner.IsVisible)
				{
					Refresh();
					status.Text = "La conexión se canceló o tardó demasiado. Podés intentarlo otra vez.";
				}
			}
			catch (Exception ex2)
			{
				if (owner.IsVisible)
				{
					Refresh();
					status.Text = "No se pudo conectar Google. " + ex2.Message;
				}
			}
			finally
			{
				connecting = false;
				if (cancellation.IsCancellationRequested)
				{
					cancellation.Dispose();
				}
			}
		};
		stackPanel.Children.Add(connect);
		stackPanel.Children.Add(BuildFreeSyncNotice());
		return new Border
		{
			Child = stackPanel,
			Padding = new Thickness(18.0),
			Margin = new Thickness(0.0, 0.0, 0.0, 18.0),
			Background = new SolidColorBrush(Color.FromRgb(241, 247, 243)),
			BorderBrush = new SolidColorBrush(Color.FromRgb(196, 218, 204)),
			BorderThickness = new Thickness(1.0),
			CornerRadius = new CornerRadius(4.0)
		};
		void Refresh()
		{
			bool flag = cloudDrive != null || GoogleDriveSync.Load(DriveSettingsPath) != null;
			status.Text = (flag ? "Google está conectado en esta computadora. Podés abrir tus libros y activar la sincronización." : "Conectá tu cuenta para sincronizar tus libros entre computadoras. No necesitás abrir un libro para iniciar sesión.");
			connect.Content = (flag ? "Google conectado ✓" : "Conectar Google");
			connect.IsEnabled = !flag;
		}
	}

	internal MainWindow(TrialService trial)
		: this()
	{
		trialService = trial;
	}

	private void StartTrialChecks()
	{
		if (!trialInitialized)
		{
			if (trialService == null)
			{
				trialService = new TrialService(new ProtectedTrialStorage(System.IO.Path.Combine(DataDirectory, "trial-v1.dat")), LicenseDevice.Fingerprint(DataDirectory));
			}
			trialView = trialService.Start();
			trialInitialized = true;
			trialTimer = new DispatcherTimer
			{
				Interval = TimeSpan.FromSeconds(20L)
			};
			trialTimer.Tick += (object? _, EventArgs _) =>
			{
				CheckTrialAccess();
			};
			trialTimer.Start();
			Closed += (object? _, EventArgs _) =>
			{
				trialClosing = true;
				trialTimer.Stop();
			};
			Dispatcher.BeginInvoke(new Action(CheckTrialAccess));
		}
	}

	private void CheckTrialAccess()
	{
		if (trialClosing || !trialInitialized)
		{
			return;
		}
		trialView = trialService.Check();
		Action[] array = licenseObservers.ToArray();
		for (int i = 0; i < array.Length; i++)
		{
			array[i]();
		}
		WrapPanel actions;
		if (CanUseApp)
		{
			((UIElement)Content).IsEnabled = true;
			Grid.IsReadOnly = false;
			FormulaBox.IsReadOnly = false;
			trialLock?.Close();
		}
		else
		{
			if (trialLock != null)
			{
				return;
			}
			committingTrialEdit = true;
			try
			{
				CommitPendingEditForHistory();
				CommitTable();
				Persist();
			}
			finally
			{
				committingTrialEdit = false;
			}
			((UIElement)Content).IsEnabled = false;
			Grid.IsReadOnly = true;
			FormulaBox.IsReadOnly = true;
			CloseCellSuggestions();
			Window owner = Application.Current.Windows.Cast<Window>().LastOrDefault((Window w) => w.IsVisible) ?? this;
			Window dialog = new Window
			{
				Title = "GEXE · Activar para continuar",
				Owner = owner,
				Width = 700.0,
				Height = 720.0,
				MinWidth = 480.0,
				MinHeight = 480.0,
				WindowStartupLocation = WindowStartupLocation.CenterOwner,
				Background = Brushes.White
			};
			trialLock = dialog;
			bool exit = false;
			dialog.Closing += (object? _, CancelEventArgs e) =>
			{
				if (!CanUseApp && !exit && !trialClosing)
				{
					e.Cancel = true;
				}
			};
			StackPanel stackPanel = new StackPanel
			{
				Margin = new Thickness(22.0)
			};
			stackPanel.Children.Add(new TextBlock
			{
				Name = "TrialExpiredMessage",
				Text = TrialStatus,
				FontSize = 20.0,
				FontWeight = FontWeights.SemiBold,
				TextWrapping = TextWrapping.Wrap
			});
			stackPanel.Children.Add(new TextBlock
			{
				Text = "Tus libros siguen guardados. Podés guardar una copia aunque no compres. Para editar o sincronizar necesitás una licencia activa.",
				Margin = new Thickness(0.0, 12.0, 0.0, 12.0),
				TextWrapping = TextWrapping.Wrap
			});
			actions = new WrapPanel();
			Add("TrialMonthlyButton", "Mensual · USD 28,15", OpenPersonalCheckout);
			Add("TrialOneTimeButton", "Pago único · USD 201,09", () =>
			{
				OpenPlanCheckout("one_time");
			});
			Add("TrialBackupButton", "Guardar copia de mis libros", SaveTrialBackup);
			Add("TrialExitButton", "Salir", () =>
			{
				exit = true;
				trialClosing = true;
				dialog.Close();
				Application.Current.Shutdown();
			});
			stackPanel.Children.Add(actions);
			stackPanel.Children.Add(BuildUpdateCard(dialog));
			stackPanel.Children.Add(BuildLicensePanel());
			dialog.Content = new ScrollViewer
			{
				Background = Brushes.White,
				Content = stackPanel,
				VerticalScrollBarVisibility = ScrollBarVisibility.Auto
			};
			try
			{
				dialog.ShowDialog();
			}
			finally
			{
				trialLock = null;
				if (!trialClosing && CanUseApp)
				{
					((UIElement)Content).IsEnabled = true;
					Grid.IsReadOnly = false;
					FormulaBox.IsReadOnly = false;
				}
			}
		}
		void Add(string name, string text, Action action)
		{
			Button button = new Button
			{
				Name = name,
				Content = text,
				Padding = new Thickness(10.0, 7.0, 10.0, 7.0),
				Margin = new Thickness(0.0, 0.0, 8.0, 8.0)
			};
			button.Click += (object _, RoutedEventArgs _) =>
			{
				action();
			};
			actions.Children.Add(button);
		}
	}

	internal static void CreateTrialBackup(string destination, string recovery, string booksDirectory)
	{
		using FileStream stream = File.Create(destination);
		using ZipArchive destination2 = new ZipArchive(stream, ZipArchiveMode.Create);
		if (File.Exists(recovery))
		{
			destination2.CreateEntryFromFile(recovery, "Libro-actual.gexe");
		}
		if (!Directory.Exists(booksDirectory))
		{
			return;
		}
		foreach (string item in Directory.EnumerateFiles(booksDirectory).Where((string f) =>
		{
			string text = System.IO.Path.GetExtension(f).ToLowerInvariant();
			return (text == ".xlsx" || text == ".gexe") ? true : false;
		}))
		{
			destination2.CreateEntryFromFile(item, "Libros/" + System.IO.Path.GetFileName(item));
		}
	}

	private void SaveTrialBackup()
	{
		SaveFileDialog saveFileDialog = new SaveFileDialog
		{
			Filter = "Copia de libros GEXE (*.zip)|*.zip",
			FileName = "Mis-libros-GEXE.zip",
			AddExtension = true,
			OverwritePrompt = true
		};
		if (saveFileDialog.ShowDialog(trialLock) != true)
		{
			return;
		}
		try
		{
			CreateTrialBackup(saveFileDialog.FileName, AutoPath, BooksDirectory);
			MessageBox.Show(trialLock, "Se guardó la copia de tus libros.", "GEXE");
		}
		catch
		{
			MessageBox.Show(trialLock, "No se pudo guardar la copia. Elegí otro nombre y ubicación.", "GEXE");
		}
	}

	private Dictionary<int, CellStyleInfo> ReadXlsxCellStyles(ZipArchive zip, XNamespace m)
	{
		Dictionary<int, CellStyleInfo> dictionary = new Dictionary<int, CellStyleInfo>();
		ZipArchiveEntry entry = zip.GetEntry("xl/styles.xml");
		if (entry == null)
		{
			return dictionary;
		}
		using Stream stream = entry.Open();
		XElement root = XDocument.Load(stream).Root;
		if (root == null)
		{
			return dictionary;
		}
		List<string> theme = ReadXlsxThemeColors(zip);
		List<XElement> list = (root.Element(m + "fonts")?.Elements(m + "font") ?? Array.Empty<XElement>()).ToList();
		List<XElement> list2 = (root.Element(m + "fills")?.Elements(m + "fill") ?? Array.Empty<XElement>()).ToList();
		List<XElement> list3 = (root.Element(m + "borders")?.Elements(m + "border") ?? Array.Empty<XElement>()).ToList();
		List<XElement> list4 = (root.Element(m + "cellXfs")?.Elements(m + "xf") ?? Array.Empty<XElement>()).ToList();
		for (int i = 0; i < list4.Count; i++)
		{
			XElement xElement = list4[i];
			int valueOrDefault = ((int?)xElement.Attribute("fontId")).GetValueOrDefault();
			int valueOrDefault2 = ((int?)xElement.Attribute("fillId")).GetValueOrDefault();
			int valueOrDefault3 = ((int?)xElement.Attribute("borderId")).GetValueOrDefault();
			XElement xElement2 = ((valueOrDefault >= 0 && valueOrDefault < list.Count) ? list[valueOrDefault] : null);
			XElement obj = ((valueOrDefault2 >= 0 && valueOrDefault2 < list2.Count) ? list2[valueOrDefault2] : null);
			XElement xElement3 = ((valueOrDefault3 >= 0 && valueOrDefault3 < list3.Count) ? list3[valueOrDefault3] : null);
			string text = ResolveXlsxColor(xElement2?.Element(m + "color"), theme);
			string fillColor = ResolveXlsxColor(obj?.Descendants(m + "fgColor").FirstOrDefault(), theme);
			string borderColor = xElement3?.Elements().Select((XElement side) => ResolveXlsxColor(side.Element(m + "color"), theme)).FirstOrDefault((string color) => color != null);
			double? num = (double?)xElement2?.Element(m + "sz")?.Attribute("val");
			string text2 = (string?)xElement2?.Element(m + "name")?.Attribute("val");
			string text3 = (string?)xElement.Element(m + "alignment")?.Attribute("horizontal");
			if (valueOrDefault != 0 || valueOrDefault2 != 0 || valueOrDefault3 != 0 || text != null || text2 != null || num.HasValue || IsXlsxOn(xElement2?.Element(m + "b")) || IsXlsxOn(xElement2?.Element(m + "i")) || IsXlsxOn(xElement2?.Element(m + "u")) || text3 != null)
			{
				Dictionary<int, CellStyleInfo> dictionary2 = dictionary;
				int key = i;
				CellStyleInfo cellStyleInfo = new CellStyleInfo();
				cellStyleInfo.FontFamily = text2 ?? "Segoe UI";
				cellStyleInfo.FontSize = num ?? 13.0;
				cellStyleInfo.Bold = IsXlsxOn(xElement2?.Element(m + "b"));
				cellStyleInfo.Italic = IsXlsxOn(xElement2?.Element(m + "i"));
				cellStyleInfo.Underline = IsXlsxOn(xElement2?.Element(m + "u"));
				cellStyleInfo.FontColor = text;
				cellStyleInfo.FillColor = fillColor;
				cellStyleInfo.BorderColor = borderColor;
				CellStyleInfo cellStyleInfo2 = cellStyleInfo;
				string horizontalAlignment;
				if (text3 == "center")
				{
					horizontalAlignment = "Center";
				}
				else
				{
					horizontalAlignment = ((!(text3 == "right")) ? "Left" : "Right");
				}
				cellStyleInfo2.HorizontalAlignment = horizontalAlignment;
				dictionary2[key] = cellStyleInfo;
			}
		}
		return dictionary;
	}

	private static Dictionary<int, string> ReadXlsxNumberFormats(ZipArchive zip, XNamespace m)
	{
		Dictionary<int, string> dictionary = new Dictionary<int, string>();
		ZipArchiveEntry entry = zip.GetEntry("xl/styles.xml");
		if (entry == null)
		{
			return dictionary;
		}
		using Stream stream = entry.Open();
		XElement root = XDocument.Load(stream).Root;
		if (root == null)
		{
			return dictionary;
		}
		Dictionary<int, string> dictionary2 = (root.Element(m + "numFmts")?.Elements(m + "numFmt") ?? Array.Empty<XElement>()).Where((XElement x) => int.TryParse((string?)x.Attribute("numFmtId"), out var _)).ToDictionary((XElement x) => (int)x.Attribute("numFmtId"), (XElement x) => ((string?)x.Attribute("formatCode")) ?? "");
		List<XElement> list = (root.Element(m + "cellXfs")?.Elements(m + "xf") ?? Array.Empty<XElement>()).ToList();
		for (int num = 0; num < list.Count; num++)
		{
			int valueOrDefault = ((int?)list[num].Attribute("numFmtId")).GetValueOrDefault();
			string text;
			switch (valueOrDefault)
			{
			case 3:
			case 37:
			case 38:
			case 39:
			case 40:
				text = "Thousands";
				break;
			case 1:
			case 2:
			case 4:
				text = "Number";
				break;
			case 9:
			case 10:
				text = "Percent";
				break;
			case 14:
			case 15:
			case 16:
			case 17:
			case 18:
			case 19:
			case 20:
			case 21:
			case 22:
			case 45:
			case 46:
			case 47:
				text = "Date";
				break;
			default:
			{
				text = (dictionary2.TryGetValue(valueOrDefault, out var value) ? GuessXlsxNumberFormat(value) : null);
				break;
			}
			}
			string text2 = text;
			if (text2 != null)
			{
				dictionary[num] = text2;
			}
		}
		return dictionary;
	}

	private static string? GuessXlsxNumberFormat(string format)
	{
		string text = Regex.Replace(format, "\\[[^\\]]*\\]|\"[^\"]*\"|\\\\.", "", RegexOptions.CultureInvariant);
		if (text.Contains('%'))
		{
			return "Percent";
		}
		if (Regex.IsMatch(text, "[yd]", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant) && Regex.IsMatch(text, "[m]", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant))
		{
			return "Date";
		}
		if (text.Contains('$') || text.Contains('€') || text.Contains('£') || text.Contains('¥') || text.Contains('₲'))
		{
			return "Currency";
		}
		if (text.Contains("#,##0", StringComparison.Ordinal) || text.Contains("# ##0", StringComparison.Ordinal))
		{
			if (!Regex.IsMatch(text, "0[\\.,]0+", RegexOptions.CultureInvariant))
			{
				return "Thousands";
			}
			return "Number";
		}
		if (Regex.IsMatch(text, "0\\.0+", RegexOptions.CultureInvariant))
		{
			return "Number";
		}
		return null;
	}

	private static List<string> ReadXlsxThemeColors(ZipArchive zip)
	{
		List<string> list = new List<string>
		{
			"#FFFFFF", "#000000", "#E7E6E6", "#44546A", "#4472C4", "#ED7D31", "#A5A5A5", "#FFC000", "#5B9BD5", "#70AD47",
			"#0563C1", "#954F72"
		};
		ZipArchiveEntry entry = zip.GetEntry("xl/theme/theme1.xml");
		if (entry == null)
		{
			ZipArchiveEntry entry2 = zip.GetEntry("xl/_rels/workbook.xml.rels");
			if (entry2 != null)
			{
				XNamespace xNamespace = "http://schemas.openxmlformats.org/package/2006/relationships";
				using Stream stream = entry2.Open();
				string text = (string?)(XDocument.Load(stream).Root?.Elements(xNamespace + "Relationship").FirstOrDefault((XElement x) => ((string?)x.Attribute("Type"))?.EndsWith("/theme", StringComparison.OrdinalIgnoreCase) ?? false))?.Attribute("Target");
				if (text != null)
				{
					entry = zip.GetEntry(ResolveXlsxPartPath("xl/workbook.xml", text));
				}
			}
		}
		if (entry == null)
		{
			return list;
		}
		using Stream stream2 = entry.Open();
		XDocument xDocument = XDocument.Load(stream2);
		XNamespace xNamespace2 = "http://schemas.openxmlformats.org/drawingml/2006/main";
		XElement xElement = xDocument.Descendants(xNamespace2 + "clrScheme").FirstOrDefault();
		if (xElement == null)
		{
			return list;
		}
		List<string> list2 = new List<string>();
		string[] array = new string[12]
		{
			"lt1", "dk1", "lt2", "dk2", "accent1", "accent2", "accent3", "accent4", "accent5", "accent6",
			"hlink", "folHlink"
		};
		foreach (string text2 in array)
		{
			XElement xElement2 = xElement.Element(xNamespace2 + text2)?.Elements().FirstOrDefault();
			string text3 = ((string?)xElement2?.Attribute("lastClr")) ?? ((string?)xElement2?.Attribute("val"));
			list2.Add((text3 != null && Regex.IsMatch(text3, "^[0-9A-Fa-f]{6}$")) ? ("#" + text3) : list[Math.Min(list2.Count, list.Count - 1)]);
		}
		return list2;
	}

	private static string? ResolveXlsxColor(XElement? element, IReadOnlyList<string> themeColors)
	{
		if (element == null)
		{
			return null;
		}
		string text = (string?)element.Attribute("rgb");
		string text2 = null;
		int result;
		int result2;
		if (text != null && text.Length == 6 && Regex.IsMatch(text, "^[0-9A-Fa-f]{6}$"))
		{
			text2 = "#" + text;
		}
		else if (text != null && text.Length == 8 && Regex.IsMatch(text, "^[0-9A-Fa-f]{8}$"))
		{
			text2 = "#" + text.Substring(2);
		}
		else if (int.TryParse((string?)element.Attribute("theme"), out result) && result >= 0 && result < themeColors.Count)
		{
			text2 = themeColors[result];
		}
		else if (int.TryParse((string?)element.Attribute("indexed"), out result2) && result2 >= 0 && result2 < IndexedXlsxColors.Length)
		{
			text2 = IndexedXlsxColors[result2];
		}
		else if ((string?)element.Attribute("auto") == "1")
		{
			return null;
		}
		if (text2 == null)
		{
			return null;
		}
		if (!double.TryParse((string?)element.Attribute("tint"), NumberStyles.Float, CultureInfo.InvariantCulture, out var result3) || result3 == 0.0)
		{
			return text2;
		}
		result3 = Math.Clamp(result3, -1.0, 1.0);
		int value = Convert.ToInt32(text2.Substring(1, 2), 16);
		int value2 = Convert.ToInt32(text2.Substring(3, 2), 16);
		int value3 = Convert.ToInt32(text2.Substring(5, 2), 16);
		return $"#{TintChannel(value, result3):X2}{TintChannel(value2, result3):X2}{TintChannel(value3, result3):X2}";
		static int TintChannel(int num, double amount)
		{
			return (int)Math.Round((amount < 0.0) ? ((double)num * (1.0 + amount)) : ((double)num * (1.0 - amount) + 255.0 * amount), MidpointRounding.AwayFromZero);
		}
	}

	private static bool IsXlsxOn(XElement? element)
	{
		if (element == null)
		{
			return false;
		}
		string text = (string?)element.Attribute("val");
		if (text != null && !(text == "1"))
		{
			return text.Equals("true", StringComparison.OrdinalIgnoreCase);
		}
		return true;
	}

	private void ApplyXlsxTableStyles(ZipArchive zip, XDocument worksheet, string worksheetPath, Sheet sheet, XNamespace m, IReadOnlyList<string> themeColors)
	{
		List<XElement> list = worksheet.Descendants(m + "tablePart").ToList();
		if (list.Count == 0)
		{
			return;
		}
		string text = worksheetPath.Substring(0, worksheetPath.LastIndexOf('/'));
		string text2 = worksheetPath.Substring(worksheetPath.LastIndexOf('/') + 1);
		string entryName = text + "/_rels/" + text2 + ".rels";
		ZipArchiveEntry entry = zip.GetEntry(entryName);
		if (entry == null)
		{
			return;
		}
		XNamespace xNamespace = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
		XNamespace xNamespace2 = "http://schemas.openxmlformats.org/package/2006/relationships";
		using Stream stream = entry.Open();
		Dictionary<string, string> dictionary = XDocument.Load(stream).Root?.Elements(xNamespace2 + "Relationship").Where((XElement x) => x.Attribute("Id") != null && x.Attribute("Target") != null).ToDictionary((XElement x) => (string?)x.Attribute("Id"), (XElement x) => ResolveXlsxPartPath(worksheetPath, (string?)x.Attribute("Target"))) ?? new Dictionary<string, string>();
		List<XElement> list2 = ReadXlsxDifferentialFormats(zip, m);
		Dictionary<string, List<XElement>> dictionary2 = ReadXlsxTableStyleDefinitions(zip, m);
		string text3 = ReadDefaultXlsxTableStyle(zip, m);
		foreach (XElement item3 in list)
		{
			string text4 = (string?)item3.Attribute(xNamespace + "id");
			if (text4 == null || !dictionary.TryGetValue(text4, out var value) || zip.GetEntry(value) == null)
			{
				continue;
			}
			XDocument xDocument;
			using (Stream stream2 = zip.GetEntry(value).Open())
			{
				xDocument = XDocument.Load(stream2);
			}
			XElement root = xDocument.Root;
			if (root == null || !TryParseXlsxRange((string?)root.Attribute("ref"), out (int, int, int, int) range))
			{
				continue;
			}
			XElement? xElement = root.Element(m + "tableStyleInfo");
			string text5 = ((string?)xElement?.Attribute("name")) ?? text3;
			string text6 = (string?)xElement?.Attribute("showRowStripes");
			bool flag = text6 == null || (!text6.Equals("0", StringComparison.OrdinalIgnoreCase) && !text6.Equals("false", StringComparison.OrdinalIgnoreCase));
			int num = Math.Clamp(((int?)root.Attribute("headerRowCount")) ?? 1, 0, range.Item3 - range.Item1 + 1);
			int num2 = Math.Clamp(((int?)root.Attribute("totalsRowCount")).GetValueOrDefault(), 0, range.Item3 - range.Item1 + 1 - num);
			if (dictionary2.TryGetValue(text5, out var value2) && value2.Count > 0)
			{
				Dictionary<string, XElement> dictionary3 = (from x in value2
					group x by ((string?)x.Attribute("type")) ?? "").ToDictionary((IGrouping<string, XElement> g) => g.Key, (IGrouping<string, XElement> g) => g.First());
				var (num3, _, _, _) = range;
				for (; num3 <= range.Item3; num3++)
				{
					string key;
					if (num3 < range.Item1 + num)
					{
						key = "headerRow";
					}
					else if (num2 <= 0 || num3 < range.Item3 - num2 + 1)
					{
						key = ((flag && (num3 - range.Item1 - num) % 2 == 0) ? "firstRowStripe" : "secondRowStripe");
					}
					else
					{
						key = "totalRow";
					}
					if (dictionary3.TryGetValue(key, out var value3) && int.TryParse((string?)value3.Attribute("dxfId"), out var result) && result >= 0 && result < list2.Count)
					{
						for (int num4 = range.Item2; num4 <= range.Item4; num4++)
						{
							ApplyDxfStyle(sheet, CellAddress(num3, num4), list2[result], m, themeColors);
						}
					}
				}
				continue;
			}
			(string, string, string, string, bool) tuple2 = BuiltInTablePalette(text5, themeColors);
			var (num5, _, _, _) = range;
			for (; num5 <= range.Item3; num5++)
			{
				bool flag2 = num5 < range.Item1 + num;
				bool flag3 = num2 > 0 && num5 >= range.Item3 - num2 + 1;
				object obj;
				if (flag2 | flag3)
				{
					(obj, _, _, _, _) = tuple2;
				}
				else
				{
					obj = ((flag && (num5 - range.Item1 - num) % 2 == 0) ? tuple2.Item2 : null);
				}
				string text7 = (string)obj;
				if (text7 == null && tuple2.Item4 == null && !flag2 && !flag3)
				{
					continue;
				}
				for (int num6 = range.Item2; num6 <= range.Item4; num6++)
				{
					string key2 = CellAddress(num5, num6);
					if (!sheet.CellStyles.TryGetValue(key2, out CellStyleInfo value4))
					{
						value4 = (sheet.CellStyles[key2] = new CellStyleInfo());
					}
					if (value4.FillColor == null || (!flag2 && !flag3 && IsTableStripeFill(value4.FillColor, text5)))
					{
						value4.FillColor = text7;
					}
					CellStyleInfo cellStyleInfo2 = value4;
					if (cellStyleInfo2.BorderColor == null)
					{
						string text8 = (cellStyleInfo2.BorderColor = tuple2.Item4);
					}
					if ((flag2 | flag3) && tuple2.Item5)
					{
						value4.Bold = true;
						cellStyleInfo2 = value4;
						if (cellStyleInfo2.FontColor == null)
						{
							string text8 = (cellStyleInfo2.FontColor = tuple2.Item3);
						}
					}
				}
			}
		}
	}

	private static List<XElement> ReadXlsxDifferentialFormats(ZipArchive zip, XNamespace m)
	{
		ZipArchiveEntry entry = zip.GetEntry("xl/styles.xml");
		if (entry == null)
		{
			return new List<XElement>();
		}
		using Stream stream = entry.Open();
		return XDocument.Load(stream).Root?.Element(m + "dxfs")?.Elements(m + "dxf").ToList() ?? new List<XElement>();
	}

	private static Dictionary<string, List<XElement>> ReadXlsxTableStyleDefinitions(ZipArchive zip, XNamespace m)
	{
		ZipArchiveEntry entry = zip.GetEntry("xl/styles.xml");
		if (entry == null)
		{
			return new Dictionary<string, List<XElement>>(StringComparer.OrdinalIgnoreCase);
		}
		using Stream stream = entry.Open();
		return (XDocument.Load(stream).Root?.Element(m + "tableStyles")?.Elements(m + "tableStyle") ?? Array.Empty<XElement>()).Where((XElement x) => x.Attribute("name") != null).ToDictionary((XElement x) => (string?)x.Attribute("name"), (XElement x) => x.Elements(m + "tableStyleElement").ToList(), StringComparer.OrdinalIgnoreCase);
	}

	private static string ReadDefaultXlsxTableStyle(ZipArchive zip, XNamespace m)
	{
		ZipArchiveEntry entry = zip.GetEntry("xl/styles.xml");
		if (entry == null)
		{
			return "TableStyleMedium2";
		}
		using Stream stream = entry.Open();
		return ((string?)XDocument.Load(stream).Root?.Element(m + "tableStyles")?.Attribute("defaultTableStyle")) ?? "TableStyleMedium2";
	}

	private static void ApplyDxfStyle(Sheet sheet, string address, XElement dxf, XNamespace m, IReadOnlyList<string> themeColors)
	{
		if (!sheet.CellStyles.TryGetValue(address, out CellStyleInfo value))
		{
			value = (sheet.CellStyles[address] = new CellStyleInfo());
		}
		XElement? xElement = dxf.Element(m + "font");
		XAttribute xAttribute = xElement?.Element(m + "name")?.Attribute("val");
		if (xAttribute != null)
		{
			value.FontFamily = xAttribute.Value;
		}
		if (double.TryParse((string?)xElement?.Element(m + "sz")?.Attribute("val"), NumberStyles.Float, CultureInfo.InvariantCulture, out var result))
		{
			value.FontSize = result;
		}
		XElement xElement2 = xElement?.Element(m + "b");
		if (xElement2 != null)
		{
			value.Bold = IsXlsxOn(xElement2);
		}
		XElement xElement3 = xElement?.Element(m + "i");
		if (xElement3 != null)
		{
			value.Italic = IsXlsxOn(xElement3);
		}
		XElement xElement4 = xElement?.Element(m + "u");
		if (xElement4 != null)
		{
			value.Underline = IsXlsxOn(xElement4);
		}
		XElement xElement5 = xElement?.Element(m + "color");
		if (xElement5 != null && value.FontColor == null)
		{
			value.FontColor = ResolveXlsxColor(xElement5, themeColors);
		}
		XElement xElement6 = dxf.Element(m + "fill")?.Descendants(m + "fgColor").FirstOrDefault();
		if (xElement6 != null && value.FillColor == null)
		{
			value.FillColor = ResolveXlsxColor(xElement6, themeColors);
		}
		string text = dxf.Element(m + "border")?.Elements().Select((XElement side) => ResolveXlsxColor(side.Element(m + "color"), themeColors)).FirstOrDefault((string color) => color != null);
		if (text != null && value.BorderColor == null)
		{
			value.BorderColor = text;
		}
		string text2 = (string?)dxf.Element(m + "alignment")?.Attribute("horizontal");
		if (text2 != null)
		{
			CellStyleInfo cellStyleInfo2 = value;
			string horizontalAlignment;
			if (text2 == "center")
			{
				horizontalAlignment = "Center";
			}
			else
			{
				horizontalAlignment = ((!(text2 == "right")) ? "Left" : "Right");
			}
			cellStyleInfo2.HorizontalAlignment = horizontalAlignment;
		}
	}

	private static (int top, int left, int bottom, int right) ParseXlsxRange(string text)
	{
		string[] array = text.Split(':');
		string a = array[0].Replace("$", "", StringComparison.Ordinal);
		int item = CellRow(a);
		int item2 = CellCol(a);
		string a2 = ((array.Length > 1) ? array[^1] : array[0]).Replace("$", "", StringComparison.Ordinal);
		int item3 = CellRow(a2);
		int item4 = CellCol(a2);
		return (top: item, left: item2, bottom: item3, right: item4);
	}

	private static string TranslateSharedFormula(string formula, int rowDelta, int colDelta)
	{
		StringBuilder stringBuilder = new StringBuilder(formula.Length + 16);
		bool flag = false;
		int num = 0;
		while (num < formula.Length)
		{
			if (formula[num] == '"')
			{
				stringBuilder.Append(formula[num++]);
				if (flag && num < formula.Length && formula[num] == '"')
				{
					stringBuilder.Append(formula[num++]);
				}
				else
				{
					flag = !flag;
				}
				continue;
			}
			if (!flag && (formula[num] == '$' || char.IsLetter(formula[num])) && (num == 0 || (!char.IsLetterOrDigit(formula[num - 1]) && formula[num - 1] != '_')))
			{
				Match match = Regex.Match(formula.Substring(num), "^(\\$?)([A-Z]{1,3})(\\$?)(\\d+)(?![A-Z0-9_])", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
				if (match.Success)
				{
					bool flag2 = match.Groups[1].Value.Length > 0;
					bool flag3 = match.Groups[3].Value.Length > 0;
					int num2 = ColIndex(match.Groups[2].Value);
					int num3 = int.Parse(match.Groups[4].Value) - 1;
					if (!flag2)
					{
						num2 += colDelta;
					}
					if (!flag3)
					{
						num3 += rowDelta;
					}
					stringBuilder.Append((num3 < 0 || num2 < 0) ? "#REF!" : ((flag2 ? "$" : "") + CellAddress(num3, num2).TakeWhile(char.IsLetter).Aggregate("", (string a, char c) => a + c) + (flag3 ? "$" : "") + (num3 + 1).ToString(CultureInfo.InvariantCulture)));
					num += match.Length;
					continue;
				}
			}
			stringBuilder.Append(formula[num++]);
		}
		return stringBuilder.ToString();
	}

	private static bool TryParseXlsxRange(string? text, out (int top, int left, int bottom, int right) range)
	{
		range = default;
		if (string.IsNullOrWhiteSpace(text) || !Regex.IsMatch(text, "^\\$?[A-Z]{1,3}\\$?\\d+:\\$?[A-Z]{1,3}\\$?\\d+$", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant))
		{
			return false;
		}
		range = ParseXlsxRange(text);
		if (range.top >= 0 && range.left >= 0 && range.bottom >= range.top && range.right >= range.left && range.bottom < 500)
		{
			return range.right < 26;
		}
		return false;
	}

	private static string ResolveXlsxPartPath(string ownerPart, string target)
	{
		if (target.StartsWith('/'))
		{
			return target.TrimStart('/');
		}
		IEnumerable<string> enumerable = ownerPart.Split('/').SkipLast(1).Concat(target.Replace('\\', '/').Split('/'));
		List<string> list = new List<string>();
		foreach (string item in enumerable)
		{
			if (item.Length == 0 || item == ".")
			{
				continue;
			}
			if (item == "..")
			{
				if (list.Count > 0)
				{
					list.RemoveAt(list.Count - 1);
				}
			}
			else
			{
				list.Add(item);
			}
		}
		return string.Join('/', list);
	}

	private static (string? Header, string Band, string Text, string Border, bool BoldHeader) BuiltInTablePalette(string styleName, IReadOnlyList<string> themeColors)
	{
		Match match = Regex.Match(styleName, "TableStyle(Medium|Dark|Light)(\\d+)", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
		int num = ((match.Success && int.TryParse(match.Groups[2].Value, out var result)) ? result : 2);
		string text = (match.Success ? match.Groups[1].Value : "Medium");
		int num2;
		if (!match.Success)
		{
			num2 = 9;
		}
		else if (text.Equals("Dark", StringComparison.OrdinalIgnoreCase) && num >= 8)
		{
			num2 = num switch
			{
				8 => 1, 
				9 => 5, 
				10 => 7, 
				11 => 9, 
				_ => 9, 
			};
		}
		else
		{
			int num3 = (num - 1) % 7;
			num2 = ((num3 == 0) ? 1 : (3 + num3));
		}
		string text2 = ((num2 < themeColors.Count) ? themeColors[num2] : "#70AD47");
		bool flag = text.Equals("Medium", StringComparison.OrdinalIgnoreCase) && num >= 22 && num <= 28;
		string item;
		if (text.Equals("Light", StringComparison.OrdinalIgnoreCase))
		{
			item = BlendXlsxColor(text2, "#FFFFFF", 0.82);
		}
		else
		{
			item = ((flag && num == 28) ? "#C6EFCE" : BlendXlsxColor(text2, "#FFFFFF", 0.9));
		}
		object item2;
		if (flag)
		{
			item2 = null;
		}
		else if (text.Equals("Light", StringComparison.OrdinalIgnoreCase))
		{
			item2 = BlendXlsxColor(text2, "#FFFFFF", 0.68);
		}
		else
		{
			item2 = (text.Equals("Dark", StringComparison.OrdinalIgnoreCase) ? BlendXlsxColor(text2, "#000000", 0.28) : text2);
		}
		string item3 = ((flag && num == 28) ? "#008000" : BlendXlsxColor(text2, "#000000", 0.18));
		string item4 = ((text.Equals("Light", StringComparison.OrdinalIgnoreCase) | flag) ? "#1F1F1F" : "#FFFFFF");
		return (Header: (string)item2, Band: item, Text: item4, Border: item3, BoldHeader: !flag);
	}

	private static string BlendXlsxColor(string foreground, string background, double amount)
	{
		return $"#{Channel(foreground, background, 1):X2}{Channel(foreground, background, 3):X2}{Channel(foreground, background, 5):X2}";
		int Channel(string a, string b, int offset)
		{
			return (int)Math.Round((double)Convert.ToInt32(a.Substring(offset, 2), 16) * (1.0 - amount) + (double)Convert.ToInt32(b.Substring(offset, 2), 16) * amount, MidpointRounding.AwayFromZero);
		}
	}

	private static bool IsTableStripeFill(string? fill, string styleName)
	{
		if (!styleName.Equals("TableStyleMedium28", StringComparison.OrdinalIgnoreCase))
		{
			return false;
		}
		if (string.IsNullOrWhiteSpace(fill) || !Regex.IsMatch(fill, "^#[0-9A-Fa-f]{6}$"))
		{
			return true;
		}
		int num = Convert.ToInt32(fill.Substring(1, 2), 16);
		int num2 = Convert.ToInt32(fill.Substring(3, 2), 16);
		int num3 = Convert.ToInt32(fill.Substring(5, 2), 16);
		bool num4 = num >= 248 && num2 >= 248 && num3 >= 248;
		bool flag = num2 >= num && num2 >= num3;
		return num4 | flag;
	}
}
