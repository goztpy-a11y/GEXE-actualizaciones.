using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace GOZT.Excel;

internal sealed class FormulaEngine(Func<int, int, object?> cell)
{
	private sealed class FormulaException(string code) : Exception(code)
	{
		public string Code { get; } = code;
	}

	private string source = "";

	private int position;

	private bool commaDecimal;

	public string Evaluate(string formula)
	{
		try
		{
			source = (formula.StartsWith('=') ? formula.Substring(1) : formula);
			commaDecimal = Regex.IsMatch(source, "\\b(SUMA|PROMEDIO|CONTAR|CONTARA|PRODUCTO|RAIZ|POTENCIA|RESIDUO|ENTERO|TRUNCAR|SIGNO|REDONDEAR|REDONDEAR\\.MAS|REDONDEAR\\.MENOS|SI|SI\\.ERROR|Y|O|NO|LARGO|MAYUSC|MINUSC|ESPACIOS|CONCATENAR|IZQUIERDA|DERECHA|EXTRAE|VALOR|SUMAR\\.SI|CONTAR\\.SI|HOY|AHORA|FECHA|AÑO|MES|DIA)\\s*\\(", RegexOptions.IgnoreCase);
			position = 0;
			object x = Compare();
			Space();
			if (position != source.Length)
			{
				return "#VALUE!";
			}
			return Format(x);
		}
		catch (FormulaException ex)
		{
			return ex.Code;
		}
		catch
		{
			return "#VALUE!";
		}
	}

	private object? Compare()
	{
		object obj = Concat();
		while (true)
		{
			Space();
			string text = TakeAny("<=", ">=", "<>", "=", "<", ">");
			if (text == null)
			{
				break;
			}
			object b = Concat();
			int num = CompareValues(obj, b);
			obj = text switch
			{
				"=" => num == 0, 
				"<>" => num != 0, 
				"<" => num < 0, 
				">" => num > 0, 
				"<=" => num <= 0, 
				_ => num >= 0, 
			};
		}
		return obj;
	}

	private object? Concat()
	{
		object obj = Add();
		while (Take("&"))
		{
			object x = Add();
			FormulaException ex = Error(obj);
			if (ex != null)
			{
				return ex;
			}
			FormulaException ex2 = Error(x);
			if (ex2 != null)
			{
				return ex2;
			}
			obj = Text(obj) + Text(x);
		}
		return obj;
	}

	private object? Add()
	{
		object obj = Multiply();
		while (true)
		{
			if (Take("+"))
			{
				object b = Multiply();
				obj = Numeric(obj, b, (double x, double y) => x + y);
				continue;
			}
			if (!Take("-"))
			{
				break;
			}
			object b2 = Multiply();
			obj = Numeric(obj, b2, (double x, double y) => x - y);
		}
		return obj;
	}

	private object? Multiply()
	{
		object obj = Power();
		while (true)
		{
			if (Take("*"))
			{
				object b = Power();
				obj = Numeric(obj, b, (double x, double y) => x * y);
				continue;
			}
			if (!Take("/"))
			{
				break;
			}
			object b2 = Power();
			obj = Numeric(obj, b2, (double x, double y) => (y != 0.0) ? ((object)(x / y)) : new FormulaException("#DIV/0!"));
		}
		return obj;
	}

	private object? Power()
	{
		object obj = Unary();
		if (Take("^"))
		{
			object b = Power();
			return Numeric(obj, b, (double x, double y) => Math.Pow(x, y));
		}
		return obj;
	}

	private object? Unary()
	{
		if (Take("+"))
		{
			return Unary();
		}
		if (Take("-"))
		{
			object x = Unary();
			FormulaException ex = Error(x);
			if (ex != null)
			{
				return ex;
			}
			return 0.0 - Number(x);
		}
		object obj = Primary();
		while (Take("%"))
		{
			FormulaException ex2 = Error(obj);
			if (ex2 != null)
			{
				return ex2;
			}
			obj = Number(obj) / 100.0;
		}
		return obj;
	}

	private object? Primary()
	{
		Space();
		if (Take("("))
		{
			object? result = Compare();
			if (!Take(")"))
			{
				throw new FormulaException("#VALUE!");
			}
			return result;
		}
		if (position >= source.Length)
		{
			throw new FormulaException("#VALUE!");
		}
		if (source[position] == '"')
		{
			return ReadString();
		}
		if (char.IsDigit(source[position]) || source[position] == '.')
		{
			return ReadNumber();
		}
		string text = ReadIdentifier();
		if (text.Length == 0)
		{
			throw new FormulaException("#VALUE!");
		}
		Space();
		if (Take("("))
		{
			return Function(text.ToUpperInvariant(), Arguments());
		}
		if (text.Equals("TRUE", StringComparison.OrdinalIgnoreCase))
		{
			return true;
		}
		if (text.Equals("FALSE", StringComparison.OrdinalIgnoreCase))
		{
			return false;
		}
		if (!TryCell(text, out var row, out var col))
		{
			throw new FormulaException("#NAME?");
		}
		object result2 = cell(row, col);
		Space();
		if (Take(":"))
		{
			Space();
			if (!TryCell(ReadIdentifier(), out var row2, out var col2))
			{
				throw new FormulaException("#REF!");
			}
			int num = Math.Min(row, row2);
			int num2 = Math.Max(row, row2);
			int num3 = Math.Min(col, col2);
			int num4 = Math.Max(col, col2);
			if ((long)(num2 - num + 1) * (long)(num4 - num3 + 1) > 10000)
			{
				throw new FormulaException("#REF!");
			}
			List<object> list = new List<object>();
			for (int i = num; i <= num2; i++)
			{
				for (int j = num3; j <= num4; j++)
				{
					list.Add(cell(i, j));
				}
			}
			return list;
		}
		return result2;
	}

	private List<object?> Arguments()
	{
		List<object> list = new List<object>();
		Space();
		if (Take(")"))
		{
			return list;
		}
		do
		{
			list.Add(Compare());
			Space();
			if (Take(")"))
			{
				return list;
			}
		}
		while (Take(",") || Take(";"));
		throw new FormulaException("#VALUE!");
	}

	private object? Function(string name, List<object?> args)
	{
		name = name switch
		{
			"SUMA" => "SUM", 
			"PROMEDIO" => "AVERAGE", 
			"CONTAR" => "COUNT", 
			"CONTARA" => "COUNTA", 
			"PRODUCTO" => "PRODUCT", 
			"RAIZ" => "SQRT", 
			"POTENCIA" => "POWER", 
			"RESIDUO" => "MOD", 
			"ENTERO" => "INT", 
			"TRUNCAR" => "TRUNC", 
			"SIGNO" => "SIGN", 
			"REDONDEAR" => "ROUND", 
			"REDONDEAR.MAS" => "ROUNDUP", 
			"REDONDEAR.MENOS" => "ROUNDDOWN", 
			"SI" => "IF", 
			"SI.ERROR" => "IFERROR", 
			"Y" => "AND", 
			"O" => "OR", 
			"NO" => "NOT", 
			"LARGO" => "LEN", 
			"MAYUSC" => "UPPER", 
			"MINUSC" => "LOWER", 
			"ESPACIOS" => "TRIM", 
			"CONCATENAR" => "CONCATENATE", 
			"IZQUIERDA" => "LEFT", 
			"DERECHA" => "RIGHT", 
			"EXTRAE" => "MID", 
			"VALOR" => "VALUE", 
			"SUMAR.SI" => "SUMIF", 
			"CONTAR.SI" => "COUNTIF", 
			"HOY" => "TODAY", 
			"AHORA" => "NOW", 
			"FECHA" => "DATE", 
			"AÑO" => "YEAR", 
			"MES" => "MONTH", 
			"DIA" => "DAY", 
			_ => name, 
		};
		List<object> list = (from x in args.SelectMany(Flatten)
			where x != null
			select x).ToList();
		List<double> list2 = list.Where(IsNumber).Select(Number).ToList();
		if (!(name == "IF") && !(name == "IFERROR"))
		{
			FormulaException ex = list.Select(Error).FirstOrDefault((FormulaException x) => x != null);
			if (ex != null)
			{
				return ex;
			}
		}
		switch (name)
		{
		case "SUM":
			return list2.Sum();
		case "AVERAGE":
			return (list2.Count == 0) ? new FormulaException("#DIV/0!") : ((object)list2.Average());
		case "MIN":
			return (list2.Count == 0) ? 0.0 : list2.Min();
		case "MAX":
			return (list2.Count == 0) ? 0.0 : list2.Max();
		case "COUNT":
			return list2.Count;
		case "COUNTA":
			return Enumerable.Count(list, (object x) => Text(x).Length > 0);
		case "PRODUCT":
			return list2.Aggregate(1.0, (double a, double b) => a * b);
		case "ABS":
			return Math.Abs(N(0));
		case "SQRT":
			return (N(0) < 0.0) ? new FormulaException("#NUM!") : ((object)Math.Sqrt(N(0)));
		case "POWER":
			return Math.Pow(N(0), N(1));
		case "MOD":
			return (N(1) == 0.0) ? new FormulaException("#DIV/0!") : ((object)(N(0) - N(1) * Math.Floor(N(0) / N(1))));
		case "INT":
			return Math.Floor(N(0));
		case "TRUNC":
			return Math.Truncate(N(0));
		case "SIGN":
			return Math.Sign(N(0));
		case "ROUND":
			return Math.Round(N(0), Digits(1), MidpointRounding.AwayFromZero);
		case "ROUNDUP":
			return RoundDirection(N(0), Digits(1), up: true);
		case "ROUNDDOWN":
			return RoundDirection(N(0), Digits(1), up: false);
		case "IF":
		{
			object? result;
			if (B(0))
			{
				result = Arg(1);
			}
			else
			{
				result = ((args.Count > 2) ? Arg(2) : ((object)false));
			}
			return result;
		}
		case "IFERROR":
		{
			object? result2;
			if (Error(Arg(0)) == null)
			{
				result2 = Arg(0);
			}
			else
			{
				result2 = ((args.Count > 1) ? Arg(1) : "");
			}
			return result2;
		}
		case "AND":
			return list.All(Truth);
		case "OR":
			return list.Any(Truth);
		case "NOT":
			return !B(0);
		case "LEN":
			return S(0).Length;
		case "UPPER":
			return S(0).ToUpperInvariant();
		case "LOWER":
			return S(0).ToLowerInvariant();
		case "TRIM":
			return Regex.Replace(S(0).Trim(), "\\s+", " ");
		case "CONCAT":
		case "CONCATENATE":
			return string.Concat(list.Select(Text));
		case "LEFT":
			return S(0).Substring(0, Math.Clamp((args.Count <= 1) ? 1 : ((int)N(1)), 0, S(0).Length));
		case "RIGHT":
			return S(0).Substring(S(0).Length - Math.Clamp((args.Count <= 1) ? 1 : ((int)N(1)), 0, S(0).Length));
		case "MID":
			return Mid(S(0), (int)N(1), (int)N(2));
		case "VALUE":
			return Number(S(0));
		case "SUMIF":
			return ConditionalSum(args, countOnly: false);
		case "COUNTIF":
			return ConditionalSum(args, countOnly: true);
		case "TODAY":
			return DateTime.Today.ToOADate();
		case "NOW":
			return DateTime.Now.ToOADate();
		case "DATE":
			return new DateTime((int)N(0), (int)N(1), (int)N(2)).ToOADate();
		case "YEAR":
			return DatePart(N(0), (DateTime d) => d.Year);
		case "MONTH":
			return DatePart(N(0), (DateTime d) => d.Month);
		case "DAY":
			return DatePart(N(0), (DateTime d) => d.Day);
		default:
			return new FormulaException("#NAME?");
		}
		object? Arg(int i)
		{
			if (i >= args.Count)
			{
				return new FormulaException("#VALUE!");
			}
			return args[i];
		}
		bool B(int i)
		{
			return Truth(Arg(i));
		}
		int Digits(int i)
		{
			if (i >= args.Count)
			{
				return 0;
			}
			return (int)Math.Clamp(N(i), -15.0, 15.0);
		}
		double N(int i)
		{
			return Number(Arg(i));
		}
		string S(int i)
		{
			return Text(Arg(i));
		}
	}

	private object ConditionalSum(List<object?> args, bool countOnly)
	{
		if (args.Count < 2 || !(args[0] is List<object> list))
		{
			return new FormulaException("#VALUE!");
		}
		List<object> list2 = ((args.Count > 2 && args[2] is List<object> list3) ? list3 : list);
		string criteria = Text(args[1]);
		int num = Math.Min(list.Count, list2.Count);
		double num2 = 0.0;
		int num3 = 0;
		for (int i = 0; i < num; i++)
		{
			if (Matches(list[i], criteria))
			{
				num3++;
				if (IsNumber(list2[i]))
				{
					num2 += Number(list2[i]);
				}
			}
		}
		return countOnly ? ((double)num3) : num2;
	}

	private static bool Matches(object? value, string criteria)
	{
		Match match = Regex.Match(criteria, "^(>=|<=|<>|>|<|=)?(.*)$");
		string value2 = match.Groups[1].Value;
		string value3 = match.Groups[2].Value;
		if (IsNumber(value) && double.TryParse(value3, NumberStyles.Any, CultureInfo.InvariantCulture, out var result))
		{
			int num = Number(value).CompareTo(result);
			return value2 switch
			{
				">" => num > 0, 
				">=" => num >= 0, 
				"<" => num < 0, 
				"<=" => num <= 0, 
				"<>" => num != 0, 
				_ => num == 0, 
			};
		}
		int num2 = string.Compare(Text(value), value3, StringComparison.CurrentCultureIgnoreCase);
		return value2 switch
		{
			"<>" => num2 != 0, 
			">" => num2 > 0, 
			">=" => num2 >= 0, 
			"<" => num2 < 0, 
			"<=" => num2 <= 0, 
			_ => num2 == 0, 
		};
	}

	private static object Mid(string text, int start, int length)
	{
		int num = Math.Max(0, start - 1);
		if (num >= text.Length || length <= 0)
		{
			return "";
		}
		return text.Substring(num, Math.Min(length, text.Length - num));
	}

	private static object DatePart(double serial, Func<DateTime, int> part)
	{
		try
		{
			return part(DateTime.FromOADate(serial));
		}
		catch
		{
			return new FormulaException("#NUM!");
		}
	}

	private static double RoundDirection(double n, int digits, bool up)
	{
		double num = Math.Pow(10.0, Math.Clamp(digits, -15, 15));
		if (digits < 0)
		{
			return (up ? (Math.Ceiling(Math.Abs(n) / num) * (double)Math.Sign(n)) : Math.Truncate(n / num)) * num;
		}
		return (up ? (Math.Ceiling(Math.Abs(n) * num) * (double)Math.Sign(n)) : Math.Truncate(n * num)) / num;
	}

	private string ReadString()
	{
		position++;
		StringBuilder stringBuilder = new StringBuilder();
		while (position < source.Length)
		{
			if (source[position++] == '"')
			{
				if (position >= source.Length || source[position] != '"')
				{
					return stringBuilder.ToString();
				}
				stringBuilder.Append('"');
				position++;
			}
			else
			{
				stringBuilder.Append(source[position - 1]);
			}
		}
		throw new FormulaException("#VALUE!");
	}

	private object ReadNumber()
	{
		int num = position;
		while (position < source.Length && (char.IsDigit(source[position]) || source[position] == '.' || (commaDecimal && source[position] == ',' && position + 1 < source.Length && char.IsDigit(source[position + 1])) || source[position] == 'E' || source[position] == 'e' || (position > num && (source[position] == '+' || source[position] == '-') && (source[position - 1] == 'E' || source[position - 1] == 'e'))))
		{
			position++;
		}
		string text = source;
		int num2 = num;
		string text2 = text.Substring(num2, position - num2);
		if (commaDecimal)
		{
			text2 = text2.Replace(',', '.');
		}
		if (!double.TryParse(text2, NumberStyles.Float, CultureInfo.InvariantCulture, out var result))
		{
			throw new FormulaException("#VALUE!");
		}
		return result;
	}

	private string ReadIdentifier()
	{
		Space();
		int num = position;
		if (position < source.Length && source[position] == '$')
		{
			position++;
		}
		while (true)
		{
			bool flag = position < source.Length;
			if (flag)
			{
				bool flag2 = char.IsLetterOrDigit(source[position]);
				if (!flag2)
				{
					char c = source[position];
					bool flag3 = ((c == '$' || c == '.' || c == '_') ? true : false);
					flag2 = flag3;
				}
				flag = flag2;
			}
			if (!flag)
			{
				break;
			}
			position++;
		}
		string text = source;
		int num2 = num;
		return text.Substring(num2, position - num2);
	}

	private void Space()
	{
		while (position < source.Length && char.IsWhiteSpace(source[position]))
		{
			position++;
		}
	}

	private bool Take(string token)
	{
		Space();
		if (!source.AsSpan(position).StartsWith(token, StringComparison.OrdinalIgnoreCase))
		{
			return false;
		}
		position += token.Length;
		return true;
	}

	private string? TakeAny(params string[] tokens)
	{
		foreach (string text in tokens)
		{
			if (Take(text))
			{
				return text;
			}
		}
		return null;
	}

	private static bool TryCell(string address, out int row, out int col)
	{
		Match match = Regex.Match(address, "^\\$?([A-Z]{1,3})\\$?(\\d+)$", RegexOptions.IgnoreCase);
		row = (col = 0);
		if (!match.Success)
		{
			return false;
		}
		col = 0;
		string text = match.Groups[1].Value.ToUpperInvariant();
		foreach (char c in text)
		{
			col = col * 26 + c - 65 + 1;
		}
		col--;
		if (!int.TryParse(match.Groups[2].Value, out row))
		{
			return false;
		}
		row--;
		if (row >= 0)
		{
			return col >= 0;
		}
		return false;
	}

	private static IEnumerable<object?> Flatten(object? x)
	{
		if (!(x is List<object> list))
		{
			return new _003C_003Ez__ReadOnlySingleElementList<object>(x);
		}
		return list.SelectMany(Flatten);
	}

	private static object? Numeric(object? a, object? b, Func<double, double, object?> f)
	{
		FormulaException ex = Error(a);
		if (ex != null)
		{
			return ex;
		}
		FormulaException ex2 = Error(b);
		if (ex2 != null)
		{
			return ex2;
		}
		try
		{
			object obj = f(Number(a), Number(b));
			return (obj is double d && (double.IsNaN(d) || double.IsInfinity(d))) ? new FormulaException("#NUM!") : obj;
		}
		catch (FormulaException result)
		{
			return result;
		}
	}

	private static bool IsNumber(object? x)
	{
		if ((!(x is double) && !(x is int) && !(x is long) && !(x is decimal) && !(x is bool)) || 1 == 0)
		{
			if (x is string s)
			{
				double result;
				return double.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out result);
			}
			return false;
		}
		return true;
	}

	private static double Number(object? x)
	{
		if (x is FormulaException ex)
		{
			throw ex;
		}
		if (x is bool flag)
		{
			return flag ? 1 : 0;
		}
		if (x == null || x is string { Length: 0 })
		{
			return 0.0;
		}
		if (x is string text2 && text2.StartsWith('#'))
		{
			throw new FormulaException(text2);
		}
		try
		{
			return Convert.ToDouble(x, CultureInfo.InvariantCulture);
		}
		catch
		{
			throw new FormulaException("#VALUE!");
		}
	}

	private static string Text(object? x)
	{
		if (x != null)
		{
			if (!(x is FormulaException ex))
			{
				if (!(x is bool))
				{
					if (x is double d)
					{
						return FormatNumber(d);
					}
					return Convert.ToString(x, CultureInfo.InvariantCulture) ?? "";
				}
				return ((bool)x) ? "TRUE" : "FALSE";
			}
			return ex.Code;
		}
		return "";
	}

	private static bool Truth(object? x)
	{
		if (!(x is bool result))
		{
			if (x is string text)
			{
				return text.Length > 0 && !text.Equals("FALSE", StringComparison.OrdinalIgnoreCase);
			}
			return Number(x) != 0.0;
		}
		return result;
	}

	private static int CompareValues(object? a, object? b)
	{
		if (IsNumber(a) && IsNumber(b))
		{
			return Number(a).CompareTo(Number(b));
		}
		return string.Compare(Text(a), Text(b), StringComparison.CurrentCultureIgnoreCase);
	}

	private static FormulaException? Error(object? x)
	{
		object obj = x as FormulaException;
		if (obj == null)
		{
			if (!(x is string text) || !text.StartsWith('#'))
			{
				return null;
			}
			obj = new FormulaException(text);
		}
		return (FormulaException?)obj;
	}

	private static string Format(object? x)
	{
		if (!(x is FormulaException ex))
		{
			return Text(x);
		}
		return ex.Code;
	}

	private static string FormatNumber(double d)
	{
		return d.ToString("G15", CultureInfo.InvariantCulture);
	}
}
