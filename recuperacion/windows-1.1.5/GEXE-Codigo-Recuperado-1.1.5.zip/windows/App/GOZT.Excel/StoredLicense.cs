using System;

namespace GOZT.Excel;

internal sealed class StoredLicense
{
	public string Key { get; set; } = "";

	public string InstanceId { get; set; } = "";

	public long LicenseId { get; set; }

	public long ProductId { get; set; }

	public long StoreId { get; set; }

	public long VariantId { get; set; }

	public int LicensedMajor { get; set; }

	public string DeviceHash { get; set; } = "";

	public bool Verified { get; set; }

	public int SeatsUsed { get; set; }

	public DateTimeOffset LastVerified { get; set; }

	public DateTimeOffset? ExpiresAtUtc { get; set; }
}
