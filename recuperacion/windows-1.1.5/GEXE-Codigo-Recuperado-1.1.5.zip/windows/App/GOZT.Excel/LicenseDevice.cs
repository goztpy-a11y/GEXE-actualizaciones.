using System;
using System.IO;
using System.Security;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Win32;

namespace GOZT.Excel;

internal static class LicenseDevice
{
	internal static string Fingerprint(string dataDirectory)
	{
		string text = null;
		try
		{
			using RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
			using RegistryKey registryKey2 = registryKey.OpenSubKey("SOFTWARE\\Microsoft\\Cryptography", writable: false);
			text = registryKey2?.GetValue("MachineGuid") as string;
		}
		catch (SecurityException)
		{
		}
		catch (UnauthorizedAccessException)
		{
		}
		if (string.IsNullOrWhiteSpace(text))
		{
			Directory.CreateDirectory(dataDirectory);
			string path = Path.Combine(dataDirectory, "license-device-id.txt");
			if (!File.Exists(path))
			{
				File.WriteAllText(path, Guid.NewGuid().ToString("N"));
			}
			text = File.ReadAllText(path);
		}
		return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes("GEXE/" + text.Trim())));
	}
}
