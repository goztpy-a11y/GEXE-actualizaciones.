using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace GOZT.Excel;

internal sealed class LicenseService(HttpClient http, ILicenseStorage storage, LicenseProductPolicy policy, string deviceHash, int applicationMajor, bool allowTestProduct = false)
{
	private readonly SemaphoreSlim gate = new SemaphoreSlim(1, 1);

	private bool serverRejected;

	internal bool IsConfigured
	{
		get
		{
			if (policy.IsConfigured)
			{
				if (policy.IsTestProduct)
				{
					return allowTestProduct;
				}
				return true;
			}
			return false;
		}
	}

	internal bool IsTestProduct => policy.IsTestProduct;

	internal bool HasSavedLicense => storage.Load() != null;

	private void RequirePolicy()
	{
		if (policy.IsTestProduct && !allowTestProduct)
		{
			throw new LicenseException("Los cobros todavía están en modo de prueba. Las claves de prueba no habilitan un plan de pago en esta versión pública.");
		}
		if (!policy.IsConfigured)
		{
			throw new LicenseException("La activación está preparada, pero falta identificar el producto de GEXE. Consultá a soporte.");
		}
		if (applicationMajor != policy.LicensedMajor)
		{
			throw new LicenseException("Esta clave corresponde a otra versión principal de GEXE.");
		}
	}

	private bool MatchesProduct(long product, long store, long variant)
	{
		if ((policy.ProductId <= 0 || product == policy.ProductId) && (!policy.StoreId.HasValue || store == policy.StoreId.Value))
		{
			if (policy.VariantIds.Length + policy.MonthlyVariantIds.Length != 0 && !policy.VariantIds.Contains(variant))
			{
				return policy.MonthlyVariantIds.Contains(variant);
			}
			return true;
		}
		return false;
	}

	private bool TrustedCache(StoredLicense state)
	{
		if (!serverRejected && IsConfigured && state.Verified && MatchesProduct(state.ProductId, state.StoreId, state.VariantId) && state.LicensedMajor == policy.LicensedMajor && state.LicensedMajor == applicationMajor && state.DeviceHash == deviceHash && state.Key.Length > 0 && state.InstanceId.Length > 0 && state.LicenseId > 0)
		{
			if (IsMonthly(state.VariantId))
			{
				if (state.LastVerified <= DateTimeOffset.UtcNow.AddMinutes(2.0))
				{
					return DateTimeOffset.UtcNow < OfflineUntil(state);
				}
				return false;
			}
			return true;
		}
		return false;
	}

	private bool IsMonthly(long variant)
	{
		return policy.MonthlyVariantIds.Contains(variant);
	}

	private static DateTimeOffset OfflineUntil(StoredLicense state)
	{
		DateTimeOffset dateTimeOffset = state.LastVerified.AddHours(24.0);
		DateTimeOffset? expiresAtUtc = state.ExpiresAtUtc;
		if (expiresAtUtc.HasValue)
		{
			DateTimeOffset valueOrDefault = expiresAtUtc.GetValueOrDefault();
			if (valueOrDefault < dateTimeOffset)
			{
				return valueOrDefault;
			}
		}
		return dateTimeOffset;
	}

	private LicenseView ActiveView(StoredLicense state, bool offline = false)
	{
		string message;
		if (IsMonthly(state.VariantId))
		{
			message = (offline ? "Mensual · verificación pendiente; conectá Internet en un plazo de 24 horas" : "Mensual activo · suscripción comprobada");
		}
		else
		{
			message = (offline ? "Pago único activo · sin conexión de verificación" : ("Pago único activo · licencia sin vencimiento para GEXE " + applicationMajor + ".x"));
		}
		return new LicenseView(IsActive: true, message, state.SeatsUsed, offline, IsMonthly(state.VariantId) ? "personal" : "one_time", IsMonthly(state.VariantId) ? new DateTimeOffset?(OfflineUntil(state)) : ((DateTimeOffset?)null));
	}

	internal LicenseView ReadLocal()
	{
		StoredLicense storedLicense = storage.Load();
		if (storedLicense == null || !TrustedCache(storedLicense))
		{
			return new LicenseView(IsActive: false, "Sin licencia activa · ingresá o comprobá tu clave");
		}
		return ActiveView(storedLicense, offline: true);
	}

	private static DateTimeOffset? Expiry(JsonElement root)
	{
		JsonElement property = root.GetProperty("license_key").GetProperty("expires_at");
		if (property.ValueKind != JsonValueKind.Null)
		{
			return property.GetDateTimeOffset();
		}
		return null;
	}

	private async Task<JsonDocument> Post(string operation, Dictionary<string, string> fields, CancellationToken ct)
	{
		using HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, "https://api.lemonsqueezy.com/v1/licenses/" + operation);
		request.Headers.Accept.ParseAdd("application/json");
		request.Content = new FormUrlEncodedContent(fields);
		using HttpResponseMessage response = await http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct);
		if (response.StatusCode == HttpStatusCode.TooManyRequests || response.StatusCode >= HttpStatusCode.InternalServerError)
		{
			throw new HttpRequestException("No se pudo consultar la licencia en este momento.");
		}
		bool flag = !response.IsSuccessStatusCode;
		if (flag)
		{
			int statusCode = (int)response.StatusCode;
			bool flag2 = ((statusCode == 400 || statusCode == 404 || statusCode == 422) ? true : false);
			flag = !flag2;
		}
		if (flag)
		{
			throw new HttpRequestException("No se pudo consultar la licencia en este momento.");
		}
		using Stream input = await response.Content.ReadAsStreamAsync(ct);
		using MemoryStream memory = new MemoryStream();
		byte[] buffer = new byte[4096];
		int num;
		while ((num = await input.ReadAsync(buffer, ct)) > 0)
		{
			if (memory.Length + num > 65536)
			{
				throw new InvalidDataException("La respuesta de licencia no es válida.");
			}
			memory.Write(buffer, 0, num);
		}
		return JsonDocument.Parse(memory.ToArray());
	}

	private static bool Flag(JsonElement root, string name)
	{
		if (root.TryGetProperty(name, out var value))
		{
			return value.ValueKind == JsonValueKind.True;
		}
		return false;
	}

	private void VerifyDetails(JsonElement root, string key, string? instanceId, bool allowInactive)
	{
		JsonElement property = root.GetProperty("license_key");
		JsonElement property2 = root.GetProperty("meta");
		if (!MatchesProduct(property2.GetProperty("product_id").GetInt64(), property2.GetProperty("store_id").GetInt64(), property2.GetProperty("variant_id").GetInt64()))
		{
			throw new LicenseException("La clave no corresponde a un plan autorizado de GEXE.");
		}
		if (property.GetProperty("key").GetString() != key || property.GetProperty("id").GetInt64() <= 0)
		{
			throw new LicenseException("No se pudo confirmar la clave ingresada.");
		}
		string text = property.GetProperty("status").GetString() ?? "";
		if (text != "active" && (!allowInactive || !(text == "inactive")))
		{
			throw new LicenseException("La licencia está vencida, deshabilitada o no es válida.");
		}
		if (!IsMonthly(property2.GetProperty("variant_id").GetInt64()) && property.GetProperty("expires_at").ValueKind != JsonValueKind.Null)
		{
			throw new LicenseException("La clave no corresponde a la licencia sin vencimiento de este producto.");
		}
		if (IsMonthly(property2.GetProperty("variant_id").GetInt64()))
		{
			DateTimeOffset? dateTimeOffset = Expiry(root);
			if (dateTimeOffset.HasValue)
			{
				DateTimeOffset valueOrDefault = dateTimeOffset.GetValueOrDefault();
				if (valueOrDefault <= DateTimeOffset.UtcNow)
				{
					throw new LicenseException("La suscripción mensual venció. Renová el plan y comprobá tu licencia.");
				}
			}
		}
		if (property.GetProperty("activation_limit").GetInt32() != 3)
		{
			throw new LicenseException("La licencia debe estar configurada para tres computadoras. Consultá a soporte.");
		}
		int @int = property.GetProperty("activation_usage").GetInt32();
		if (@int < 0 || @int > 3)
		{
			throw new LicenseException("La licencia superó el límite de tres computadoras.");
		}
		if (instanceId != null && (!root.TryGetProperty("instance", out var value) || value.ValueKind != JsonValueKind.Object || value.GetProperty("id").GetString() != instanceId))
		{
			throw new LicenseException("La licencia no está activada para esta instalación.");
		}
	}

	private static LicenseException Rejected(JsonElement root)
	{
		JsonElement value;
		return new LicenseException(((root.TryGetProperty("error", out value) && value.ValueKind == JsonValueKind.String) ? (value.GetString() ?? "") : "").Contains("activation limit", StringComparison.OrdinalIgnoreCase) ? "La clave ya está activada en tres computadoras. Quitá la licencia de una de ellas para usarla aquí." : "La clave no es válida, está deshabilitada o ya no está activa. Revisala o consultá a soporte.");
	}

	internal async Task<LicenseView> ActivateAsync(string key, CancellationToken ct)
	{
		await gate.WaitAsync(ct);
		try
		{
			RequirePolicy();
			key = key.Trim();
			int length = key.Length;
			if ((length < 8 || length > 256) ? true : false)
			{
				throw new LicenseException("Pegá la clave de licencia recibida con tu compra.");
			}
			StoredLicense storedLicense = storage.Load();
			if (storedLicense != null)
			{
				if (storedLicense.DeviceHash != deviceHash)
				{
					throw new LicenseException("La activación guardada corresponde a otra computadora.");
				}
				if (storedLicense.Key != key)
				{
					throw new LicenseException("Primero quitá la licencia actual de este equipo para activar otra clave.");
				}
				return await RefreshCore(storedLicense, ct);
			}
			using (JsonDocument jsonDocument = await Post("validate", new Dictionary<string, string> { { "license_key", key } }, ct))
			{
				if (!Flag(jsonDocument.RootElement, "valid"))
				{
					throw Rejected(jsonDocument.RootElement);
				}
				VerifyDetails(jsonDocument.RootElement, key, null, allowInactive: true);
			}
			using JsonDocument response = await Post("activate", new Dictionary<string, string>
			{
				{ "license_key", key },
				{
					"instance_name",
					"GEXE Windows · " + deviceHash.Substring(0, Math.Min(12, deviceHash.Length))
				}
			}, ct);
			JsonElement rootElement = response.RootElement;
			if (!Flag(rootElement, "activated"))
			{
				throw Rejected(rootElement);
			}
			string text = rootElement.GetProperty("instance").GetProperty("id").GetString() ?? "";
			length = text.Length;
			if ((length < 1 || length > 128) ? true : false)
			{
				throw new LicenseException("No se recibió una activación válida para esta computadora.");
			}
			try
			{
				VerifyDetails(rootElement, key, text, allowInactive: false);
				JsonElement property = rootElement.GetProperty("license_key");
				StoredLicense storedLicense2 = new StoredLicense
				{
					Key = key,
					InstanceId = text,
					LicenseId = property.GetProperty("id").GetInt64(),
					ProductId = rootElement.GetProperty("meta").GetProperty("product_id").GetInt64(),
					StoreId = rootElement.GetProperty("meta").GetProperty("store_id").GetInt64(),
					VariantId = rootElement.GetProperty("meta").GetProperty("variant_id").GetInt64(),
					LicensedMajor = policy.LicensedMajor,
					DeviceHash = deviceHash,
					Verified = true,
					SeatsUsed = property.GetProperty("activation_usage").GetInt32(),
					LastVerified = DateTimeOffset.UtcNow,
					ExpiresAtUtc = Expiry(rootElement)
				};
				storage.Save(storedLicense2);
				return ActiveView(storedLicense2);
			}
			catch
			{
				try
				{
					using CancellationTokenSource rollback = new CancellationTokenSource(TimeSpan.FromSeconds(5L));
					using (await Post("deactivate", new Dictionary<string, string>
					{
						{ "license_key", key },
						{ "instance_id", text }
					}, rollback.Token))
					{
					}
				}
				catch
				{
				}
				throw;
			}
		}
		finally
		{
			gate.Release();
		}
	}

	internal async Task<LicenseView> RefreshAsync(CancellationToken ct)
	{
		await gate.WaitAsync(ct);
		try
		{
			StoredLicense storedLicense = storage.Load();
			if (storedLicense == null)
			{
				return new LicenseView(IsActive: false, "Gratis · sin licencia activa en esta computadora");
			}
			RequirePolicy();
			return await RefreshCore(storedLicense, ct);
		}
		finally
		{
			gate.Release();
		}
	}

	private async Task<LicenseView> RefreshCore(StoredLicense state, CancellationToken ct)
	{
		if (!MatchesProduct(state.ProductId, state.StoreId, state.VariantId) || state.LicensedMajor != applicationMajor || state.DeviceHash != deviceHash)
		{
			return new LicenseView(IsActive: false, "La activación guardada no corresponde a esta computadora o versión.");
		}
		try
		{
			using JsonDocument jsonDocument = await Post("validate", new Dictionary<string, string>
			{
				{ "license_key", state.Key },
				{ "instance_id", state.InstanceId }
			}, ct);
			JsonElement rootElement = jsonDocument.RootElement;
			if (!Flag(rootElement, "valid"))
			{
				throw Rejected(rootElement);
			}
			VerifyDetails(rootElement, state.Key, state.InstanceId, allowInactive: false);
			if (rootElement.GetProperty("license_key").GetProperty("id").GetInt64() != state.LicenseId)
			{
				throw new LicenseException("No coincide la activación guardada.");
			}
			serverRejected = false;
			state.Verified = true;
			state.SeatsUsed = rootElement.GetProperty("license_key").GetProperty("activation_usage").GetInt32();
			state.LastVerified = DateTimeOffset.UtcNow;
			state.ExpiresAtUtc = Expiry(rootElement);
			storage.Save(state);
			return ActiveView(state);
		}
		catch (LicenseException ex)
		{
			serverRejected = true;
			state.Verified = false;
			try
			{
				storage.Save(state);
			}
			catch (IOException)
			{
			}
			catch (CryptographicException)
			{
			}
			return new LicenseView(IsActive: false, ex.Message);
		}
		catch (Exception ex4) when ((ex4 is HttpRequestException || ex4 is OperationCanceledException || ex4 is JsonException || ex4 is InvalidDataException) ? true : false)
		{
			return TrustedCache(state) ? ActiveView(state, offline: true) : new LicenseView(IsActive: false, "No se pudo comprobar la licencia. Volvé a intentar con conexión a Internet.");
		}
	}

	internal async Task<LicenseView> DeactivateAsync(CancellationToken ct)
	{
		await gate.WaitAsync(ct);
		try
		{
			StoredLicense state = storage.Load();
			if (state == null)
			{
				return new LicenseView(IsActive: false, "Gratis · sin licencia activa en esta computadora");
			}
			if (state.DeviceHash != deviceHash)
			{
				throw new LicenseException("La activación guardada corresponde a otra computadora.");
			}
			using JsonDocument response = await Post("deactivate", new Dictionary<string, string>
			{
				{ "license_key", state.Key },
				{ "instance_id", state.InstanceId }
			}, ct);
			if (!Flag(response.RootElement, "deactivated"))
			{
				using JsonDocument jsonDocument = await Post("validate", new Dictionary<string, string>
				{
					{ "license_key", state.Key },
					{ "instance_id", state.InstanceId }
				}, ct);
				if (Flag(jsonDocument.RootElement, "valid"))
				{
					throw new LicenseException("No se pudo liberar la activación. Volvé a intentarlo.");
				}
			}
			storage.Clear();
			return new LicenseView(IsActive: false, "Licencia quitada de este equipo. Tus libros se conservan.");
		}
		finally
		{
			gate.Release();
		}
	}
}
