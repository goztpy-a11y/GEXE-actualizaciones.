using System.Windows;

namespace GOZT.Excel;

public partial class App : Application
{
}
