namespace GOZT.Excel;

internal sealed record AppUpdate(string Version, string DownloadUrl, string Notes);
