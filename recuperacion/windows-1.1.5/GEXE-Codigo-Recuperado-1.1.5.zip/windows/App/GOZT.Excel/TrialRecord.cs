using System;

namespace GOZT.Excel;

internal sealed class TrialRecord
{
	public DateTimeOffset StartedUtc { get; set; }

	public DateTimeOffset LastSeenUtc { get; set; }

	public bool Blocked { get; set; }

	public string DeviceHash { get; set; } = "";
}
