namespace GOZT.Excel;

internal interface ITrialStorage
{
	TrialRecord? Load();

	void Save(TrialRecord value);
}
